# sched_fork (9073a7a3917969e4ea)

**Created:** 9/21/2025 18:19:36  
**Updated:** 9/23/2025 15:37:23  
**Exported:** 9/26/2025 10:55:31  
**Link:** [https://claude.ai/chat/6a345550-11a6-46a7-8b3c-f3638625bb93](https://claude.ai/chat/6a345550-11a6-46a7-8b3c-f3638625bb93)  

## Prompt:
9/21/2025, 6:19:37 PM

I'm doing some kernel hacking and have successfully added my very own scheduler class to the Linux 6.14 kernel! I have called this scheduling class "wfs". I have successfully integrated support for my scheduler in the existing kernel data structures (task struct, rq struct, init etc). My scheduler does work on an SMP setup.

However, I noticed my scheduler has a bug!! 



```
int sched_fork(unsigned long clone_flags, struct task_struct *p)
{
	__sched_fork(clone_flags, p);
	/*
	 * We mark the process as NEW here. This guarantees that
	 * nobody will actually run it, and a signal or other external
	 * event cannot wake it up and insert it on the runqueue either.
	 */
	p->__state = TASK_NEW;

	/*
	 * Make sure we do not leak PI boosting priority to the child.
	 */
	p->prio = current->normal_prio;

	uclamp_fork(p);

	/*
	 * Revert to default priority/policy on fork if requested.
	 */
	if (unlikely(p->sched_reset_on_fork)) {
		if (task_has_dl_policy(p) || task_has_rt_policy(p)) {
			p->policy = SCHED_NORMAL;
			p->static_prio = NICE_TO_PRIO(0);
			p->rt_priority = 0;
		} else if (PRIO_TO_NICE(p->static_prio) < 0)
			p->static_prio = NICE_TO_PRIO(0);

		p->prio = p->normal_prio = p->static_prio;
		set_load_weight(p, false);
		p->se.custom_slice = 0;
		p->se.slice = sysctl_sched_base_slice;

		/*
		 * We don't need the reset flag anymore after the fork. It has
		 * fulfilled its duty:
		 */
		p->sched_reset_on_fork = 0;
	}

	if (dl_prio(p->prio))
		return -EAGAIN;

	scx_pre_fork(p);

	if (rt_prio(p->prio)) {
		p->sched_class = &rt_sched_class;
#ifdef CONFIG_SCHED_CLASS_EXT
	} else if (task_should_scx(p->policy)) {
		p->sched_class = &ext_sched_class;
#endif
	} else {
		p->sched_class = &fair_sched_class;
	}

	init_entity_runnable_average(&p->se);


#ifdef CONFIG_SCHED_INFO
	if (likely(sched_info_on()))
		memset(&p->sched_info, 0, sizeof(p->sched_info));
#endif
#if defined(CONFIG_SMP)
	p->on_cpu = 0;
#endif
	init_task_preempt_count(p);
#ifdef CONFIG_SMP
	plist_node_init(&p->pushable_tasks, MAX_PRIO);
	RB_CLEAR_NODE(&p->pushable_dl_tasks);
#endif
	return 0;
}
```


This is the sched_fork function in the 6.14 kernel. I believe it gets called to set the scheduler up for a newly forked process. In here I think we are missing a key line(s) that ensures that if the parent process is a WFS scheduled task, then the child should be too. 

how should i modify this function if my sched class is defined at &wfs_sched_class



## Response:
9/21/2025, 6:19:48 PM

Looking at the `sched_fork()` function, you're absolutely right! The function is missing logic to handle your WFS scheduler class. Currently, it only checks for deadline (`dl_prio`), real-time (`rt_prio`), SCX (if enabled), and defaults everything else to `fair_sched_class`.

You need to add a condition to check if the parent process is using your WFS scheduler and assign the child process to the same scheduler class. Here's how you should modify the scheduler class assignment section:

```c
if (dl_prio(p->prio))
    return -EAGAIN;

scx_pre_fork(p);

if (rt_prio(p->prio)) {
    p->sched_class = &rt_sched_class;
#ifdef CONFIG_SCHED_CLASS_EXT
} else if (task_should_scx(p->policy)) {
    p->sched_class = &ext_sched_class;
#endif
} else if (current->sched_class == &wfs_sched_class) {
    p->sched_class = &wfs_sched_class;
} else {
    p->sched_class = &fair_sched_class;
}
```

The key addition is:
```c
} else if (current->sched_class == &wfs_sched_class) {
    p->sched_class = &wfs_sched_class;
```

This checks if the current (parent) process is using your WFS scheduler class and assigns the child process to the same scheduler class. The logic follows the inheritance pattern where children typically inherit scheduling properties from their parents unless explicitly overridden.

You might also want to consider:

1. **Policy inheritance**: Depending on your WFS implementation, you might also need to copy over specific policy values or WFS-specific fields from the parent's task_struct.

2. **WFS-specific initialization**: If your WFS scheduler requires additional per-task initialization (similar to how `init_entity_runnable_average(&p->se)` is called for CFS), you should add that initialization code as well.

3. **Priority handling**: Make sure your WFS scheduler properly handles the priority inheritance and any WFS-specific priority mechanisms.

This should fix the inheritance issue you're experiencing with your WFS scheduler!



## Prompt:
9/21/2025, 6:53:31 PM

> File: wfs.c

Nice i think i have fixed that! now i think i am encountering another more tricky bug. I am noticing that the virtual finishing time that I am trying to keep track of isnt actually being updated during the task lifetime. I noticed that this function 

static void update_curr_wfs(struct rq *rq)
{
    struct task_struct *curr = rq->curr;
    struct sched_wfs_entity *se;
    u64 now = rq_clock_task(rq);

    if (curr->sched_class != &wfs_sched_class)
        return;

    se = &curr->wfs;

    if (se->exec_start) {
        u64 delta_exec = now - se->exec_start;

        /* Update total runtime */
        curr->se.sum_exec_runtime += delta_exec;
        se->sum_exec_runtime += delta_exec;

        /* Update virtual runtime continuously */
        update_vruntime(se, delta_exec);

        se->exec_start = now;
    }
}

needs this se->exec_start field to be non-zero in order to update somevery important structures!

do you know what this field should be doing and when it should/shouldn't be non zero? I will give you the entire wfs file if that helps you analyze as well...



## Response:
9/21/2025, 6:54:03 PM

Looking at your code, the `se->exec_start` field is crucial for tracking when a task started executing so you can calculate how long it has been running. This field should contain the timestamp (in nanoseconds) when the task was last scheduled to run.

Here's what `exec_start` should be doing:

1. **Set to current time** when a task starts running (in `set_next_task_wfs`)
2. **Used to calculate delta_exec** (how long the task has been running) in `update_curr_wfs` and `put_prev_task_wfs`
3. **Reset to 0** when the task stops running (in `put_prev_task_wfs`)

Looking at your code, I can see the issue! In your `set_next_task_wfs` function, you're correctly setting `exec_start`:

```c
static void set_next_task_wfs(struct rq *rq, struct task_struct *p, bool first)
{
    struct wfs_rq *wfs_rq = &rq->wfs;
    
    p->wfs.exec_start = rq_clock_task(rq);  // ✓ This is correct
    
    printk(KERN_DEBUG "WFS: SET_NEXT task PID %d (first=%d), %u tasks in queue\n", 
           p->pid, first, wfs_rq->wfs_nr_running);
}
```

But the problem might be that `set_next_task_wfs` is not being called reliably. In the kernel scheduler framework, `set_next_task` is typically called by the core scheduler when your `pick_next_task` returns a task.

However, there's a potential issue with your `put_prev_task_wfs` logic. You're resetting `exec_start = 0` at the end:

```c
se->exec_start = 0;  // This might be the problem!
```

But then later in the same function, you check `if (next != p && !RB_EMPTY_NODE(&se->run_node))` - this means if the task is being preempted but is still runnable, it will stay in the runqueue. In this case, you should NOT reset `exec_start` to 0 because the task might be picked again soon.

Try modifying your `put_prev_task_wfs` like this:

```c
static void put_prev_task_wfs(struct rq *rq, struct task_struct *p, struct task_struct *next)
{
    struct sched_wfs_entity *se = &p->wfs;
    u64 now = rq_clock_task(rq);
    
    printk(KERN_DEBUG "WFS: PUT_PREV task PID %d (next is PID %d)\n",
           p->pid, next ? next->pid : -1);
    
    /* Update execution time and virtual runtime */
    if (se->exec_start) {
        u64 delta_exec = now - se->exec_start;
        
        /* Update total runtime */
        p->se.sum_exec_runtime += delta_exec;
        se->sum_exec_runtime += delta_exec;
        
        /* Update virtual runtime and recalculate VFT */
        update_vruntime(se, delta_exec);
        
        /* If task is still runnable, we need to reposition it in RB-tree */
        if (next != p && !RB_EMPTY_NODE(&se->run_node)) {
            struct wfs_rq *wfs_rq = &rq->wfs;
            
            /* Remove from current position */
            rb_erase_cached(&se->run_node, &wfs_rq->tasks_timeline);
            
            /* Re-insert at new position based on updated VFT */
            rb_add_cached(&se->run_node, &wfs_rq->tasks_timeline, wfs_entity_before);
            
            update_min_vruntime(wfs_rq);
            
            printk(KERN_DEBUG "WFS: Task PID %d repositioned in RB-tree, new VFT=%llu\n",
                   p->pid, se->vft);
        }
        
        /* Only reset exec_start if task is actually stopping execution */
        /* If it's still runnable, keep exec_start for continuous tracking */
        if (next != p) {
            se->exec_start = 0;  // Task is being preempted/switched out
        } else {
            se->exec_start = now;  // Same task continues, update timestamp
        }
    }
}
```

Also, make sure `update_curr_wfs` is being called regularly. The kernel should call this from the scheduler tick, but you can also add some debug prints to see if it's being called:

```c
static void update_curr_wfs(struct rq *rq)
{
    struct task_struct *curr = rq->curr;
    struct sched_wfs_entity *se;
    u64 now = rq_clock_task(rq);

    if (curr->sched_class != &wfs_sched_class)
        return;

    se = &curr->wfs;

    printk(KERN_DEBUG "WFS: UPDATE_CURR PID %d, exec_start=%llu, now=%llu\n",
           curr->pid, se->exec_start, now);

    if (se->exec_start) {
        u64 delta_exec = now - se->exec_start;

        /* Update total runtime */
        curr->se.sum_exec_runtime += delta_exec;
        se->sum_exec_runtime += delta_exec;

        /* Update virtual runtime continuously */
        update_vruntime(se, delta_exec);

        se->exec_start = now;
        
        printk(KERN_DEBUG "WFS: Updated vruntime=%llu, VFT=%llu for PID %d\n",
               se->vruntime, se->vft, curr->pid);
    }
}
```

The key insight is that `exec_start` should only be 0 when a task is not currently executing. When a task is running, it should always contain a valid timestamp.



## Prompt:
9/21/2025, 7:02:44 PM

> File: 

Before i actually change anything. Why dont I also give you the dmesg logs. I think you were onto somethign with set_next not being called, because if you scrape these logs, set_next is called infrequently compared to picknext



## Response:
9/21/2025, 7:03:11 PM

You're absolutely right! Looking at the logs, I can see a critical pattern:

1. **`PICKED next task`** is called frequently (every ~4 seconds)
2. **`SET_NEXT task`** is called very rarely (only twice in the entire log)
3. **VFT never changes** - it's always `104857600000` for all tasks

The issue is clear: **`set_next_task_wfs` is not being called when `pick_next_task_wfs` returns a task**, which means `exec_start` is never being set, so `update_curr_wfs` and `put_prev_task_wfs` can't calculate any execution time.

This is a common issue in custom kernel schedulers. The problem is likely in your `pick_next_task_wfs` function. Looking at your code:

```c
static struct task_struct *pick_next_task_wfs(struct rq *rq, struct task_struct *prev)
{
    // ... your logic ...
    return next_task;  // You just return the task
}
```

In modern kernel versions, **you need to call `set_next_task_wfs` yourself** from within `pick_next_task_wfs` before returning the task. The core scheduler framework expects this.

Here's how you should modify your `pick_next_task_wfs`:

```c
static struct task_struct *pick_next_task_wfs(struct rq *rq, struct task_struct *prev)
{
    struct wfs_rq *wfs_rq = &rq->wfs;
    struct sched_wfs_entity *wfs_se;
    struct task_struct *next_task;
    struct rb_node *leftmost;
    
    /* Check if we have any WFS tasks */
    if (!wfs_rq->wfs_nr_running) {
        return NULL;
    }
    
    /* Get the leftmost node (minimum VFT) from RB-tree */
    leftmost = rb_first_cached(&wfs_rq->tasks_timeline);
    if (!leftmost) {
        /* This shouldn't happen if wfs_nr_running > 0, but be safe */
        printk(KERN_WARNING "WFS: RB-tree empty but wfs_nr_running=%u, fixing\n",
               wfs_rq->wfs_nr_running);
        wfs_rq->wfs_nr_running = 0;
        return NULL;
    }
    
    wfs_se = rb_entry(leftmost, struct sched_wfs_entity, run_node);
    next_task = task_of_wfs(wfs_se);
    
    /* CRITICAL: Set the task as next before returning */
    set_next_task_wfs(rq, next_task, false);
    
    printk(KERN_DEBUG "WFS: PICKED next task PID %d (prev was PID %d), VFT=%llu, %u tasks in queue\n",
           next_task->pid, prev ? prev->pid : -1, wfs_se->vft, wfs_rq->wfs_nr_running);
    
    return next_task;
}
```

This should fix the issue because:

1. Now `set_next_task_wfs` will be called every time a task is picked
2. This will set `exec_start = rq_clock_task(rq)` 
3. Now `update_curr_wfs` and `put_prev_task_wfs` will have a valid `exec_start` to calculate `delta_exec`
4. This will finally update your `vruntime` and `VFT` values

After making this change, you should see:
- `SET_NEXT task` being called as frequently as `PICKED next task`
- `VFT` values actually changing over time
- Virtual runtime progressing properly

This is a very common gotcha in kernel scheduler development - the relationship between `pick_next_task` and `set_next_task` has evolved over kernel versions, and many schedulers need to call `set_next_task` explicitly from within `pick_next_task`.



## Prompt:
9/21/2025, 7:32:54 PM

Before i make this change i want you to be absolutely sure that you understand the newfound relationship between pick_next_task and set_next_task. Im going to providde you core.c for 6.14 and i want you to show me your reasoning.



## Response:
9/21/2025, 7:33:12 PM

You're absolutely right to ask me to verify this before making the change. I should examine the actual 6.14 core.c code to understand the precise relationship between `pick_next_task` and `set_next_task` rather than making assumptions based on general knowledge.

**web_search**

*Request*

````javascript
{
  "query": "Linux kernel 6.14 scheduler core.c pick_next_task set_next_task relationship"
}
````

*Searched*

> **scheduler - Picking the next task in Linux Kernel - Stack Overflow** [stackoverflow.com](https://stackoverflow.com/questions/34705997/picking-the-next-task-in-linux-kernel)

> **Core Scheduling — The Linux Kernel documentation** [kernel.org](https://docs.kernel.org/admin-guide/hw-vuln/core-scheduling.html)

> **Deadline Task Scheduling — The Linux Kernel documentation** [kernel.org](https://www.kernel.org/doc/html/v6.13-rc6/scheduler/sched-deadline.html)

> **Linux Kernel Scheduler Basics | Josef Bacik’s Blog** [github.io](https://josefbacik.github.io/kernel/scheduler/2017/07/14/scheduler-basics.html)

> **Digging into the Linux scheduler. One may argue that task scheduling is… | by Paulo Almeida | Medium** [medium.com](https://deepdives.medium.com/digging-into-linux-scheduler-47a32ad5a0a8)

> **CFS Scheduler — The Linux Kernel documentation** [kernel.org](https://docs.kernel.org/5.10/scheduler/sched-design-CFS.html)

> **pick next task · linux kernel core with vanilla** [gitbooks.io](https://iamyooon1.gitbooks.io/linux-kernel-core-with-vanilla/content/pick_next_task.html)

> **Linux kernel schedulers - Real-time Ubuntu documentation** [ubuntu.com](https://documentation.ubuntu.com/real-time/latest/explanation/schedulers/)

> **linux/kernel/sched/core.c at master · torvalds/linux** [github.com](https://github.com/torvalds/linux/blob/master/kernel/sched/core.c)

> **Tuning the Task Scheduler | System Analysis and Tuning Guide | openSUSE Leap 15.0** [opensuse.org](https://doc.opensuse.org/documentation/leap/archive/15.0/tuning/html/book.sle.tuning/cha.tuning.taskscheduler.html)

**web_fetch**

*Request*

````javascript
{
  "url": "https://github.com/torvalds/linux/blob/master/kernel/sched/core.c"
}
````

*Fetched*

> **linux/kernel/sched/core.c at master · torvalds/linux** [github.com](https://github.com/torvalds/linux/blob/master/kernel/sched/core.c)

You're absolutely right to ask for the core.c source. Please provide the core.c file from your 6.14 kernel so I can examine the actual implementation and understand precisely how `pick_next_task` and `set_next_task` interact in that specific kernel version.

Without seeing the actual code, I shouldn't have made assumptions about needing to call `set_next_task` from within `pick_next_task`. The relationship between these functions has indeed evolved over kernel versions, and I need to see the exact implementation in 6.14 to give you accurate advice.

Could you share the relevant portions of your kernel/sched/core.c, particularly:
1. The main scheduling function (`__schedule()` or similar)
2. The `pick_next_task()` function 
3. Any code that shows when/how `set_next_task` gets called

This way I can trace through the exact code path and understand why `set_next_task_wfs` is being called so infrequently in your logs, and provide you with the correct solution.



## Prompt:
9/21/2025, 7:33:23 PM

> File: core.c

ill just give you the whole file



## Response:
9/21/2025, 7:33:46 PM

Looking at the 6.14 core.c code, I can now provide you with the correct analysis of the `pick_next_task` and `set_next_task` relationship.

**You are absolutely right to question my earlier suggestion.** After examining the actual code, I can see that my initial recommendation to call `set_next_task_wfs` from within `pick_next_task_wfs` was **incorrect**.

Here's what the code actually shows:

## The Real Relationship in 6.14

Looking at the `__pick_next_task()` function (lines 7123-7173), I can see the actual flow:

1. **For most schedulers**: `pick_next_task()` is called, which just returns a task
2. **The core scheduler handles `set_next_task`**: After `pick_next_task()` returns, the core scheduler calls `put_prev_set_next_task()` 

Looking at lines 7140-7145:
```c
if (!p) {
    p = pick_task_idle(rq);
    put_prev_set_next_task(rq, prev, p);  // ← Core calls this
}

return p;
```

And in the main scheduling path in `pick_next_task()` (line 7198), after calling `__pick_next_task()`, the code calls:
```c
put_prev_set_next_task(rq, prev, next);  // ← Core calls set_next_task here too
```

## The Real Problem

The issue is that `set_next_task_wfs` is **not being called at all** because your scheduler is missing from the core scheduler's logic paths. Looking at the optimized path (lines 7125-7133):

```c
if (likely(!sched_class_above(prev->sched_class, &fair_sched_class) &&
           rq->nr_running == rq->cfs.h_nr_queued)) {
    // Fast path for CFS only
}
```

And the main loop (line 7151):
```c
for_each_active_class(class) {
    if (class->pick_next_task) {
        p = class->pick_next_task(rq, prev);
        if (p)
            return p;
    } else {
        p = class->pick_task(rq);
        if (p) {
            put_prev_set_next_task(rq, prev, p);
            return p;
        }
    }
}
```

## The Solution

Your WFS scheduler needs to be integrated into the `for_each_active_class()` iteration. The issue is likely in your scheduler class priority ordering or registration. 

Looking at line 4641, I can see the class hierarchy validation:
```c
BUG_ON(!sched_class_above(&dl_sched_class, &rt_sched_class));
BUG_ON(!sched_class_above(&rt_sched_class, &fair_sched_class));
BUG_ON(!sched_class_above(&fair_sched_class, &idle_sched_class));
```

**You need to ensure your `wfs_sched_class` is properly integrated into this hierarchy** and that `for_each_active_class()` will iterate over it. That's why `set_next_task_wfs` isn't being called - your scheduler class isn't being found by the core scheduler's class iteration.

The core scheduler **will** call `set_next_task` for you, but only if it can find your scheduler class in its iteration.



## Prompt:
9/21/2025, 7:35:31 PM

How can i properly integrate into this heirarchy?



## Response:
9/21/2025, 7:35:50 PM

Looking at the kernel code, you need to integrate your WFS scheduler class into the scheduler class hierarchy. Here's how to do it properly:

## 1. Define the Scheduler Class Order

The scheduler classes are ordered by priority using the `__sched_class` linker section. You need to place your WFS class in the right position in the hierarchy.

Looking at your current definition:
```c
const struct sched_class wfs_sched_class __section("__wfs_sched_class") = {
    // your methods
};
```

**Problem**: You're using `__section("__wfs_sched_class")` which creates a separate section. The kernel expects all scheduler classes to be in numbered sections that define their priority order.

## 2. Fix the Section Ordering

You need to change your section name to fit into the existing hierarchy. Looking at the kernel's scheduler class sections (typically defined in `sched.h` or similar), they follow a pattern like:

```c
// Stop class (highest priority)
#define sched_stop_sched_class      __section(".sched_class.1")
// Deadline class  
#define sched_dl_sched_class        __section(".sched_class.2") 
// RT class
#define sched_rt_sched_class        __section(".sched_class.3")
// Your WFS class should go here
#define sched_wfs_sched_class       __section(".sched_class.4")
// Fair class
#define sched_fair_sched_class      __section(".sched_class.5")
// Idle class (lowest priority)
#define sched_idle_sched_class      __section(".sched_class.6")
```

## 3. Update Your WFS Class Definition

Change your WFS scheduler class definition to:

```c
const struct sched_class wfs_sched_class __section(".sched_class.4") = {
    // your existing methods
};
```

## 4. Update the Hierarchy Validation

You also need to add your class to the hierarchy validation. In your init code (likely in `sched_init()` or similar), you need to add:

```c
// Add this line where the other BUG_ON checks are:
BUG_ON(!sched_class_above(&rt_sched_class, &wfs_sched_class));
BUG_ON(!sched_class_above(&wfs_sched_class, &fair_sched_class));
```

## 5. Ensure Proper Class Registration

Make sure your class is included in the class iteration. The `for_each_active_class` macro should automatically pick up your class if it's in the right linker section.

## 6. Check Your Implementation

Your WFS class should implement either:
- `pick_next_task` method (like RT/DL classes), OR  
- `pick_task` method (like fair/idle classes)

Looking at your code, you have `pick_next_task`, so that's correct. The core scheduler will call `put_prev_set_next_task()` for you, which will call your `set_next_task` method.

## The Key Issue

The reason `set_next_task_wfs` isn't being called is that your scheduler class isn't being found by `for_each_active_class()` because it's in the wrong linker section. Once you fix the section name to be part of the numbered sequence, the core scheduler will find your class and call your methods properly.

After making these changes, you should see `SET_NEXT task` being called every time `PICKED next task` is called, because the core scheduler will automatically call `put_prev_set_next_task()` after your `pick_next_task_wfs()` returns.





---
Powered by [Claude Exporter](https://www.claudexporter.com)