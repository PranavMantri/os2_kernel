# pick_task & cpu assignment (3f773d84cb & 2e4923ba07fd2dc)

**Created:** 9/22/2025 13:32:23  
**Updated:** 9/23/2025 15:37:43  
**Exported:** 9/26/2025 10:55:40  
**Link:** [https://claude.ai/chat/74a9953a-de30-4f08-815d-fcfbac8847f2](https://claude.ai/chat/74a9953a-de30-4f08-815d-fcfbac8847f2)  

## Prompt:
9/22/2025, 1:32:24 PM

I'm doing some kernel hacking and have successfully added my very own scheduler class to the Linux 6.14 kernel! I have called this scheduling class "wfs" which implements a weighted fair queuing scheduler. I have successfully integrated support for my scheduler in the existing kernel data structures (task struct, rq struct, init etc), and My scheduler successfully runs on an SMP setup.

However, as I was analyzing some dmesg prints that I have sprinkled around in my scheduler, I am noticing that my set_next_task fuction is rarely ever being called! I then started looking at the other schedulers implemented in this version of the kernel and aside from fair they all use a "pick task" function as opposed to a "pick next task" function. Do you have any knowledge of why this is? If so should I change my pick_next_task function to be a pick_task function?

Here is proof of it for idle and rt


```
DEFINE_SCHED_CLASS(idle) = {

	/* no enqueue/yield_task for idle tasks */

	/* dequeue is not valid, we print a debug message there: */
	.dequeue_task		= dequeue_task_idle,

	.wakeup_preempt		= wakeup_preempt_idle,

	.pick_task		= pick_task_idle,
	.put_prev_task		= put_prev_task_idle,
	.set_next_task          = set_next_task_idle,

#ifdef CONFIG_SMP
	.balance		= balance_idle,
	.select_task_rq		= select_task_rq_idle,
	.set_cpus_allowed	= set_cpus_allowed_common,
#endif

	.task_tick		= task_tick_idle,

	.prio_changed		= prio_changed_idle,
	.switched_to		= switched_to_idle,
	.update_curr		= update_curr_idle,
};
```


```
DEFINE_SCHED_CLASS(rt) = {

	.enqueue_task		= enqueue_task_rt,
	.dequeue_task		= dequeue_task_rt,
	.yield_task		= yield_task_rt,

	.wakeup_preempt		= wakeup_preempt_rt,

	.pick_task		= pick_task_rt,
	.put_prev_task		= put_prev_task_rt,
	.set_next_task          = set_next_task_rt,

#ifdef CONFIG_SMP
	.balance		= balance_rt,
	.select_task_rq		= select_task_rq_rt,
	.set_cpus_allowed       = set_cpus_allowed_common,
	.rq_online              = rq_online_rt,
	.rq_offline             = rq_offline_rt,
	.task_woken		= task_woken_rt,
	.switched_from		= switched_from_rt,
	.find_lock_rq		= find_lock_lowest_rq,
#endif

	.task_tick		= task_tick_rt,

	.get_rr_interval	= get_rr_interval_rt,

	.prio_changed		= prio_changed_rt,
	.switched_to		= switched_to_rt,

	.update_curr		= update_curr_rt,

#ifdef CONFIG_SCHED_CORE
	.task_is_throttled	= task_is_throttled_rt,
#endif

#ifdef CONFIG_UCLAMP_TASK
	.uclamp_enabled		= 1,
#endif
};
```

Compaered with fair


```
DEFINE_SCHED_CLASS(fair) = {

	.enqueue_task		= enqueue_task_fair,
	.dequeue_task		= dequeue_task_fair,
	.yield_task		= yield_task_fair,
	.yield_to_task		= yield_to_task_fair,

	.wakeup_preempt		= check_preempt_wakeup_fair,

	.pick_task		= pick_task_fair,
	.pick_next_task		= __pick_next_task_fair,
	.put_prev_task		= put_prev_task_fair,
	.set_next_task          = set_next_task_fair,

#ifdef CONFIG_SMP
	.balance		= balance_fair,
	.select_task_rq		= select_task_rq_fair,
	.migrate_task_rq	= migrate_task_rq_fair,

	.rq_online		= rq_online_fair,
	.rq_offline		= rq_offline_fair,

	.task_dead		= task_dead_fair,
	.set_cpus_allowed	= set_cpus_allowed_fair,
#endif

	.task_tick		= task_tick_fair,
	.task_fork		= task_fork_fair,

	.reweight_task		= reweight_task_fair,
	.prio_changed		= prio_changed_fair,
	.switched_from		= switched_from_fair,
	.switched_to		= switched_to_fair,

	.get_rr_interval	= get_rr_interval_fair,

	.update_curr		= update_curr_fair,

#ifdef CONFIG_FAIR_GROUP_SCHED
	.task_change_group	= task_change_group_fair,
#endif

#ifdef CONFIG_SCHED_CORE
	.task_is_throttled	= task_is_throttled_fair,
#endif

#ifdef CONFIG_UCLAMP_TASK
	.uclamp_enabled		= 1,
#endif
};
```



## Response:
9/22/2025, 1:32:40 PM

Great work on implementing your own scheduler class! You've made an astute observation about the difference between `pick_task` and `pick_next_task` functions across the scheduling classes.

The reason you're seeing `set_next_task` called rarely is directly related to this distinction. Here's what's happening:

## The Difference Between `pick_task` and `pick_next_task`

In recent Linux kernel versions (this pattern was solidified around 5.x and refined further), the scheduler core uses a two-phase approach:

1. **`pick_task`** - This is the primary selection mechanism used by the core scheduler. It's called during the main scheduling path to select which task should run next.

2. **`pick_next_task`** - This is more of a fast-path optimization, primarily used by the CFS (fair) scheduler for performance reasons when it dominates the runqueue.

## Why Your `set_next_task` Isn't Being Called Much

The scheduler core (`kernel/sched/core.c`) typically follows this logic:

1. First tries the fast-path optimizations (mainly for CFS via `pick_next_task`)
2. Falls back to the generic path using `pick_task` for all scheduler classes
3. Only calls `set_next_task` when a task is actually selected via the `pick_task` path

Since your scheduler only implements `pick_next_task`, it's likely being bypassed in favor of the generic core scheduling logic that expects `pick_task`.

## Recommendation: Implement `pick_task`

Yes, you should definitely implement `pick_task` for your WFS scheduler. Here's what you should do:

1. **Replace `pick_next_task` with `pick_task`** - The `pick_task` function should contain your core scheduling logic for selecting the next task to run.

2. **Keep `set_next_task`** - This will now be called properly when your `pick_task` function returns a valid task.

3. **Follow the same pattern as RT/DL/Idle schedulers** - These are good reference implementations for non-CFS schedulers.

Your scheduler class definition should look more like:

```c
DEFINE_SCHED_CLASS(wfs) = {
    .enqueue_task       = enqueue_task_wfs,
    .dequeue_task       = dequeue_task_wfs,
    .yield_task         = yield_task_wfs,
    
    .wakeup_preempt     = wakeup_preempt_wfs,
    
    .pick_task          = pick_task_wfs,        // <- This instead of pick_next_task
    .put_prev_task      = put_prev_task_wfs,
    .set_next_task      = set_next_task_wfs,
    
    // ... rest of your implementation
};
```

The CFS scheduler is special because it's the most commonly used scheduler and has additional optimizations. For custom schedulers like yours, following the `pick_task` pattern used by RT, DL, and idle schedulers is the correct approach.

Once you make this change, you should see your `set_next_task` function being called much more frequently, as the core scheduler will properly invoke your `pick_task` function during the scheduling decision process.



## Prompt:
9/22/2025, 1:40:20 PM

Ah i see, can you modify this to be pick_task then?

static struct task_struct *pick_task_wfs(struct rq *rq, struct task_struct *prev)
{
    struct wfs_rq *wfs_rq = &rq->wfs;
    struct sched_wfs_entity *wfs_se;
    struct task_struct *next_task;
    struct rb_node *leftmost;
    
    /* Check if we have any WFS tasks */
    if (!wfs_rq->wfs_nr_running) {
        return NULL;
    }
    
    /* Get the leftmost node (minimum VFT) from RB-tree */
    leftmost = rb_first_cached(&wfs_rq->tasks_timeline);
    if (!leftmost) {
        /* This shouldn't happen if wfs_nr_running > 0, but be safe */
        printk(KERN_WARNING "WFS: RB-tree empty but wfs_nr_running=%u, fixing\n",
               wfs_rq->wfs_nr_running);
        wfs_rq->wfs_nr_running = 0;
        return NULL;
    }
    
    wfs_se = rb_entry(leftmost, struct sched_wfs_entity, run_node);
    next_task = task_of_wfs(wfs_se);
    
    printk(KERN_DEBUG "WFS: PICKED next task PID %d (prev was PID %d), VFT=%llu, %u tasks in queue\n",
           next_task->pid, prev ? prev->pid : -1, wfs_se->vft, wfs_rq->wfs_nr_running);
    
    return next_task;
}



## Response:
9/22/2025, 1:40:30 PM

Looking at your current `pick_next_task_wfs` function, it's actually already in the correct format for `pick_task`! The function signature and logic are exactly what you need.

Here's your function with just the name change and a small adjustment:

```c
static struct task_struct *pick_task_wfs(struct rq *rq)
{
    struct wfs_rq *wfs_rq = &rq->wfs;
    struct sched_wfs_entity *wfs_se;
    struct task_struct *next_task;
    struct rb_node *leftmost;
    
    /* Check if we have any WFS tasks */
    if (!wfs_rq->wfs_nr_running) {
        return NULL;
    }
    
    /* Get the leftmost node (minimum VFT) from RB-tree */
    leftmost = rb_first_cached(&wfs_rq->tasks_timeline);
    if (!leftmost) {
        /* This shouldn't happen if wfs_nr_running > 0, but be safe */
        printk(KERN_WARNING "WFS: RB-tree empty but wfs_nr_running=%u, fixing\n",
               wfs_rq->wfs_nr_running);
        wfs_rq->wfs_nr_running = 0;
        return NULL;
    }
    
    wfs_se = rb_entry(leftmost, struct sched_wfs_entity, run_node);
    next_task = task_of_wfs(wfs_se);
    
    printk(KERN_DEBUG "WFS: PICKED task PID %d, VFT=%llu, %u tasks in queue\n",
           next_task->pid, wfs_se->vft, wfs_rq->wfs_nr_running);
    
    return next_task;
}
```

The key changes:
1. **Function name**: `pick_next_task_wfs` → `pick_task_wfs`
2. **Function signature**: Removed the `prev` parameter since `pick_task` doesn't receive it (the core scheduler handles previous task management separately)
3. **Debug print**: Simplified since we don't have the `prev` parameter anymore

Your logic for selecting the leftmost node (minimum virtual finish time) from the RB-tree is perfect for a weighted fair queuing scheduler. The core scheduler will handle calling `put_prev_task_wfs` for the previous task and `set_next_task_wfs` for the task you return, which is why you should now see `set_next_task_wfs` being called much more frequently.

Don't forget to update your scheduler class definition to use `.pick_task = pick_task_wfs` instead of `.pick_next_task = pick_next_task_wfs`.



## Prompt:
9/23/2025, 2:16:09 PM

> File: cpumask.h

> File: wfs.c

Wow that worked perfectly! Can you help me with one more thing? So far in my new scheduler I have just been assigning tasks to the cpu of the "current", but I want to add a few more properties to my scheduler that allows for better balancing of tasks across multiple cpus.

1. When deciding which CPU a task should be assigned to, it should be assigned to the CPU with the least total weight. This means we have to keep track of the total weight of all the tasks running on each CPU (cpu_total_weight). If there are multiple CPUs with the same weight, assign the task to the lowest number CPU among CPUs with the same weight.
2. Each CPU has a virtual time which starts at zero. When a task runs on that CPU for some time t, the CPU's virtual time increases by t / cpu_total_weight.
3. Each task has its virtual time which is initialized to the CPU virtual time when it is assigned to a CPU. 

Let me give you my current wfs.c file which implements my scheduling class. I will also do my best to give you the necessary cpu related helper functions in the 6.14 kernel so you dont have to make up functions yourself....



## Response:
9/23/2025, 2:17:51 PM

Looking at your requirements, you want to implement a more sophisticated load balancing scheme that tracks CPU weights and virtual times. Here's how I would modify your `wfs.c` file to add these features:

**Enhanced WFS Scheduler with CPU Load Balancing**

````c
/* 6118 */
#include <linux/mmu_context.h>
#include "sched.h"
#include "wfs.h"

/* Per-CPU data structure to track CPU load and virtual time */
DEFINE_PER_CPU(struct wfs_cpu_data, wfs_cpu_data);

/* Initialize per-CPU WFS data */
static void init_wfs_cpu_data(int cpu)
{
    struct wfs_cpu_data *cpu_data = &per_cpu(wfs_cpu_data, cpu);
    cpu_data->cpu_total_weight = 0;
    cpu_data->cpu_vtime = 0;
    raw_spin_lock_init(&cpu_data->lock);
}

/* Find the CPU with minimum total weight */
static int find_min_weight_cpu(struct task_struct *p)
{
    int cpu, best_cpu = -1;
    u64 min_weight = ULLONG_MAX;
    const struct cpumask *allowed_mask = tsk_cpus_allowed(p);
    
    for_each_cpu(cpu, allowed_mask) {
        struct wfs_cpu_data *cpu_data = &per_cpu(wfs_cpu_data, cpu);
        
        /* Skip offline CPUs */
        if (!cpu_online(cpu))
            continue;
            
        /* Find CPU with minimum weight, breaking ties with lowest CPU number */
        if (cpu_data->cpu_total_weight < min_weight) {
            min_weight = cpu_data->cpu_total_weight;
            best_cpu = cpu;
        }
    }
    
    /* Fallback to current CPU if no suitable CPU found */
    if (best_cpu == -1)
        best_cpu = smp_processor_id();
        
    return best_cpu;
}

/* Add task weight to CPU's total weight */
static void add_task_to_cpu_weight(int cpu, u64 weight)
{
    struct wfs_cpu_data *cpu_data = &per_cpu(wfs_cpu_data, cpu);
    unsigned long flags;
    
    raw_spin_lock_irqsave(&cpu_data->lock, flags);
    cpu_data->cpu_total_weight += weight;
    raw_spin_unlock_irqrestore(&cpu_data->lock, flags);
    
    printk(KERN_DEBUG "WFS: Added weight %llu to CPU %d, total weight now %llu\n",
           weight, cpu, cpu_data->cpu_total_weight);
}

/* Remove task weight from CPU's total weight */
static void remove_task_from_cpu_weight(int cpu, u64 weight)
{
    struct wfs_cpu_data *cpu_data = &per_cpu(wfs_cpu_data, cpu);
    unsigned long flags;
    
    raw_spin_lock_irqsave(&cpu_data->lock, flags);
    if (cpu_data->cpu_total_weight >= weight) {
        cpu_data->cpu_total_weight -= weight;
    } else {
        printk(KERN_WARNING "WFS: CPU %d weight underflow, resetting to 0\n", cpu);
        cpu_data->cpu_total_weight = 0;
    }
    raw_spin_unlock_irqrestore(&cpu_data->lock, flags);
    
    printk(KERN_DEBUG "WFS: Removed weight %llu from CPU %d, total weight now %llu\n",
           weight, cpu, cpu_data->cpu_total_weight);
}

/* Update CPU virtual time based on execution time */
static void update_cpu_vtime(int cpu, u64 delta_exec)
{
    struct wfs_cpu_data *cpu_data = &per_cpu(wfs_cpu_data, cpu);
    unsigned long flags;
    
    raw_spin_lock_irqsave(&cpu_data->lock, flags);
    if (cpu_data->cpu_total_weight > 0) {
        u64 vtime_delta = (delta_exec * WFS_SCALE_FACTOR) / cpu_data->cpu_total_weight;
        cpu_data->cpu_vtime += vtime_delta;
        
        printk(KERN_DEBUG "WFS: CPU %d vtime updated by %llu, now %llu (weight=%llu)\n",
               cpu, vtime_delta, cpu_data->cpu_vtime, cpu_data->cpu_total_weight);
    }
    raw_spin_unlock_irqrestore(&cpu_data->lock, flags);
}

/* Get current CPU virtual time */
static u64 get_cpu_vtime(int cpu)
{
    struct wfs_cpu_data *cpu_data = &per_cpu(wfs_cpu_data, cpu);
    unsigned long flags;
    u64 vtime;
    
    raw_spin_lock_irqsave(&cpu_data->lock, flags);
    vtime = cpu_data->cpu_vtime;
    raw_spin_unlock_irqrestore(&cpu_data->lock, flags);
    
    return vtime;
}

/* Update virtual runtime and VFT for a task */
static void update_vruntime(struct sched_wfs_entity *se, u64 delta_exec)
{
    u64 vdelta = calc_delta_fair(delta_exec, se);
    se->vruntime += vdelta;
    
    /* Calculate VFT = vruntime + (1 tick scaled) / weight */
    u64 tick_ns = TICK_NSEC; /* Duration of 1 tick in nanoseconds */
    u64 scaled_tick = calc_delta_fair(tick_ns, se);
    se->vft = se->vruntime + scaled_tick;
}

/* Initialize virtual time for new tasks */
static void place_entity(struct wfs_rq *wfs_rq, struct sched_wfs_entity *se, int cpu)
{
    /* Initialize weight if not set */
    if (!se->weight) {
        se->weight = WFS_DEFAULT_WEIGHT;
        se->inv_weight = WFS_SCALE_FACTOR / se->weight;
    }
    
    /* Set task's virtual time to current CPU virtual time */
    se->vruntime = get_cpu_vtime(cpu);
    
    /* If this is greater than min_vruntime, use min_vruntime to prevent starvation */
    if (se->vruntime < wfs_rq->min_vruntime) {
        se->vruntime = wfs_rq->min_vruntime;
    }
    
    /* Calculate initial VFT */
    u64 tick_ns = TICK_NSEC;
    u64 scaled_tick = calc_delta_fair(tick_ns, se);
    se->vft = se->vruntime + scaled_tick;
    
    /* Record which CPU this task is assigned to */
    se->assigned_cpu = cpu;
    
    printk(KERN_DEBUG "WFS: Task placed with vruntime=%llu, VFT=%llu on CPU %d (CPU vtime=%llu)\n",
           se->vruntime, se->vft, cpu, get_cpu_vtime(cpu));
}

/* Update min_vruntime for the runqueue */
static void update_min_vruntime(struct wfs_rq *wfs_rq)
{
    struct rb_node *leftmost = rb_first_cached(&wfs_rq->tasks_timeline);
    u64 vruntime = wfs_rq->min_vruntime;

    if (leftmost) {
        struct sched_wfs_entity *se = rb_entry(leftmost, struct sched_wfs_entity, run_node);
        vruntime = se->vruntime;
    }

    /* min_vruntime should never go backwards */
    wfs_rq->min_vruntime = max(wfs_rq->min_vruntime, vruntime);
}

/* Main scheduler functions */

static void enqueue_task_wfs(struct rq *rq, struct task_struct *p, int flags)
{
    struct wfs_rq *wfs_rq = &rq->wfs;
    struct sched_wfs_entity *se = &p->wfs;
    int cpu = cpu_of(rq);

    /* Only add if not already on RB-tree */
    if (RB_EMPTY_NODE(&se->run_node)) {
        /* Initialize virtual time for new or waking tasks */
        if (!(flags & ENQUEUE_WAKEUP) || se->vruntime == 0) {
            place_entity(wfs_rq, se, cpu);
        } else {
            /* Waking task - recalculate VFT based on current vruntime */
            u64 tick_ns = TICK_NSEC;
            u64 scaled_tick = calc_delta_fair(tick_ns, se);
            se->vft = se->vruntime + scaled_tick;
        }

        /* Add task weight to CPU's total weight */
        add_task_to_cpu_weight(cpu, se->weight);

        /* Insert into RB-tree ordered by VFT */
        rb_add_cached(&se->run_node, &wfs_rq->tasks_timeline, wfs_entity_before);

        wfs_rq->wfs_nr_running++;

        /* Also add to list for compatibility */
        if (list_empty(&se->run_list)) {
            list_add_tail(&se->run_list, &wfs_rq->queue);
        }

        update_min_vruntime(wfs_rq);

        printk(KERN_INFO "WFS: PID %d ENQUEUED on CPU %d (flags=%d), vruntime=%llu, VFT=%llu, weight=%llu, runqueue now has %u tasks\n",
               p->pid, cpu, flags, se->vruntime, se->vft, se->weight, wfs_rq->wfs_nr_running);
    } else {
        printk(KERN_WARNING "WFS: PID %d already on runqueue, skipping enqueue\n", p->pid);
    }
}

static bool dequeue_task_wfs(struct rq *rq, struct task_struct *p, int flags)
{
    struct wfs_rq *wfs_rq = &rq->wfs;
    struct sched_wfs_entity *se = &p->wfs;
    int cpu = cpu_of(rq);

    /* Only remove if actually in RB-tree */
    if (!RB_EMPTY_NODE(&se->run_node)) {
        /* Remove task weight from CPU's total weight */
        remove_task_from_cpu_weight(cpu, se->weight);

        rb_erase_cached(&se->run_node, &wfs_rq->tasks_timeline);
        RB_CLEAR_NODE(&se->run_node);

        wfs_rq->wfs_nr_running--;

        /* Also remove from list */
        if (!list_empty(&se->run_list)) {
            list_del_init(&se->run_list);
        }

        update_min_vruntime(wfs_rq);

        printk(KERN_INFO "WFS: PID %d DEQUEUED from CPU %d (flags=%d), weight=%llu, runqueue now has %u tasks\n",
               p->pid, cpu, flags, se->weight, wfs_rq->wfs_nr_running);
    } else {
        printk(KERN_WARNING "WFS: PID %d not on runqueue, skipping dequeue\n", p->pid);
    }
    return true;
}

static struct task_struct *pick_task_wfs(struct rq *rq)
{
    struct wfs_rq *wfs_rq = &rq->wfs;
    struct sched_wfs_entity *wfs_se;
    struct task_struct *next_task;
    struct rb_node *leftmost;
    
    /* Check if we have any WFS tasks */
    if (!wfs_rq->wfs_nr_running) {
        return NULL;
    }
    
    /* Get the leftmost node (minimum VFT) from RB-tree */
    leftmost = rb_first_cached(&wfs_rq->tasks_timeline);
    if (!leftmost) {
        /* This shouldn't happen if wfs_nr_running > 0, but be safe */
        printk(KERN_WARNING "WFS: RB-tree empty but wfs_nr_running=%u, fixing\n",
               wfs_rq->wfs_nr_running);
        wfs_rq->wfs_nr_running = 0;
        return NULL;
    }
    
    wfs_se = rb_entry(leftmost, struct sched_wfs_entity, run_node);
    next_task = task_of_wfs(wfs_se);
    
    printk(KERN_DEBUG "WFS: PICKED task PID %d, VFT=%llu, weight=%llu, %u tasks in queue\n",
           next_task->pid, wfs_se->vft, wfs_se->weight, wfs_rq->wfs_nr_running);
    
    return next_task;
}

static void put_prev_task_wfs(struct rq *rq, struct task_struct *p, struct task_struct *next)
{
    struct sched_wfs_entity *se = &p->wfs;
    u64 now = rq_clock_task(rq);
    int cpu = cpu_of(rq);
    
    printk(KERN_DEBUG "WFS: PUT_PREV task PID %d on CPU %d (next is PID %d)\n",
           p->pid, cpu, next ? next->pid : -1);
    
    /* Update execution time and virtual runtime */
    if (se->exec_start) {
        u64 delta_exec = now - se->exec_start;
        
        /* Update total runtime */
        p->se.sum_exec_runtime += delta_exec;
        se->sum_exec_runtime += delta_exec;
        
        /* Update CPU virtual time */
        update_cpu_vtime(cpu, delta_exec);
        
        /* Update virtual runtime and recalculate VFT */
        update_vruntime(se, delta_exec);
        
        se->exec_start = 0;
        
        /* If task is still runnable, we need to reposition it in RB-tree */
        if (next != p && !RB_EMPTY_NODE(&se->run_node)) {
            struct wfs_rq *wfs_rq = &rq->wfs;
            
            /* Remove from current position */
            rb_erase_cached(&se->run_node, &wfs_rq->tasks_timeline);
            
            /* Re-insert at new position based on updated VFT */
            rb_add_cached(&se->run_node, &wfs_rq->tasks_timeline, wfs_entity_before);
            
            update_min_vruntime(wfs_rq);
            
            printk(KERN_DEBUG "WFS: Task PID %d repositioned in RB-tree, new VFT=%llu\n",
                   p->pid, se->vft);
        }
    }
}

static void set_next_task_wfs(struct rq *rq, struct task_struct *p, bool first)
{
    struct wfs_rq *wfs_rq = &rq->wfs;
    int cpu = cpu_of(rq);
    
    p->wfs.exec_start = rq_clock_task(rq);
    
    printk(KERN_DEBUG "WFS: SET_NEXT task PID %d on CPU %d (first=%d), %u tasks in queue\n", 
           p->pid, cpu, first, wfs_rq->wfs_nr_running);
}

static void update_curr_wfs(struct rq *rq)
{
    struct task_struct *curr = rq->curr;
    struct sched_wfs_entity *se;
    u64 now = rq_clock_task(rq);
    int cpu = cpu_of(rq);

    if (curr->sched_class != &wfs_sched_class)
        return;

    se = &curr->wfs;

    if (se->exec_start) {
        u64 delta_exec = now - se->exec_start;

        /* Update total runtime */
        curr->se.sum_exec_runtime += delta_exec;
        se->sum_exec_runtime += delta_exec;

        /* Update CPU virtual time */
        update_cpu_vtime(cpu, delta_exec);

        /* Update virtual runtime continuously */
        update_vruntime(se, delta_exec);

        se->exec_start = now;
    }
}

static void task_tick_wfs(struct rq *rq, struct task_struct *p, int queued)
{
    struct wfs_rq *wfs_rq = &rq->wfs;
    struct sched_wfs_entity *se = &p->wfs;
    int cpu = cpu_of(rq);

    printk(KERN_DEBUG "WFS: TASK_TICK PID %d on CPU %d (queued=%d), VFT=%llu, %u tasks in queue\n",
           p->pid, cpu, queued, se->vft, wfs_rq->wfs_nr_running);

    /* Update runtime stats first */
    update_curr_wfs(rq);

    /*
     * WFS: each task runs for exactly 1 tick quantum
     * Always preempt after 1 tick if there are other tasks
     */
    if (wfs_rq->wfs_nr_running > 1) {
        printk(KERN_DEBUG "WFS: Multiple tasks (%u) - preempting PID %d after 1 tick, VFT=%llu\n",
               wfs_rq->wfs_nr_running, p->pid, se->vft);

        /* Trigger a reschedule - put_prev_task will handle repositioning */
        resched_curr(rq);

        printk(KERN_DEBUG "WFS: Task PID %d preempted, will be repositioned based on updated VFT\n", p->pid);
    }
}

static void switched_to_wfs(struct rq *rq, struct task_struct *p)
{
    struct wfs_rq *wfs_rq = &rq->wfs;
    int cpu = cpu_of(rq);
    
    printk(KERN_INFO "WFS: Task PID %d SWITCHED_TO WFS class on CPU %d, %u tasks in queue\n", 
           p->pid, cpu, wfs_rq->wfs_nr_running);
    
    /* If this task should preempt current task */
    if (rq->curr != p && rq->curr->sched_class == &wfs_sched_class)
        resched_curr(rq);
}

static void switched_from_wfs(struct rq *rq, struct task_struct *p)
{
    struct wfs_rq *wfs_rq = &rq->wfs;
    int cpu = cpu_of(rq);
    
    printk(KERN_INFO "WFS: Task PID %d SWITCHED_FROM WFS class on CPU %d, %u tasks in queue\n", 
           p->pid, cpu, wfs_rq->wfs_nr_running);
    
    /* Clean up when task leaves WFS */
    if (p->wfs.exec_start) {
        u64 delta_exec = rq_clock_task(rq) - p->wfs.exec_start;
        p->se.sum_exec_runtime += delta_exec;
        update_cpu_vtime(cpu, delta_exec);
        p->wfs.exec_start = 0;
    }
}

static void check_preempt_curr_wfs(struct rq *rq, struct task_struct *p, int flags)
{
    /* For now, WFS is non-preemptive except for round-robin in task_tick */
    /* Could add preemption logic here if needed */
    printk(KERN_DEBUG "WFS: check_preempt_curr called for PID %d (flags=%d)\n", 
           p->pid, flags);
}

static void wakeup_preempt_wfs(struct rq *rq, struct task_struct *p, int flags)
{
    /* 
     * Called when a task wakes up to determine if it should preempt current task.
     * For WFS round-robin, we don't do immediate preemption on wakeup.
     * Tasks will be scheduled in round-robin order via task_tick.
     */
    printk(KERN_DEBUG "WFS: wakeup_preempt called for PID %d (flags=%d)\n", 
           p->pid, flags);
}

void init_wfs_rq(struct wfs_rq *wfs_rq)
{
    INIT_LIST_HEAD(&wfs_rq->queue);
    wfs_rq->tasks_timeline = RB_ROOT_CACHED;
    wfs_rq->wfs_nr_running = 0;
    wfs_rq->min_vruntime = 0;
    printk(KERN_INFO "WFS: Runqueue initialized\n");
}

/* Initialize WFS subsystem */
void init_wfs_system(void)
{
    int cpu;
    
    for_each_possible_cpu(cpu) {
        init_wfs_cpu_data(cpu);
    }
    
    printk(KERN_INFO "WFS: System initialized for %d CPUs\n", num_possible_cpus());
}

/* Enhanced SMP hooks for wfs scheduler */

static int select_task_rq_wfs(struct task_struct *p, int cpu, int flags)
{
    int best_cpu;
    
    /* Find CPU with minimum total weight */
    best_cpu = find_min_weight_cpu(p);
    
    printk(KERN_DEBUG "WFS: select_task_rq for PID %d: chose CPU %d (was %d)\n",
           p->pid, best_cpu, cpu);
    
    return best_cpu;
}

static int balance_wfs(struct rq *rq, struct task_struct *prev, struct rq_flags *rf)
{
    /* No-op balancing for now - load balancing happens at task placement */
    return 0;
}

static void migrate_task_rq_wfs(struct task_struct *p, int new_cpu)
{
    struct sched_wfs_entity *se = &p->wfs;
    int old_cpu = se->assigned_cpu;
    
    if (old_cpu != new_cpu && se->weight > 0) {
        /* Remove weight from old CPU and add to new CPU */
        if (old_cpu >= 0 && old_cpu < nr_cpu_ids) {
            remove_task_from_cpu_weight(old_cpu, se->weight);
        }
        add_task_to_cpu_weight(new_cpu, se->weight);
        se->assigned_cpu = new_cpu;
        
        printk(KERN_DEBUG "WFS: Task PID %d migrated from CPU %d to CPU %d, weight=%llu\n",
               p->pid, old_cpu, new_cpu, se->weight);
    }
}

static void rq_online_wfs(struct rq *rq)
{
    int cpu = cpu_of(rq);
    init_wfs_cpu_data(cpu);
    printk(KERN_INFO "WFS: CPU %d came online\n", cpu);
}

static void rq_offline_wfs(struct rq *rq)
{
    int cpu = cpu_of(rq);
    struct wfs_cpu_data *cpu_data = &per_cpu(wfs_cpu_data, cpu);
    
    printk(KERN_INFO "WFS: CPU %d going offline, had total weight %llu\n",
           cpu, cpu_data->cpu_total_weight);
}

static void task_woken_wfs(struct rq *rq, struct task_struct *p)
{
    /* No-op - nothing to do after remote wakeup */
}

static void set_cpus_allowed_wfs(struct task_struct *p, struct affinity_context *ctx)
{
    /* Could implement logic to rebalance if affinity changes */
    printk(KERN_DEBUG "WFS: CPU affinity changed for PID %d\n", p->pid);
}

static bool yield_to_task_wfs(struct rq *rq, struct task_struct *p)
{
    /* Return false - don't handle yield_to */
    return false;
}

const struct sched_class wfs_sched_class __section("__wfs_sched_class") = {
    .enqueue_task = enqueue_task_wfs,
    .dequeue_task = dequeue_task_wfs,
    .pick_task = pick_task_wfs,
    .put_prev_task = put_prev_task_wfs,
    .set_next_task = set_next_task_wfs,
    .task_tick = task_tick_wfs,
    .switched_to = switched_to_wfs,
    .switched_from = switched_from_wfs,
    .wakeup_preempt = wakeup_preempt_wfs,
    .update_curr = update_curr_wfs,
    .yield_to_task = yield_to_task_wfs,

#ifdef CONFIG_SMP
    .balance = balance_wfs,
    .select_task_rq = select_task_rq_wfs,
    .migrate_task_rq = migrate_task_rq_wfs,
    .rq_online = rq_online_wfs,
    .rq_offline = rq_offline_wfs,
    .task_woken = task_woken_wfs,
    .set_cpus_allowed = set_cpus_allowed_wfs,
#endif
};
/* 6118 */
````

I've enhanced your WFS scheduler with the CPU load balancing features you requested. Here are the key additions:

## New Data Structures

**Per-CPU tracking**: Added `struct wfs_cpu_data` with:
- `cpu_total_weight`: Sum of all task weights on this CPU
- `cpu_vtime`: Virtual time for the CPU (starts at 0)
- `lock`: For thread-safe access

**Task tracking**: Added `assigned_cpu` field to track which CPU a task belongs to.

## Key Features Implemented

### 1. **CPU Selection Based on Minimum Weight**
- `find_min_weight_cpu()`: Scans all allowed CPUs and selects the one with lowest total weight
- Breaks ties by choosing the lowest-numbered CPU
- Respects CPU affinity masks (`tsk_cpus_allowed`)

### 2. **CPU Virtual Time Updates**
- `update_cpu_vtime()`: When a task runs for time `t`, CPU's virtual time increases by `t / cpu_total_weight`
- Called from `put_prev_task_wfs()` and `update_curr_wfs()` whenever execution time is accounted

### 3. **Task Virtual Time Initialization**
- `place_entity()`: New tasks get their virtual time set to the CPU's current virtual time
- Falls back to `min_vruntime` if CPU's virtual time is too old to prevent starvation

### 4. **Weight Management**
- `add_task_to_cpu_weight()` / `remove_task_from_cpu_weight()`: Maintain accurate per-CPU weight totals
- Called during enqueue/dequeue and task migration
- Thread-safe with per-CPU locks

### 5. **Enhanced Migration Support**
- `migrate_task_rq_wfs()`: Properly updates weight counters when tasks migrate between CPUs
- `select_task_rq_wfs()`: Uses the new CPU selection algorithm instead of just returning current CPU

## Integration Points

You'll also need to add the per-CPU data structure definition to your `wfs.h` header:

```c
struct wfs_cpu_data {
    u64 cpu_total_weight;
    u64 cpu_vtime;
    raw_spinlock_t lock;
};

DECLARE_PER_CPU(struct wfs_cpu_data, wfs_cpu_data);
```

And call `init_wfs_system()` during kernel initialization to set up the per-CPU data structures.

The scheduler now intelligently balances load by placing new tasks on the least loaded CPUs while maintaining proper virtual time accounting per your requirements.



## Prompt:
9/23/2025, 2:23:04 PM

I notice you are creating this new struct "wfs_cpu_data" but do you think it wouldinstead make sense to just integrate all this logic into my wfs_rq struct?

struct wfs_rq {
    struct rb_root_cached   tasks_timeline;  // Leftmost-cached RB-tree for O(1) min-VFT
    struct list_head        queue;           // Keep for fallback or debugging
    unsigned int            wfs_nr_running;
    u64                     min_vruntime;    // Track minimum virtual runtime on this CPU
};



## Response:
9/23/2025, 2:25:09 PM

You're absolutely right - integrating this into the existing `wfs_rq` struct makes much more sense. Each CPU already has its own `wfs_rq` in the per-CPU runqueue structure, so we can leverage that instead of creating a separate per-CPU data structure.

**Enhanced WFS Scheduler with CPU Load Balancing** ∙ Version 5

````c
/* 6118 */
#include <linux/mmu_context.h>
#include "sched.h"
#include "wfs.h"

/* No separate per-CPU structure needed - using wfs_rq instead */

/* Find the CPU with minimum total weight */
static int find_min_weight_cpu(struct task_struct *p)
{
    int cpu, best_cpu = -1;
    u64 min_weight = ULLONG_MAX;
    const struct cpumask *allowed_mask = tsk_cpus_allowed(p);
    
    for_each_cpu(cpu, allowed_mask) {
        struct rq *cpu_rq = cpu_rq(cpu);
        struct wfs_rq *wfs_rq = &cpu_rq->wfs;
        
        /* Skip offline CPUs */
        if (!cpu_online(cpu))
            continue;
            
        /* Find CPU with minimum weight, breaking ties with lowest CPU number */
        if (wfs_rq->cpu_total_weight < min_weight) {
            min_weight = wfs_rq->cpu_total_weight;
            best_cpu = cpu;
        }
    }
    
    /* Fallback to current CPU if no suitable CPU found */
    if (best_cpu == -1)
        best_cpu = smp_processor_id();
        
    return best_cpu;
}

/* Add task weight to CPU's total weight */
static void add_task_to_cpu_weight(struct wfs_rq *wfs_rq, u64 weight)
{
    wfs_rq->cpu_total_weight += weight;
    
    printk(KERN_DEBUG "WFS: Added weight %llu to CPU, total weight now %llu\n",
           weight, wfs_rq->cpu_total_weight);
}

/* Remove task weight from CPU's total weight */
static void remove_task_from_cpu_weight(struct wfs_rq *wfs_rq, u64 weight)
{
    if (wfs_rq->cpu_total_weight >= weight) {
        wfs_rq->cpu_total_weight -= weight;
    } else {
        printk(KERN_WARNING "WFS: CPU weight underflow, resetting to 0\n");
        wfs_rq->cpu_total_weight = 0;
    }
    
    printk(KERN_DEBUG "WFS: Removed weight %llu from CPU, total weight now %llu\n",
           weight, wfs_rq->cpu_total_weight);
}

/* Update CPU virtual time based on execution time */
static void update_cpu_vtime(struct wfs_rq *wfs_rq, u64 delta_exec)
{
    if (wfs_rq->cpu_total_weight > 0) {
        u64 vtime_delta = (delta_exec * WFS_SCALE_FACTOR) / wfs_rq->cpu_total_weight;
        wfs_rq->cpu_vtime += vtime_delta;
        
        printk(KERN_DEBUG "WFS: CPU vtime updated by %llu, now %llu (weight=%llu)\n",
               vtime_delta, wfs_rq->cpu_vtime, wfs_rq->cpu_total_weight);
    }
}

/* Get current CPU virtual time */
static u64 get_cpu_vtime(struct wfs_rq *wfs_rq)
{
    return wfs_rq->cpu_vtime;
}

/* Update virtual runtime and VFT for a task */
static void update_vruntime(struct sched_wfs_entity *se, u64 delta_exec)
{
    u64 vdelta = calc_delta_fair(delta_exec, se);
    se->vruntime += vdelta;
    
    /* Calculate VFT = vruntime + (1 tick scaled) / weight */
    u64 tick_ns = TICK_NSEC; /* Duration of 1 tick in nanoseconds */
    u64 scaled_tick = calc_delta_fair(tick_ns, se);
    se->vft = se->vruntime + scaled_tick;
}

/* Initialize virtual time for new tasks */
static void place_entity(struct wfs_rq *wfs_rq, struct sched_wfs_entity *se, int cpu)
{
    /* Initialize weight if not set */
    if (!se->weight) {
        se->weight = WFS_DEFAULT_WEIGHT;
        se->inv_weight = WFS_SCALE_FACTOR / se->weight;
    }
    
    /* Set task's virtual time to current CPU virtual time */
    se->vruntime = get_cpu_vtime(wfs_rq);
    
    /* If this is greater than min_vruntime, use min_vruntime to prevent starvation */
    if (se->vruntime < wfs_rq->min_vruntime) {
        se->vruntime = wfs_rq->min_vruntime;
    }
    
    /* Calculate initial VFT */
    u64 tick_ns = TICK_NSEC;
    u64 scaled_tick = calc_delta_fair(tick_ns, se);
    se->vft = se->vruntime + scaled_tick;
    
    /* Record which CPU this task is assigned to */
    se->assigned_cpu = cpu;
    
    printk(KERN_DEBUG "WFS: Task placed with vruntime=%llu, VFT=%llu on CPU %d (CPU vtime=%llu)\n",
           se->vruntime, se->vft, cpu, get_cpu_vtime(wfs_rq));
}

/* Update min_vruntime for the runqueue */
static void update_min_vruntime(struct wfs_rq *wfs_rq)
{
    struct rb_node *leftmost = rb_first_cached(&wfs_rq->tasks_timeline);
    u64 vruntime = wfs_rq->min_vruntime;

    if (leftmost) {
        struct sched_wfs_entity *se = rb_entry(leftmost, struct sched_wfs_entity, run_node);
        vruntime = se->vruntime;
    }

    /* min_vruntime should never go backwards */
    wfs_rq->min_vruntime = max(wfs_rq->min_vruntime, vruntime);
}

/* Main scheduler functions */

static void enqueue_task_wfs(struct rq *rq, struct task_struct *p, int flags)
{
    struct wfs_rq *wfs_rq = &rq->wfs;
    struct sched_wfs_entity *se = &p->wfs;
    int cpu = cpu_of(rq);

    /* Only add if not already on RB-tree */
    if (RB_EMPTY_NODE(&se->run_node)) {
        /* Initialize virtual time for new or waking tasks */
        if (!(flags & ENQUEUE_WAKEUP) || se->vruntime == 0) {
            place_entity(wfs_rq, se, cpu);
        } else {
            /* Waking task - recalculate VFT based on current vruntime */
            u64 tick_ns = TICK_NSEC;
            u64 scaled_tick = calc_delta_fair(tick_ns, se);
            se->vft = se->vruntime + scaled_tick;
        }

        /* Add task weight to CPU's total weight */
        add_task_to_cpu_weight(cpu, se->weight);

        /* Insert into RB-tree ordered by VFT */
        rb_add_cached(&se->run_node, &wfs_rq->tasks_timeline, wfs_entity_before);

        wfs_rq->wfs_nr_running++;

        /* Also add to list for compatibility */
        if (list_empty(&se->run_list)) {
            list_add_tail(&se->run_list, &wfs_rq->queue);
        }

        update_min_vruntime(wfs_rq);

        printk(KERN_INFO "WFS: PID %d ENQUEUED on CPU %d (flags=%d), vruntime=%llu, VFT=%llu, weight=%llu, runqueue now has %u tasks\n",
               p->pid, cpu, flags, se->vruntime, se->vft, se->weight, wfs_rq->wfs_nr_running);
    } else {
        printk(KERN_WARNING "WFS: PID %d already on runqueue, skipping enqueue\n", p->pid);
    }
}

static bool dequeue_task_wfs(struct rq *rq, struct task_struct *p, int flags)
{
    struct wfs_rq *wfs_rq = &rq->wfs;
    struct sched_wfs_entity *se = &p->wfs;
    int cpu = cpu_of(rq);

    /* Only remove if actually in RB-tree */
    if (!RB_EMPTY_NODE(&se->run_node)) {
        /* Remove task weight from CPU's total weight */
        remove_task_from_cpu_weight(cpu, se->weight);

        rb_erase_cached(&se->run_node, &wfs_rq->tasks_timeline);
        RB_CLEAR_NODE(&se->run_node);

        wfs_rq->wfs_nr_running--;

        /* Also remove from list */
        if (!list_empty(&se->run_list)) {
            list_del_init(&se->run_list);
        }

        update_min_vruntime(wfs_rq);

        printk(KERN_INFO "WFS: PID %d DEQUEUED from CPU %d (flags=%d), weight=%llu, runqueue now has %u tasks\n",
               p->pid, cpu, flags, se->weight, wfs_rq->wfs_nr_running);
    } else {
        printk(KERN_WARNING "WFS: PID %d not on runqueue, skipping dequeue\n", p->pid);
    }
    return true;
}

static struct task_struct *pick_task_wfs(struct rq *rq)
{
    struct wfs_rq *wfs_rq = &rq->wfs;
    struct sched_wfs_entity *wfs_se;
    struct task_struct *next_task;
    struct rb_node *leftmost;
    
    /* Check if we have any WFS tasks */
    if (!wfs_rq->wfs_nr_running) {
        return NULL;
    }
    
    /* Get the leftmost node (minimum VFT) from RB-tree */
    leftmost = rb_first_cached(&wfs_rq->tasks_timeline);
    if (!leftmost) {
        /* This shouldn't happen if wfs_nr_running > 0, but be safe */
        printk(KERN_WARNING "WFS: RB-tree empty but wfs_nr_running=%u, fixing\n",
               wfs_rq->wfs_nr_running);
        wfs_rq->wfs_nr_running = 0;
        return NULL;
    }
    
    wfs_se = rb_entry(leftmost, struct sched_wfs_entity, run_node);
    next_task = task_of_wfs(wfs_se);
    
    printk(KERN_DEBUG "WFS: PICKED task PID %d, VFT=%llu, weight=%llu, %u tasks in queue\n",
           next_task->pid, wfs_se->vft, wfs_se->weight, wfs_rq->wfs_nr_running);
    
    return next_task;
}

static void put_prev_task_wfs(struct rq *rq, struct task_struct *p, struct task_struct *next)
{
    struct sched_wfs_entity *se = &p->wfs;
    u64 now = rq_clock_task(rq);
    int cpu = cpu_of(rq);
    
    printk(KERN_DEBUG "WFS: PUT_PREV task PID %d on CPU %d (next is PID %d)\n",
           p->pid, cpu, next ? next->pid : -1);
    
    /* Update execution time and virtual runtime */
    if (se->exec_start) {
        u64 delta_exec = now - se->exec_start;
        
        /* Update total runtime */
        p->se.sum_exec_runtime += delta_exec;
        se->sum_exec_runtime += delta_exec;
        
        /* Update CPU virtual time */
        update_cpu_vtime(cpu, delta_exec);
        
        /* Update virtual runtime and recalculate VFT */
        update_vruntime(se, delta_exec);
        
        se->exec_start = 0;
        
        /* If task is still runnable, we need to reposition it in RB-tree */
        if (next != p && !RB_EMPTY_NODE(&se->run_node)) {
            struct wfs_rq *wfs_rq = &rq->wfs;
            
            /* Remove from current position */
            rb_erase_cached(&se->run_node, &wfs_rq->tasks_timeline);
            
            /* Re-insert at new position based on updated VFT */
            rb_add_cached(&se->run_node, &wfs_rq->tasks_timeline, wfs_entity_before);
            
            update_min_vruntime(wfs_rq);
            
            printk(KERN_DEBUG "WFS: Task PID %d repositioned in RB-tree, new VFT=%llu\n",
                   p->pid, se->vft);
        }
    }
}

static void set_next_task_wfs(struct rq *rq, struct task_struct *p, bool first)
{
    struct wfs_rq *wfs_rq = &rq->wfs;
    int cpu = cpu_of(rq);
    
    p->wfs.exec_start = rq_clock_task(rq);
    
    printk(KERN_DEBUG "WFS: SET_NEXT task PID %d on CPU %d (first=%d), %u tasks in queue\n", 
           p->pid, cpu, first, wfs_rq->wfs_nr_running);
}

static void update_curr_wfs(struct rq *rq)
{
    struct task_struct *curr = rq->curr;
    struct sched_wfs_entity *se;
    u64 now = rq_clock_task(rq);
    int cpu = cpu_of(rq);

    if (curr->sched_class != &wfs_sched_class)
        return;

    se = &curr->wfs;

    if (se->exec_start) {
        u64 delta_exec = now - se->exec_start;

        /* Update total runtime */
        curr->se.sum_exec_runtime += delta_exec;
        se->sum_exec_runtime += delta_exec;

        /* Update CPU virtual time */
        update_cpu_vtime(cpu, delta_exec);

        /* Update virtual runtime continuously */
        update_vruntime(se, delta_exec);

        se->exec_start = now;
    }
}

static void task_tick_wfs(struct rq *rq, struct task_struct *p, int queued)
{
    struct wfs_rq *wfs_rq = &rq->wfs;
    struct sched_wfs_entity *se = &p->wfs;
    int cpu = cpu_of(rq);

    printk(KERN_DEBUG "WFS: TASK_TICK PID %d on CPU %d (queued=%d), VFT=%llu, %u tasks in queue\n",
           p->pid, cpu, queued, se->vft, wfs_rq->wfs_nr_running);

    /* Update runtime stats first */
    update_curr_wfs(rq);

    /*
     * WFS: each task runs for exactly 1 tick quantum
     * Always preempt after 1 tick if there are other tasks
     */
    if (wfs_rq->wfs_nr_running > 1) {
        printk(KERN_DEBUG "WFS: Multiple tasks (%u) - preempting PID %d after 1 tick, VFT=%llu\n",
               wfs_rq->wfs_nr_running, p->pid, se->vft);

        /* Trigger a reschedule - put_prev_task will handle repositioning */
        resched_curr(rq);

        printk(KERN_DEBUG "WFS: Task PID %d preempted, will be repositioned based on updated VFT\n", p->pid);
    }
}

static void switched_to_wfs(struct rq *rq, struct task_struct *p)
{
    struct wfs_rq *wfs_rq = &rq->wfs;
    int cpu = cpu_of(rq);
    
    printk(KERN_INFO "WFS: Task PID %d SWITCHED_TO WFS class on CPU %d, %u tasks in queue\n", 
           p->pid, cpu, wfs_rq->wfs_nr_running);
    
    /* If this task should preempt current task */
    if (rq->curr != p && rq->curr->sched_class == &wfs_sched_class)
        resched_curr(rq);
}

static void switched_from_wfs(struct rq *rq, struct task_struct *p)
{
    struct wfs_rq *wfs_rq = &rq->wfs;
    int cpu = cpu_of(rq);
    
    printk(KERN_INFO "WFS: Task PID %d SWITCHED_FROM WFS class on CPU %d, %u tasks in queue\n", 
           p->pid, cpu, wfs_rq->wfs_nr_running);
    
    /* Clean up when task leaves WFS */
    if (p->wfs.exec_start) {
        u64 delta_exec = rq_clock_task(rq) - p->wfs.exec_start;
        p->se.sum_exec_runtime += delta_exec;
        update_cpu_vtime(cpu, delta_exec);
        p->wfs.exec_start = 0;
    }
}

static void check_preempt_curr_wfs(struct rq *rq, struct task_struct *p, int flags)
{
    /* For now, WFS is non-preemptive except for round-robin in task_tick */
    /* Could add preemption logic here if needed */
    printk(KERN_DEBUG "WFS: check_preempt_curr called for PID %d (flags=%d)\n", 
           p->pid, flags);
}

static void wakeup_preempt_wfs(struct rq *rq, struct task_struct *p, int flags)
{
    /* 
     * Called when a task wakes up to determine if it should preempt current task.
     * For WFS round-robin, we don't do immediate preemption on wakeup.
     * Tasks will be scheduled in round-robin order via task_tick.
     */
    printk(KERN_DEBUG "WFS: wakeup_preempt called for PID %d (flags=%d)\n", 
           p->pid, flags);
}

void init_wfs_rq(struct wfs_rq *wfs_rq)
{
    INIT_LIST_HEAD(&wfs_rq->queue);
    wfs_rq->tasks_timeline = RB_ROOT_CACHED;
    wfs_rq->wfs_nr_running = 0;
    wfs_rq->min_vruntime = 0;
    printk(KERN_INFO "WFS: Runqueue initialized\n");
}

/* Initialize WFS subsystem */
void init_wfs_system(void)
{
    int cpu;
    
    for_each_possible_cpu(cpu) {
        init_wfs_cpu_data(cpu);
    }
    
    printk(KERN_INFO "WFS: System initialized for %d CPUs\n", num_possible_cpus());
}

/* Enhanced SMP hooks for wfs scheduler */

static int select_task_rq_wfs(struct task_struct *p, int cpu, int flags)
{
    int best_cpu;
    
    /* Find CPU with minimum total weight */
    best_cpu = find_min_weight_cpu(p);
    
    printk(KERN_DEBUG "WFS: select_task_rq for PID %d: chose CPU %d (was %d)\n",
           p->pid, best_cpu, cpu);
    
    return best_cpu;
}

static int balance_wfs(struct rq *rq, struct task_struct *prev, struct rq_flags *rf)
{
    /* No-op balancing for now - load balancing happens at task placement */
    return 0;
}

static void migrate_task_rq_wfs(struct task_struct *p, int new_cpu)
{
    struct sched_wfs_entity *se = &p->wfs;
    int old_cpu = se->assigned_cpu;
    
    if (old_cpu != new_cpu && se->weight > 0) {
        /* Remove weight from old CPU and add to new CPU */
        if (old_cpu >= 0 && old_cpu < nr_cpu_ids) {
            remove_task_from_cpu_weight(old_cpu, se->weight);
        }
        add_task_to_cpu_weight(new_cpu, se->weight);
        se->assigned_cpu = new_cpu;
        
        printk(KERN_DEBUG "WFS: Task PID %d migrated from CPU %d to CPU %d, weight=%llu\n",
               p->pid, old_cpu, new_cpu, se->weight);
    }
}

static void rq_online_wfs(struct rq *rq)
{
    int cpu = cpu_of(rq);
    init_wfs_cpu_data(cpu);
    printk(KERN_INFO "WFS: CPU %d came online\n", cpu);
}

static void rq_offline_wfs(struct rq *rq)
{
    int cpu = cpu_of(rq);
    struct wfs_cpu_data *cpu_data = &per_cpu(wfs_cpu_data, cpu);
    
    printk(KERN_INFO "WFS: CPU %d going offline, had total weight %llu\n",
           cpu, cpu_data->cpu_total_weight);
}

static void task_woken_wfs(struct rq *rq, struct task_struct *p)
{
    /* No-op - nothing to do after remote wakeup */
}

static void set_cpus_allowed_wfs(struct task_struct *p, struct affinity_context *ctx)
{
    /* Could implement logic to rebalance if affinity changes */
    printk(KERN_DEBUG "WFS: CPU affinity changed for PID %d\n", p->pid);
}

static bool yield_to_task_wfs(struct rq *rq, struct task_struct *p)
{
    /* Return false - don't handle yield_to */
    return false;
}

const struct sched_class wfs_sched_class __section("__wfs_sched_class") = {
    .enqueue_task = enqueue_task_wfs,
    .dequeue_task = dequeue_task_wfs,
    .pick_task = pick_task_wfs,
    .put_prev_task = put_prev_task_wfs,
    .set_next_task = set_next_task_wfs,
    .task_tick = task_tick_wfs,
    .switched_to = switched_to_wfs,
    .switched_from = switched_from_wfs,
    .wakeup_preempt = wakeup_preempt_wfs,
    .update_curr = update_curr_wfs,
    .yield_to_task = yield_to_task_wfs,

#ifdef CONFIG_SMP
    .balance = balance_wfs,
    .select_task_rq = select_task_rq_wfs,
    .migrate_task_rq = migrate_task_rq_wfs,
    .rq_online = rq_online_wfs,
    .rq_offline = rq_offline_wfs,
    .task_woken = task_woken_wfs,
    .set_cpus_allowed = set_cpus_allowed_wfs,
#endif
};
/* 6118 */
````

I'll continue updating the code to use the existing `wfs_rq` structure instead of a separate per-CPU data structure:

**Enhanced WFS Scheduler with CPU Load Balancing** ∙ Version 6

````c
/* 6118 */
#include <linux/mmu_context.h>
#include "sched.h"
#include "wfs.h"

/* No separate per-CPU structure needed - using wfs_rq instead */

/* Find the CPU with minimum total weight */
static int find_min_weight_cpu(struct task_struct *p)
{
    int cpu, best_cpu = -1;
    u64 min_weight = ULLONG_MAX;
    const struct cpumask *allowed_mask = tsk_cpus_allowed(p);
    
    for_each_cpu(cpu, allowed_mask) {
        struct rq *cpu_rq = cpu_rq(cpu);
        struct wfs_rq *wfs_rq = &cpu_rq->wfs;
        
        /* Skip offline CPUs */
        if (!cpu_online(cpu))
            continue;
            
        /* Find CPU with minimum weight, breaking ties with lowest CPU number */
        if (wfs_rq->cpu_total_weight < min_weight) {
            min_weight = wfs_rq->cpu_total_weight;
            best_cpu = cpu;
        }
    }
    
    /* Fallback to current CPU if no suitable CPU found */
    if (best_cpu == -1)
        best_cpu = smp_processor_id();
        
    return best_cpu;
}

/* Add task weight to CPU's total weight */
static void add_task_to_cpu_weight(struct wfs_rq *wfs_rq, u64 weight)
{
    wfs_rq->cpu_total_weight += weight;
    
    printk(KERN_DEBUG "WFS: Added weight %llu to CPU, total weight now %llu\n",
           weight, wfs_rq->cpu_total_weight);
}

/* Remove task weight from CPU's total weight */
static void remove_task_from_cpu_weight(struct wfs_rq *wfs_rq, u64 weight)
{
    if (wfs_rq->cpu_total_weight >= weight) {
        wfs_rq->cpu_total_weight -= weight;
    } else {
        printk(KERN_WARNING "WFS: CPU weight underflow, resetting to 0\n");
        wfs_rq->cpu_total_weight = 0;
    }
    
    printk(KERN_DEBUG "WFS: Removed weight %llu from CPU, total weight now %llu\n",
           weight, wfs_rq->cpu_total_weight);
}

/* Update CPU virtual time based on execution time */
static void update_cpu_vtime(struct wfs_rq *wfs_rq, u64 delta_exec)
{
    if (wfs_rq->cpu_total_weight > 0) {
        u64 vtime_delta = (delta_exec * WFS_SCALE_FACTOR) / wfs_rq->cpu_total_weight;
        wfs_rq->cpu_vtime += vtime_delta;
        
        printk(KERN_DEBUG "WFS: CPU vtime updated by %llu, now %llu (weight=%llu)\n",
               vtime_delta, wfs_rq->cpu_vtime, wfs_rq->cpu_total_weight);
    }
}

/* Get current CPU virtual time */
static u64 get_cpu_vtime(struct wfs_rq *wfs_rq)
{
    return wfs_rq->cpu_vtime;
}

/* Update virtual runtime and VFT for a task */
static void update_vruntime(struct sched_wfs_entity *se, u64 delta_exec)
{
    u64 vdelta = calc_delta_fair(delta_exec, se);
    se->vruntime += vdelta;
    
    /* Calculate VFT = vruntime + (1 tick scaled) / weight */
    u64 tick_ns = TICK_NSEC; /* Duration of 1 tick in nanoseconds */
    u64 scaled_tick = calc_delta_fair(tick_ns, se);
    se->vft = se->vruntime + scaled_tick;
}

/* Initialize virtual time for new tasks */
static void place_entity(struct wfs_rq *wfs_rq, struct sched_wfs_entity *se, int cpu)
{
    /* Initialize weight if not set */
    if (!se->weight) {
        se->weight = WFS_DEFAULT_WEIGHT;
        se->inv_weight = WFS_SCALE_FACTOR / se->weight;
    }
    
    /* Set task's virtual time to current CPU virtual time */
    se->vruntime = get_cpu_vtime(wfs_rq);
    
    /* If this is greater than min_vruntime, use min_vruntime to prevent starvation */
    if (se->vruntime < wfs_rq->min_vruntime) {
        se->vruntime = wfs_rq->min_vruntime;
    }
    
    /* Calculate initial VFT */
    u64 tick_ns = TICK_NSEC;
    u64 scaled_tick = calc_delta_fair(tick_ns, se);
    se->vft = se->vruntime + scaled_tick;
    
    /* Record which CPU this task is assigned to */
    se->assigned_cpu = cpu;
    
    printk(KERN_DEBUG "WFS: Task placed with vruntime=%llu, VFT=%llu on CPU %d (CPU vtime=%llu)\n",
           se->vruntime, se->vft, cpu, get_cpu_vtime(wfs_rq));
}

/* Update min_vruntime for the runqueue */
static void update_min_vruntime(struct wfs_rq *wfs_rq)
{
    struct rb_node *leftmost = rb_first_cached(&wfs_rq->tasks_timeline);
    u64 vruntime = wfs_rq->min_vruntime;

    if (leftmost) {
        struct sched_wfs_entity *se = rb_entry(leftmost, struct sched_wfs_entity, run_node);
        vruntime = se->vruntime;
    }

    /* min_vruntime should never go backwards */
    wfs_rq->min_vruntime = max(wfs_rq->min_vruntime, vruntime);
}

/* Main scheduler functions */

static void enqueue_task_wfs(struct rq *rq, struct task_struct *p, int flags)
{
    struct wfs_rq *wfs_rq = &rq->wfs;
    struct sched_wfs_entity *se = &p->wfs;
    int cpu = cpu_of(rq);

    /* Only add if not already on RB-tree */
    if (RB_EMPTY_NODE(&se->run_node)) {
        /* Initialize virtual time for new or waking tasks */
        if (!(flags & ENQUEUE_WAKEUP) || se->vruntime == 0) {
            place_entity(wfs_rq, se, cpu);
        } else {
            /* Waking task - recalculate VFT based on current vruntime */
            u64 tick_ns = TICK_NSEC;
            u64 scaled_tick = calc_delta_fair(tick_ns, se);
            se->vft = se->vruntime + scaled_tick;
        }

        /* Add task weight to CPU's total weight */
        add_task_to_cpu_weight(wfs_rq, se->weight);

        /* Insert into RB-tree ordered by VFT */
        rb_add_cached(&se->run_node, &wfs_rq->tasks_timeline, wfs_entity_before);

        wfs_rq->wfs_nr_running++;

        /* Also add to list for compatibility */
        if (list_empty(&se->run_list)) {
            list_add_tail(&se->run_list, &wfs_rq->queue);
        }

        update_min_vruntime(wfs_rq);

        printk(KERN_INFO "WFS: PID %d ENQUEUED on CPU %d (flags=%d), vruntime=%llu, VFT=%llu, weight=%llu, runqueue now has %u tasks\n",
               p->pid, cpu, flags, se->vruntime, se->vft, se->weight, wfs_rq->wfs_nr_running);
    } else {
        printk(KERN_WARNING "WFS: PID %d already on runqueue, skipping enqueue\n", p->pid);
    }
}

static bool dequeue_task_wfs(struct rq *rq, struct task_struct *p, int flags)
{
    struct wfs_rq *wfs_rq = &rq->wfs;
    struct sched_wfs_entity *se = &p->wfs;
    int cpu = cpu_of(rq);

    /* Only remove if actually in RB-tree */
    if (!RB_EMPTY_NODE(&se->run_node)) {
        /* Remove task weight from CPU's total weight */
        remove_task_from_cpu_weight(cpu, se->weight);

        rb_erase_cached(&se->run_node, &wfs_rq->tasks_timeline);
        RB_CLEAR_NODE(&se->run_node);

        wfs_rq->wfs_nr_running--;

        /* Also remove from list */
        if (!list_empty(&se->run_list)) {
            list_del_init(&se->run_list);
        }

        update_min_vruntime(wfs_rq);

        printk(KERN_INFO "WFS: PID %d DEQUEUED from CPU %d (flags=%d), weight=%llu, runqueue now has %u tasks\n",
               p->pid, cpu, flags, se->weight, wfs_rq->wfs_nr_running);
    } else {
        printk(KERN_WARNING "WFS: PID %d not on runqueue, skipping dequeue\n", p->pid);
    }
    return true;
}

static struct task_struct *pick_task_wfs(struct rq *rq)
{
    struct wfs_rq *wfs_rq = &rq->wfs;
    struct sched_wfs_entity *wfs_se;
    struct task_struct *next_task;
    struct rb_node *leftmost;
    
    /* Check if we have any WFS tasks */
    if (!wfs_rq->wfs_nr_running) {
        return NULL;
    }
    
    /* Get the leftmost node (minimum VFT) from RB-tree */
    leftmost = rb_first_cached(&wfs_rq->tasks_timeline);
    if (!leftmost) {
        /* This shouldn't happen if wfs_nr_running > 0, but be safe */
        printk(KERN_WARNING "WFS: RB-tree empty but wfs_nr_running=%u, fixing\n",
               wfs_rq->wfs_nr_running);
        wfs_rq->wfs_nr_running = 0;
        return NULL;
    }
    
    wfs_se = rb_entry(leftmost, struct sched_wfs_entity, run_node);
    next_task = task_of_wfs(wfs_se);
    
    printk(KERN_DEBUG "WFS: PICKED task PID %d, VFT=%llu, weight=%llu, %u tasks in queue\n",
           next_task->pid, wfs_se->vft, wfs_se->weight, wfs_rq->wfs_nr_running);
    
    return next_task;
}

static void put_prev_task_wfs(struct rq *rq, struct task_struct *p, struct task_struct *next)
{
    struct sched_wfs_entity *se = &p->wfs;
    u64 now = rq_clock_task(rq);
    int cpu = cpu_of(rq);
    
    printk(KERN_DEBUG "WFS: PUT_PREV task PID %d on CPU %d (next is PID %d)\n",
           p->pid, cpu, next ? next->pid : -1);
    
    /* Update execution time and virtual runtime */
    if (se->exec_start) {
        u64 delta_exec = now - se->exec_start;
        
        /* Update total runtime */
        p->se.sum_exec_runtime += delta_exec;
        se->sum_exec_runtime += delta_exec;
        
        /* Update CPU virtual time */
        update_cpu_vtime(cpu, delta_exec);
        
        /* Update virtual runtime and recalculate VFT */
        update_vruntime(se, delta_exec);
        
        se->exec_start = 0;
        
        /* If task is still runnable, we need to reposition it in RB-tree */
        if (next != p && !RB_EMPTY_NODE(&se->run_node)) {
            struct wfs_rq *wfs_rq = &rq->wfs;
            
            /* Remove from current position */
            rb_erase_cached(&se->run_node, &wfs_rq->tasks_timeline);
            
            /* Re-insert at new position based on updated VFT */
            rb_add_cached(&se->run_node, &wfs_rq->tasks_timeline, wfs_entity_before);
            
            update_min_vruntime(wfs_rq);
            
            printk(KERN_DEBUG "WFS: Task PID %d repositioned in RB-tree, new VFT=%llu\n",
                   p->pid, se->vft);
        }
    }
}

static void set_next_task_wfs(struct rq *rq, struct task_struct *p, bool first)
{
    struct wfs_rq *wfs_rq = &rq->wfs;
    int cpu = cpu_of(rq);
    
    p->wfs.exec_start = rq_clock_task(rq);
    
    printk(KERN_DEBUG "WFS: SET_NEXT task PID %d on CPU %d (first=%d), %u tasks in queue\n", 
           p->pid, cpu, first, wfs_rq->wfs_nr_running);
}

static void update_curr_wfs(struct rq *rq)
{
    struct task_struct *curr = rq->curr;
    struct sched_wfs_entity *se;
    u64 now = rq_clock_task(rq);
    int cpu = cpu_of(rq);

    if (curr->sched_class != &wfs_sched_class)
        return;

    se = &curr->wfs;

    if (se->exec_start) {
        u64 delta_exec = now - se->exec_start;

        /* Update total runtime */
        curr->se.sum_exec_runtime += delta_exec;
        se->sum_exec_runtime += delta_exec;

        /* Update CPU virtual time */
        update_cpu_vtime(cpu, delta_exec);

        /* Update virtual runtime continuously */
        update_vruntime(se, delta_exec);

        se->exec_start = now;
    }
}

static void task_tick_wfs(struct rq *rq, struct task_struct *p, int queued)
{
    struct wfs_rq *wfs_rq = &rq->wfs;
    struct sched_wfs_entity *se = &p->wfs;
    int cpu = cpu_of(rq);

    printk(KERN_DEBUG "WFS: TASK_TICK PID %d on CPU %d (queued=%d), VFT=%llu, %u tasks in queue\n",
           p->pid, cpu, queued, se->vft, wfs_rq->wfs_nr_running);

    /* Update runtime stats first */
    update_curr_wfs(rq);

    /*
     * WFS: each task runs for exactly 1 tick quantum
     * Always preempt after 1 tick if there are other tasks
     */
    if (wfs_rq->wfs_nr_running > 1) {
        printk(KERN_DEBUG "WFS: Multiple tasks (%u) - preempting PID %d after 1 tick, VFT=%llu\n",
               wfs_rq->wfs_nr_running, p->pid, se->vft);

        /* Trigger a reschedule - put_prev_task will handle repositioning */
        resched_curr(rq);

        printk(KERN_DEBUG "WFS: Task PID %d preempted, will be repositioned based on updated VFT\n", p->pid);
    }
}

static void switched_to_wfs(struct rq *rq, struct task_struct *p)
{
    struct wfs_rq *wfs_rq = &rq->wfs;
    int cpu = cpu_of(rq);
    
    printk(KERN_INFO "WFS: Task PID %d SWITCHED_TO WFS class on CPU %d, %u tasks in queue\n", 
           p->pid, cpu, wfs_rq->wfs_nr_running);
    
    /* If this task should preempt current task */
    if (rq->curr != p && rq->curr->sched_class == &wfs_sched_class)
        resched_curr(rq);
}

static void switched_from_wfs(struct rq *rq, struct task_struct *p)
{
    struct wfs_rq *wfs_rq = &rq->wfs;
    int cpu = cpu_of(rq);
    
    printk(KERN_INFO "WFS: Task PID %d SWITCHED_FROM WFS class on CPU %d, %u tasks in queue\n", 
           p->pid, cpu, wfs_rq->wfs_nr_running);
    
    /* Clean up when task leaves WFS */
    if (p->wfs.exec_start) {
        u64 delta_exec = rq_clock_task(rq) - p->wfs.exec_start;
        p->se.sum_exec_runtime += delta_exec;
        update_cpu_vtime(cpu, delta_exec);
        p->wfs.exec_start = 0;
    }
}

static void check_preempt_curr_wfs(struct rq *rq, struct task_struct *p, int flags)
{
    /* For now, WFS is non-preemptive except for round-robin in task_tick */
    /* Could add preemption logic here if needed */
    printk(KERN_DEBUG "WFS: check_preempt_curr called for PID %d (flags=%d)\n", 
           p->pid, flags);
}

static void wakeup_preempt_wfs(struct rq *rq, struct task_struct *p, int flags)
{
    /* 
     * Called when a task wakes up to determine if it should preempt current task.
     * For WFS round-robin, we don't do immediate preemption on wakeup.
     * Tasks will be scheduled in round-robin order via task_tick.
     */
    printk(KERN_DEBUG "WFS: wakeup_preempt called for PID %d (flags=%d)\n", 
           p->pid, flags);
}

void init_wfs_rq(struct wfs_rq *wfs_rq)
{
    INIT_LIST_HEAD(&wfs_rq->queue);
    wfs_rq->tasks_timeline = RB_ROOT_CACHED;
    wfs_rq->wfs_nr_running = 0;
    wfs_rq->min_vruntime = 0;
    printk(KERN_INFO "WFS: Runqueue initialized\n");
}

/* Initialize WFS subsystem */
void init_wfs_system(void)
{
    int cpu;
    
    for_each_possible_cpu(cpu) {
        init_wfs_cpu_data(cpu);
    }
    
    printk(KERN_INFO "WFS: System initialized for %d CPUs\n", num_possible_cpus());
}

/* Enhanced SMP hooks for wfs scheduler */

static int select_task_rq_wfs(struct task_struct *p, int cpu, int flags)
{
    int best_cpu;
    
    /* Find CPU with minimum total weight */
    best_cpu = find_min_weight_cpu(p);
    
    printk(KERN_DEBUG "WFS: select_task_rq for PID %d: chose CPU %d (was %d)\n",
           p->pid, best_cpu, cpu);
    
    return best_cpu;
}

static int balance_wfs(struct rq *rq, struct task_struct *prev, struct rq_flags *rf)
{
    /* No-op balancing for now - load balancing happens at task placement */
    return 0;
}

static void migrate_task_rq_wfs(struct task_struct *p, int new_cpu)
{
    struct sched_wfs_entity *se = &p->wfs;
    int old_cpu = se->assigned_cpu;
    
    if (old_cpu != new_cpu && se->weight > 0) {
        /* Remove weight from old CPU and add to new CPU */
        if (old_cpu >= 0 && old_cpu < nr_cpu_ids) {
            remove_task_from_cpu_weight(old_cpu, se->weight);
        }
        add_task_to_cpu_weight(new_cpu, se->weight);
        se->assigned_cpu = new_cpu;
        
        printk(KERN_DEBUG "WFS: Task PID %d migrated from CPU %d to CPU %d, weight=%llu\n",
               p->pid, old_cpu, new_cpu, se->weight);
    }
}

static void rq_online_wfs(struct rq *rq)
{
    int cpu = cpu_of(rq);
    init_wfs_cpu_data(cpu);
    printk(KERN_INFO "WFS: CPU %d came online\n", cpu);
}

static void rq_offline_wfs(struct rq *rq)
{
    int cpu = cpu_of(rq);
    struct wfs_cpu_data *cpu_data = &per_cpu(wfs_cpu_data, cpu);
    
    printk(KERN_INFO "WFS: CPU %d going offline, had total weight %llu\n",
           cpu, cpu_data->cpu_total_weight);
}

static void task_woken_wfs(struct rq *rq, struct task_struct *p)
{
    /* No-op - nothing to do after remote wakeup */
}

static void set_cpus_allowed_wfs(struct task_struct *p, struct affinity_context *ctx)
{
    /* Could implement logic to rebalance if affinity changes */
    printk(KERN_DEBUG "WFS: CPU affinity changed for PID %d\n", p->pid);
}

static bool yield_to_task_wfs(struct rq *rq, struct task_struct *p)
{
    /* Return false - don't handle yield_to */
    return false;
}

const struct sched_class wfs_sched_class __section("__wfs_sched_class") = {
    .enqueue_task = enqueue_task_wfs,
    .dequeue_task = dequeue_task_wfs,
    .pick_task = pick_task_wfs,
    .put_prev_task = put_prev_task_wfs,
    .set_next_task = set_next_task_wfs,
    .task_tick = task_tick_wfs,
    .switched_to = switched_to_wfs,
    .switched_from = switched_from_wfs,
    .wakeup_preempt = wakeup_preempt_wfs,
    .update_curr = update_curr_wfs,
    .yield_to_task = yield_to_task_wfs,

#ifdef CONFIG_SMP
    .balance = balance_wfs,
    .select_task_rq = select_task_rq_wfs,
    .migrate_task_rq = migrate_task_rq_wfs,
    .rq_online = rq_online_wfs,
    .rq_offline = rq_offline_wfs,
    .task_woken = task_woken_wfs,
    .set_cpus_allowed = set_cpus_allowed_wfs,
#endif
};
/* 6118 */
````

Let me finish updating all the remaining references:

**Enhanced WFS Scheduler with CPU Load Balancing** ∙ Version 9

````c
/* 6118 */
#include <linux/mmu_context.h>
#include "sched.h"
#include "wfs.h"

/* No separate per-CPU structure needed - using wfs_rq instead */

/* Find the CPU with minimum total weight */
static int find_min_weight_cpu(struct task_struct *p)
{
    int cpu, best_cpu = -1;
    u64 min_weight = ULLONG_MAX;
    const struct cpumask *allowed_mask = tsk_cpus_allowed(p);
    
    for_each_cpu(cpu, allowed_mask) {
        struct rq *cpu_rq = cpu_rq(cpu);
        struct wfs_rq *wfs_rq = &cpu_rq->wfs;
        
        /* Skip offline CPUs */
        if (!cpu_online(cpu))
            continue;
            
        /* Find CPU with minimum weight, breaking ties with lowest CPU number */
        if (wfs_rq->cpu_total_weight < min_weight) {
            min_weight = wfs_rq->cpu_total_weight;
            best_cpu = cpu;
        }
    }
    
    /* Fallback to current CPU if no suitable CPU found */
    if (best_cpu == -1)
        best_cpu = smp_processor_id();
        
    return best_cpu;
}

/* Add task weight to CPU's total weight */
static void add_task_to_cpu_weight(struct wfs_rq *wfs_rq, u64 weight)
{
    wfs_rq->cpu_total_weight += weight;
    
    printk(KERN_DEBUG "WFS: Added weight %llu to CPU, total weight now %llu\n",
           weight, wfs_rq->cpu_total_weight);
}

/* Remove task weight from CPU's total weight */
static void remove_task_from_cpu_weight(struct wfs_rq *wfs_rq, u64 weight)
{
    if (wfs_rq->cpu_total_weight >= weight) {
        wfs_rq->cpu_total_weight -= weight;
    } else {
        printk(KERN_WARNING "WFS: CPU weight underflow, resetting to 0\n");
        wfs_rq->cpu_total_weight = 0;
    }
    
    printk(KERN_DEBUG "WFS: Removed weight %llu from CPU, total weight now %llu\n",
           weight, wfs_rq->cpu_total_weight);
}

/* Update CPU virtual time based on execution time */
static void update_cpu_vtime(struct wfs_rq *wfs_rq, u64 delta_exec)
{
    if (wfs_rq->cpu_total_weight > 0) {
        u64 vtime_delta = (delta_exec * WFS_SCALE_FACTOR) / wfs_rq->cpu_total_weight;
        wfs_rq->cpu_vtime += vtime_delta;
        
        printk(KERN_DEBUG "WFS: CPU vtime updated by %llu, now %llu (weight=%llu)\n",
               vtime_delta, wfs_rq->cpu_vtime, wfs_rq->cpu_total_weight);
    }
}

/* Get current CPU virtual time */
static u64 get_cpu_vtime(struct wfs_rq *wfs_rq)
{
    return wfs_rq->cpu_vtime;
}

/* Update virtual runtime and VFT for a task */
static void update_vruntime(struct sched_wfs_entity *se, u64 delta_exec)
{
    u64 vdelta = calc_delta_fair(delta_exec, se);
    se->vruntime += vdelta;
    
    /* Calculate VFT = vruntime + (1 tick scaled) / weight */
    u64 tick_ns = TICK_NSEC; /* Duration of 1 tick in nanoseconds */
    u64 scaled_tick = calc_delta_fair(tick_ns, se);
    se->vft = se->vruntime + scaled_tick;
}

/* Initialize virtual time for new tasks */
static void place_entity(struct wfs_rq *wfs_rq, struct sched_wfs_entity *se, int cpu)
{
    /* Initialize weight if not set */
    if (!se->weight) {
        se->weight = WFS_DEFAULT_WEIGHT;
        se->inv_weight = WFS_SCALE_FACTOR / se->weight;
    }
    
    /* Set task's virtual time to current CPU virtual time */
    se->vruntime = get_cpu_vtime(wfs_rq);
    
    /* If this is greater than min_vruntime, use min_vruntime to prevent starvation */
    if (se->vruntime < wfs_rq->min_vruntime) {
        se->vruntime = wfs_rq->min_vruntime;
    }
    
    /* Calculate initial VFT */
    u64 tick_ns = TICK_NSEC;
    u64 scaled_tick = calc_delta_fair(tick_ns, se);
    se->vft = se->vruntime + scaled_tick;
    
    /* Record which CPU this task is assigned to */
    se->assigned_cpu = cpu;
    
    printk(KERN_DEBUG "WFS: Task placed with vruntime=%llu, VFT=%llu on CPU %d (CPU vtime=%llu)\n",
           se->vruntime, se->vft, cpu, get_cpu_vtime(wfs_rq));
}

/* Update min_vruntime for the runqueue */
static void update_min_vruntime(struct wfs_rq *wfs_rq)
{
    struct rb_node *leftmost = rb_first_cached(&wfs_rq->tasks_timeline);
    u64 vruntime = wfs_rq->min_vruntime;

    if (leftmost) {
        struct sched_wfs_entity *se = rb_entry(leftmost, struct sched_wfs_entity, run_node);
        vruntime = se->vruntime;
    }

    /* min_vruntime should never go backwards */
    wfs_rq->min_vruntime = max(wfs_rq->min_vruntime, vruntime);
}

/* Main scheduler functions */

static void enqueue_task_wfs(struct rq *rq, struct task_struct *p, int flags)
{
    struct wfs_rq *wfs_rq = &rq->wfs;
    struct sched_wfs_entity *se = &p->wfs;
    int cpu = cpu_of(rq);

    /* Only add if not already on RB-tree */
    if (RB_EMPTY_NODE(&se->run_node)) {
        /* Initialize virtual time for new or waking tasks */
        if (!(flags & ENQUEUE_WAKEUP) || se->vruntime == 0) {
            place_entity(wfs_rq, se, cpu);
        } else {
            /* Waking task - recalculate VFT based on current vruntime */
            u64 tick_ns = TICK_NSEC;
            u64 scaled_tick = calc_delta_fair(tick_ns, se);
            se->vft = se->vruntime + scaled_tick;
        }

        /* Add task weight to CPU's total weight */
        add_task_to_cpu_weight(wfs_rq, se->weight);

        /* Insert into RB-tree ordered by VFT */
        rb_add_cached(&se->run_node, &wfs_rq->tasks_timeline, wfs_entity_before);

        wfs_rq->wfs_nr_running++;

        /* Also add to list for compatibility */
        if (list_empty(&se->run_list)) {
            list_add_tail(&se->run_list, &wfs_rq->queue);
        }

        update_min_vruntime(wfs_rq);

        printk(KERN_INFO "WFS: PID %d ENQUEUED on CPU %d (flags=%d), vruntime=%llu, VFT=%llu, weight=%llu, runqueue now has %u tasks\n",
               p->pid, cpu, flags, se->vruntime, se->vft, se->weight, wfs_rq->wfs_nr_running);
    } else {
        printk(KERN_WARNING "WFS: PID %d already on runqueue, skipping enqueue\n", p->pid);
    }
}

static bool dequeue_task_wfs(struct rq *rq, struct task_struct *p, int flags)
{
    struct wfs_rq *wfs_rq = &rq->wfs;
    struct sched_wfs_entity *se = &p->wfs;
    int cpu = cpu_of(rq);

    /* Only remove if actually in RB-tree */
    if (!RB_EMPTY_NODE(&se->run_node)) {
        /* Remove task weight from CPU's total weight */
        remove_task_from_cpu_weight(wfs_rq, se->weight);

        rb_erase_cached(&se->run_node, &wfs_rq->tasks_timeline);
        RB_CLEAR_NODE(&se->run_node);

        wfs_rq->wfs_nr_running--;

        /* Also remove from list */
        if (!list_empty(&se->run_list)) {
            list_del_init(&se->run_list);
        }

        update_min_vruntime(wfs_rq);

        printk(KERN_INFO "WFS: PID %d DEQUEUED from CPU %d (flags=%d), weight=%llu, runqueue now has %u tasks\n",
               p->pid, cpu, flags, se->weight, wfs_rq->wfs_nr_running);
    } else {
        printk(KERN_WARNING "WFS: PID %d not on runqueue, skipping dequeue\n", p->pid);
    }
    return true;
}

static struct task_struct *pick_task_wfs(struct rq *rq)
{
    struct wfs_rq *wfs_rq = &rq->wfs;
    struct sched_wfs_entity *wfs_se;
    struct task_struct *next_task;
    struct rb_node *leftmost;
    
    /* Check if we have any WFS tasks */
    if (!wfs_rq->wfs_nr_running) {
        return NULL;
    }
    
    /* Get the leftmost node (minimum VFT) from RB-tree */
    leftmost = rb_first_cached(&wfs_rq->tasks_timeline);
    if (!leftmost) {
        /* This shouldn't happen if wfs_nr_running > 0, but be safe */
        printk(KERN_WARNING "WFS: RB-tree empty but wfs_nr_running=%u, fixing\n",
               wfs_rq->wfs_nr_running);
        wfs_rq->wfs_nr_running = 0;
        return NULL;
    }
    
    wfs_se = rb_entry(leftmost, struct sched_wfs_entity, run_node);
    next_task = task_of_wfs(wfs_se);
    
    printk(KERN_DEBUG "WFS: PICKED task PID %d, VFT=%llu, weight=%llu, %u tasks in queue\n",
           next_task->pid, wfs_se->vft, wfs_se->weight, wfs_rq->wfs_nr_running);
    
    return next_task;
}

static void put_prev_task_wfs(struct rq *rq, struct task_struct *p, struct task_struct *next)
{
    struct sched_wfs_entity *se = &p->wfs;
    u64 now = rq_clock_task(rq);
    int cpu = cpu_of(rq);
    
    printk(KERN_DEBUG "WFS: PUT_PREV task PID %d on CPU %d (next is PID %d)\n",
           p->pid, cpu, next ? next->pid : -1);
    
    /* Update execution time and virtual runtime */
    if (se->exec_start) {
        u64 delta_exec = now - se->exec_start;
        
        /* Update total runtime */
        p->se.sum_exec_runtime += delta_exec;
        se->sum_exec_runtime += delta_exec;
        
        /* Update CPU virtual time */
        update_cpu_vtime(wfs_rq, delta_exec);
        
        /* Update virtual runtime and recalculate VFT */
        update_vruntime(se, delta_exec);
        
        se->exec_start = 0;
        
        /* If task is still runnable, we need to reposition it in RB-tree */
        if (next != p && !RB_EMPTY_NODE(&se->run_node)) {
            struct wfs_rq *wfs_rq = &rq->wfs;
            
            /* Remove from current position */
            rb_erase_cached(&se->run_node, &wfs_rq->tasks_timeline);
            
            /* Re-insert at new position based on updated VFT */
            rb_add_cached(&se->run_node, &wfs_rq->tasks_timeline, wfs_entity_before);
            
            update_min_vruntime(wfs_rq);
            
            printk(KERN_DEBUG "WFS: Task PID %d repositioned in RB-tree, new VFT=%llu\n",
                   p->pid, se->vft);
        }
    }
}

static void set_next_task_wfs(struct rq *rq, struct task_struct *p, bool first)
{
    struct wfs_rq *wfs_rq = &rq->wfs;
    int cpu = cpu_of(rq);
    
    p->wfs.exec_start = rq_clock_task(rq);
    
    printk(KERN_DEBUG "WFS: SET_NEXT task PID %d on CPU %d (first=%d), %u tasks in queue\n", 
           p->pid, cpu, first, wfs_rq->wfs_nr_running);
}

static void update_curr_wfs(struct rq *rq)
{
    struct task_struct *curr = rq->curr;
    struct sched_wfs_entity *se;
    u64 now = rq_clock_task(rq);
    int cpu = cpu_of(rq);

    if (curr->sched_class != &wfs_sched_class)
        return;

    se = &curr->wfs;

    if (se->exec_start) {
        u64 delta_exec = now - se->exec_start;

        /* Update total runtime */
        curr->se.sum_exec_runtime += delta_exec;
        se->sum_exec_runtime += delta_exec;

        /* Update CPU virtual time */
        update_cpu_vtime(wfs_rq, delta_exec);

        /* Update virtual runtime continuously */
        update_vruntime(se, delta_exec);

        se->exec_start = now;
    }
}

static void task_tick_wfs(struct rq *rq, struct task_struct *p, int queued)
{
    struct wfs_rq *wfs_rq = &rq->wfs;
    struct sched_wfs_entity *se = &p->wfs;
    int cpu = cpu_of(rq);

    printk(KERN_DEBUG "WFS: TASK_TICK PID %d on CPU %d (queued=%d), VFT=%llu, %u tasks in queue\n",
           p->pid, cpu, queued, se->vft, wfs_rq->wfs_nr_running);

    /* Update runtime stats first */
    update_curr_wfs(rq);

    /*
     * WFS: each task runs for exactly 1 tick quantum
     * Always preempt after 1 tick if there are other tasks
     */
    if (wfs_rq->wfs_nr_running > 1) {
        printk(KERN_DEBUG "WFS: Multiple tasks (%u) - preempting PID %d after 1 tick, VFT=%llu\n",
               wfs_rq->wfs_nr_running, p->pid, se->vft);

        /* Trigger a reschedule - put_prev_task will handle repositioning */
        resched_curr(rq);

        printk(KERN_DEBUG "WFS: Task PID %d preempted, will be repositioned based on updated VFT\n", p->pid);
    }
}

static void switched_to_wfs(struct rq *rq, struct task_struct *p)
{
    struct wfs_rq *wfs_rq = &rq->wfs;
    int cpu = cpu_of(rq);
    
    printk(KERN_INFO "WFS: Task PID %d SWITCHED_TO WFS class on CPU %d, %u tasks in queue\n", 
           p->pid, cpu, wfs_rq->wfs_nr_running);
    
    /* If this task should preempt current task */
    if (rq->curr != p && rq->curr->sched_class == &wfs_sched_class)
        resched_curr(rq);
}

static void switched_from_wfs(struct rq *rq, struct task_struct *p)
{
    struct wfs_rq *wfs_rq = &rq->wfs;
    int cpu = cpu_of(rq);
    
    printk(KERN_INFO "WFS: Task PID %d SWITCHED_FROM WFS class on CPU %d, %u tasks in queue\n", 
           p->pid, cpu, wfs_rq->wfs_nr_running);
    
    /* Clean up when task leaves WFS */
    if (p->wfs.exec_start) {
        u64 delta_exec = rq_clock_task(rq) - p->wfs.exec_start;
        p->se.sum_exec_runtime += delta_exec;
        update_cpu_vtime(cpu, delta_exec);
        p->wfs.exec_start = 0;
    }
}

static void check_preempt_curr_wfs(struct rq *rq, struct task_struct *p, int flags)
{
    /* For now, WFS is non-preemptive except for round-robin in task_tick */
    /* Could add preemption logic here if needed */
    printk(KERN_DEBUG "WFS: check_preempt_curr called for PID %d (flags=%d)\n", 
           p->pid, flags);
}

static void wakeup_preempt_wfs(struct rq *rq, struct task_struct *p, int flags)
{
    /* 
     * Called when a task wakes up to determine if it should preempt current task.
     * For WFS round-robin, we don't do immediate preemption on wakeup.
     * Tasks will be scheduled in round-robin order via task_tick.
     */
    printk(KERN_DEBUG "WFS: wakeup_preempt called for PID %d (flags=%d)\n", 
           p->pid, flags);
}

void init_wfs_rq(struct wfs_rq *wfs_rq)
{
    INIT_LIST_HEAD(&wfs_rq->queue);
    wfs_rq->tasks_timeline = RB_ROOT_CACHED;
    wfs_rq->wfs_nr_running = 0;
    wfs_rq->min_vruntime = 0;
    printk(KERN_INFO "WFS: Runqueue initialized\n");
}

/* Initialize WFS subsystem */
void init_wfs_system(void)
{
    int cpu;
    
    for_each_possible_cpu(cpu) {
        init_wfs_cpu_data(cpu);
    }
    
    printk(KERN_INFO "WFS: System initialized for %d CPUs\n", num_possible_cpus());
}

/* Enhanced SMP hooks for wfs scheduler */

static int select_task_rq_wfs(struct task_struct *p, int cpu, int flags)
{
    int best_cpu;
    
    /* Find CPU with minimum total weight */
    best_cpu = find_min_weight_cpu(p);
    
    printk(KERN_DEBUG "WFS: select_task_rq for PID %d: chose CPU %d (was %d)\n",
           p->pid, best_cpu, cpu);
    
    return best_cpu;
}

static int balance_wfs(struct rq *rq, struct task_struct *prev, struct rq_flags *rf)
{
    /* No-op balancing for now - load balancing happens at task placement */
    return 0;
}

static void migrate_task_rq_wfs(struct task_struct *p, int new_cpu)
{
    struct sched_wfs_entity *se = &p->wfs;
    int old_cpu = se->assigned_cpu;
    
    if (old_cpu != new_cpu && se->weight > 0) {
        /* Remove weight from old CPU and add to new CPU */
        if (old_cpu >= 0 && old_cpu < nr_cpu_ids) {
            remove_task_from_cpu_weight(old_cpu, se->weight);
        }
        add_task_to_cpu_weight(new_cpu, se->weight);
        se->assigned_cpu = new_cpu;
        
        printk(KERN_DEBUG "WFS: Task PID %d migrated from CPU %d to CPU %d, weight=%llu\n",
               p->pid, old_cpu, new_cpu, se->weight);
    }
}

static void rq_online_wfs(struct rq *rq)
{
    int cpu = cpu_of(rq);
    init_wfs_cpu_data(cpu);
    printk(KERN_INFO "WFS: CPU %d came online\n", cpu);
}

static void rq_offline_wfs(struct rq *rq)
{
    int cpu = cpu_of(rq);
    struct wfs_cpu_data *cpu_data = &per_cpu(wfs_cpu_data, cpu);
    
    printk(KERN_INFO "WFS: CPU %d going offline, had total weight %llu\n",
           cpu, cpu_data->cpu_total_weight);
}

static void task_woken_wfs(struct rq *rq, struct task_struct *p)
{
    /* No-op - nothing to do after remote wakeup */
}

static void set_cpus_allowed_wfs(struct task_struct *p, struct affinity_context *ctx)
{
    /* Could implement logic to rebalance if affinity changes */
    printk(KERN_DEBUG "WFS: CPU affinity changed for PID %d\n", p->pid);
}

static bool yield_to_task_wfs(struct rq *rq, struct task_struct *p)
{
    /* Return false - don't handle yield_to */
    return false;
}

const struct sched_class wfs_sched_class __section("__wfs_sched_class") = {
    .enqueue_task = enqueue_task_wfs,
    .dequeue_task = dequeue_task_wfs,
    .pick_task = pick_task_wfs,
    .put_prev_task = put_prev_task_wfs,
    .set_next_task = set_next_task_wfs,
    .task_tick = task_tick_wfs,
    .switched_to = switched_to_wfs,
    .switched_from = switched_from_wfs,
    .wakeup_preempt = wakeup_preempt_wfs,
    .update_curr = update_curr_wfs,
    .yield_to_task = yield_to_task_wfs,

#ifdef CONFIG_SMP
    .balance = balance_wfs,
    .select_task_rq = select_task_rq_wfs,
    .migrate_task_rq = migrate_task_rq_wfs,
    .rq_online = rq_online_wfs,
    .rq_offline = rq_offline_wfs,
    .task_woken = task_woken_wfs,
    .set_cpus_allowed = set_cpus_allowed_wfs,
#endif
};
/* 6118 */
````

I'll update the remaining parts of the code that need to use the `wfs_rq` structure:

**Enhanced WFS Scheduler with CPU Load Balancing** ∙ Version 10

````c
/* 6118 */
#include <linux/mmu_context.h>
#include "sched.h"
#include "wfs.h"

/* No separate per-CPU structure needed - using wfs_rq instead */

/* Find the CPU with minimum total weight */
static int find_min_weight_cpu(struct task_struct *p)
{
    int cpu, best_cpu = -1;
    u64 min_weight = ULLONG_MAX;
    const struct cpumask *allowed_mask = tsk_cpus_allowed(p);
    
    for_each_cpu(cpu, allowed_mask) {
        struct rq *cpu_rq = cpu_rq(cpu);
        struct wfs_rq *wfs_rq = &cpu_rq->wfs;
        
        /* Skip offline CPUs */
        if (!cpu_online(cpu))
            continue;
            
        /* Find CPU with minimum weight, breaking ties with lowest CPU number */
        if (wfs_rq->cpu_total_weight < min_weight) {
            min_weight = wfs_rq->cpu_total_weight;
            best_cpu = cpu;
        }
    }
    
    /* Fallback to current CPU if no suitable CPU found */
    if (best_cpu == -1)
        best_cpu = smp_processor_id();
        
    return best_cpu;
}

/* Add task weight to CPU's total weight */
static void add_task_to_cpu_weight(struct wfs_rq *wfs_rq, u64 weight)
{
    wfs_rq->cpu_total_weight += weight;
    
    printk(KERN_DEBUG "WFS: Added weight %llu to CPU, total weight now %llu\n",
           weight, wfs_rq->cpu_total_weight);
}

/* Remove task weight from CPU's total weight */
static void remove_task_from_cpu_weight(struct wfs_rq *wfs_rq, u64 weight)
{
    if (wfs_rq->cpu_total_weight >= weight) {
        wfs_rq->cpu_total_weight -= weight;
    } else {
        printk(KERN_WARNING "WFS: CPU weight underflow, resetting to 0\n");
        wfs_rq->cpu_total_weight = 0;
    }
    
    printk(KERN_DEBUG "WFS: Removed weight %llu from CPU, total weight now %llu\n",
           weight, wfs_rq->cpu_total_weight);
}

/* Update CPU virtual time based on execution time */
static void update_cpu_vtime(struct wfs_rq *wfs_rq, u64 delta_exec)
{
    if (wfs_rq->cpu_total_weight > 0) {
        u64 vtime_delta = (delta_exec * WFS_SCALE_FACTOR) / wfs_rq->cpu_total_weight;
        wfs_rq->cpu_vtime += vtime_delta;
        
        printk(KERN_DEBUG "WFS: CPU vtime updated by %llu, now %llu (weight=%llu)\n",
               vtime_delta, wfs_rq->cpu_vtime, wfs_rq->cpu_total_weight);
    }
}

/* Get current CPU virtual time */
static u64 get_cpu_vtime(struct wfs_rq *wfs_rq)
{
    return wfs_rq->cpu_vtime;
}

/* Update virtual runtime and VFT for a task */
static void update_vruntime(struct sched_wfs_entity *se, u64 delta_exec)
{
    u64 vdelta = calc_delta_fair(delta_exec, se);
    se->vruntime += vdelta;
    
    /* Calculate VFT = vruntime + (1 tick scaled) / weight */
    u64 tick_ns = TICK_NSEC; /* Duration of 1 tick in nanoseconds */
    u64 scaled_tick = calc_delta_fair(tick_ns, se);
    se->vft = se->vruntime + scaled_tick;
}

/* Initialize virtual time for new tasks */
static void place_entity(struct wfs_rq *wfs_rq, struct sched_wfs_entity *se, int cpu)
{
    /* Initialize weight if not set */
    if (!se->weight) {
        se->weight = WFS_DEFAULT_WEIGHT;
        se->inv_weight = WFS_SCALE_FACTOR / se->weight;
    }
    
    /* Set task's virtual time to current CPU virtual time */
    se->vruntime = get_cpu_vtime(wfs_rq);
    
    /* If this is greater than min_vruntime, use min_vruntime to prevent starvation */
    if (se->vruntime < wfs_rq->min_vruntime) {
        se->vruntime = wfs_rq->min_vruntime;
    }
    
    /* Calculate initial VFT */
    u64 tick_ns = TICK_NSEC;
    u64 scaled_tick = calc_delta_fair(tick_ns, se);
    se->vft = se->vruntime + scaled_tick;
    
    /* Record which CPU this task is assigned to */
    se->assigned_cpu = cpu;
    
    printk(KERN_DEBUG "WFS: Task placed with vruntime=%llu, VFT=%llu on CPU %d (CPU vtime=%llu)\n",
           se->vruntime, se->vft, cpu, get_cpu_vtime(wfs_rq));
}

/* Update min_vruntime for the runqueue */
static void update_min_vruntime(struct wfs_rq *wfs_rq)
{
    struct rb_node *leftmost = rb_first_cached(&wfs_rq->tasks_timeline);
    u64 vruntime = wfs_rq->min_vruntime;

    if (leftmost) {
        struct sched_wfs_entity *se = rb_entry(leftmost, struct sched_wfs_entity, run_node);
        vruntime = se->vruntime;
    }

    /* min_vruntime should never go backwards */
    wfs_rq->min_vruntime = max(wfs_rq->min_vruntime, vruntime);
}

/* Main scheduler functions */

static void enqueue_task_wfs(struct rq *rq, struct task_struct *p, int flags)
{
    struct wfs_rq *wfs_rq = &rq->wfs;
    struct sched_wfs_entity *se = &p->wfs;
    int cpu = cpu_of(rq);

    /* Only add if not already on RB-tree */
    if (RB_EMPTY_NODE(&se->run_node)) {
        /* Initialize virtual time for new or waking tasks */
        if (!(flags & ENQUEUE_WAKEUP) || se->vruntime == 0) {
            place_entity(wfs_rq, se, cpu);
        } else {
            /* Waking task - recalculate VFT based on current vruntime */
            u64 tick_ns = TICK_NSEC;
            u64 scaled_tick = calc_delta_fair(tick_ns, se);
            se->vft = se->vruntime + scaled_tick;
        }

        /* Add task weight to CPU's total weight */
        add_task_to_cpu_weight(wfs_rq, se->weight);

        /* Insert into RB-tree ordered by VFT */
        rb_add_cached(&se->run_node, &wfs_rq->tasks_timeline, wfs_entity_before);

        wfs_rq->wfs_nr_running++;

        /* Also add to list for compatibility */
        if (list_empty(&se->run_list)) {
            list_add_tail(&se->run_list, &wfs_rq->queue);
        }

        update_min_vruntime(wfs_rq);

        printk(KERN_INFO "WFS: PID %d ENQUEUED on CPU %d (flags=%d), vruntime=%llu, VFT=%llu, weight=%llu, runqueue now has %u tasks\n",
               p->pid, cpu, flags, se->vruntime, se->vft, se->weight, wfs_rq->wfs_nr_running);
    } else {
        printk(KERN_WARNING "WFS: PID %d already on runqueue, skipping enqueue\n", p->pid);
    }
}

static bool dequeue_task_wfs(struct rq *rq, struct task_struct *p, int flags)
{
    struct wfs_rq *wfs_rq = &rq->wfs;
    struct sched_wfs_entity *se = &p->wfs;
    int cpu = cpu_of(rq);

    /* Only remove if actually in RB-tree */
    if (!RB_EMPTY_NODE(&se->run_node)) {
        /* Remove task weight from CPU's total weight */
        remove_task_from_cpu_weight(wfs_rq, se->weight);

        rb_erase_cached(&se->run_node, &wfs_rq->tasks_timeline);
        RB_CLEAR_NODE(&se->run_node);

        wfs_rq->wfs_nr_running--;

        /* Also remove from list */
        if (!list_empty(&se->run_list)) {
            list_del_init(&se->run_list);
        }

        update_min_vruntime(wfs_rq);

        printk(KERN_INFO "WFS: PID %d DEQUEUED from CPU %d (flags=%d), weight=%llu, runqueue now has %u tasks\n",
               p->pid, cpu, flags, se->weight, wfs_rq->wfs_nr_running);
    } else {
        printk(KERN_WARNING "WFS: PID %d not on runqueue, skipping dequeue\n", p->pid);
    }
    return true;
}

static struct task_struct *pick_task_wfs(struct rq *rq)
{
    struct wfs_rq *wfs_rq = &rq->wfs;
    struct sched_wfs_entity *wfs_se;
    struct task_struct *next_task;
    struct rb_node *leftmost;
    
    /* Check if we have any WFS tasks */
    if (!wfs_rq->wfs_nr_running) {
        return NULL;
    }
    
    /* Get the leftmost node (minimum VFT) from RB-tree */
    leftmost = rb_first_cached(&wfs_rq->tasks_timeline);
    if (!leftmost) {
        /* This shouldn't happen if wfs_nr_running > 0, but be safe */
        printk(KERN_WARNING "WFS: RB-tree empty but wfs_nr_running=%u, fixing\n",
               wfs_rq->wfs_nr_running);
        wfs_rq->wfs_nr_running = 0;
        return NULL;
    }
    
    wfs_se = rb_entry(leftmost, struct sched_wfs_entity, run_node);
    next_task = task_of_wfs(wfs_se);
    
    printk(KERN_DEBUG "WFS: PICKED task PID %d, VFT=%llu, weight=%llu, %u tasks in queue\n",
           next_task->pid, wfs_se->vft, wfs_se->weight, wfs_rq->wfs_nr_running);
    
    return next_task;
}

static void put_prev_task_wfs(struct rq *rq, struct task_struct *p, struct task_struct *next)
{
    struct sched_wfs_entity *se = &p->wfs;
    u64 now = rq_clock_task(rq);
    int cpu = cpu_of(rq);
    
    printk(KERN_DEBUG "WFS: PUT_PREV task PID %d on CPU %d (next is PID %d)\n",
           p->pid, cpu, next ? next->pid : -1);
    
    /* Update execution time and virtual runtime */
    if (se->exec_start) {
        u64 delta_exec = now - se->exec_start;
        
        /* Update total runtime */
        p->se.sum_exec_runtime += delta_exec;
        se->sum_exec_runtime += delta_exec;
        
        /* Update CPU virtual time */
        update_cpu_vtime(wfs_rq, delta_exec);
        
        /* Update virtual runtime and recalculate VFT */
        update_vruntime(se, delta_exec);
        
        se->exec_start = 0;
        
        /* If task is still runnable, we need to reposition it in RB-tree */
        if (next != p && !RB_EMPTY_NODE(&se->run_node)) {
            struct wfs_rq *wfs_rq = &rq->wfs;
            
            /* Remove from current position */
            rb_erase_cached(&se->run_node, &wfs_rq->tasks_timeline);
            
            /* Re-insert at new position based on updated VFT */
            rb_add_cached(&se->run_node, &wfs_rq->tasks_timeline, wfs_entity_before);
            
            update_min_vruntime(wfs_rq);
            
            printk(KERN_DEBUG "WFS: Task PID %d repositioned in RB-tree, new VFT=%llu\n",
                   p->pid, se->vft);
        }
    }
}

static void set_next_task_wfs(struct rq *rq, struct task_struct *p, bool first)
{
    struct wfs_rq *wfs_rq = &rq->wfs;
    int cpu = cpu_of(rq);
    
    p->wfs.exec_start = rq_clock_task(rq);
    
    printk(KERN_DEBUG "WFS: SET_NEXT task PID %d on CPU %d (first=%d), %u tasks in queue\n", 
           p->pid, cpu, first, wfs_rq->wfs_nr_running);
}

static void update_curr_wfs(struct rq *rq)
{
    struct task_struct *curr = rq->curr;
    struct sched_wfs_entity *se;
    u64 now = rq_clock_task(rq);
    int cpu = cpu_of(rq);

    if (curr->sched_class != &wfs_sched_class)
        return;

    se = &curr->wfs;

    if (se->exec_start) {
        u64 delta_exec = now - se->exec_start;

        /* Update total runtime */
        curr->se.sum_exec_runtime += delta_exec;
        se->sum_exec_runtime += delta_exec;

        /* Update CPU virtual time */
        update_cpu_vtime(wfs_rq, delta_exec);

        /* Update virtual runtime continuously */
        update_vruntime(se, delta_exec);

        se->exec_start = now;
    }
}

static void task_tick_wfs(struct rq *rq, struct task_struct *p, int queued)
{
    struct wfs_rq *wfs_rq = &rq->wfs;
    struct sched_wfs_entity *se = &p->wfs;
    int cpu = cpu_of(rq);

    printk(KERN_DEBUG "WFS: TASK_TICK PID %d on CPU %d (queued=%d), VFT=%llu, %u tasks in queue\n",
           p->pid, cpu, queued, se->vft, wfs_rq->wfs_nr_running);

    /* Update runtime stats first */
    update_curr_wfs(rq);

    /*
     * WFS: each task runs for exactly 1 tick quantum
     * Always preempt after 1 tick if there are other tasks
     */
    if (wfs_rq->wfs_nr_running > 1) {
        printk(KERN_DEBUG "WFS: Multiple tasks (%u) - preempting PID %d after 1 tick, VFT=%llu\n",
               wfs_rq->wfs_nr_running, p->pid, se->vft);

        /* Trigger a reschedule - put_prev_task will handle repositioning */
        resched_curr(rq);

        printk(KERN_DEBUG "WFS: Task PID %d preempted, will be repositioned based on updated VFT\n", p->pid);
    }
}

static void switched_to_wfs(struct rq *rq, struct task_struct *p)
{
    struct wfs_rq *wfs_rq = &rq->wfs;
    int cpu = cpu_of(rq);
    
    printk(KERN_INFO "WFS: Task PID %d SWITCHED_TO WFS class on CPU %d, %u tasks in queue\n", 
           p->pid, cpu, wfs_rq->wfs_nr_running);
    
    /* If this task should preempt current task */
    if (rq->curr != p && rq->curr->sched_class == &wfs_sched_class)
        resched_curr(rq);
}

static void switched_from_wfs(struct rq *rq, struct task_struct *p)
{
    struct wfs_rq *wfs_rq = &rq->wfs;
    int cpu = cpu_of(rq);
    
    printk(KERN_INFO "WFS: Task PID %d SWITCHED_FROM WFS class on CPU %d, %u tasks in queue\n", 
           p->pid, cpu, wfs_rq->wfs_nr_running);
    
    /* Clean up when task leaves WFS */
    if (p->wfs.exec_start) {
        u64 delta_exec = rq_clock_task(rq) - p->wfs.exec_start;
        p->se.sum_exec_runtime += delta_exec;
        update_cpu_vtime(&rq->wfs, delta_exec);
        p->wfs.exec_start = 0;
    }
}

static void check_preempt_curr_wfs(struct rq *rq, struct task_struct *p, int flags)
{
    /* For now, WFS is non-preemptive except for round-robin in task_tick */
    /* Could add preemption logic here if needed */
    printk(KERN_DEBUG "WFS: check_preempt_curr called for PID %d (flags=%d)\n", 
           p->pid, flags);
}

static void wakeup_preempt_wfs(struct rq *rq, struct task_struct *p, int flags)
{
    /* 
     * Called when a task wakes up to determine if it should preempt current task.
     * For WFS round-robin, we don't do immediate preemption on wakeup.
     * Tasks will be scheduled in round-robin order via task_tick.
     */
    printk(KERN_DEBUG "WFS: wakeup_preempt called for PID %d (flags=%d)\n", 
           p->pid, flags);
}

void init_wfs_rq(struct wfs_rq *wfs_rq)
{
    INIT_LIST_HEAD(&wfs_rq->queue);
    wfs_rq->tasks_timeline = RB_ROOT_CACHED;
    wfs_rq->wfs_nr_running = 0;
    wfs_rq->min_vruntime = 0;
    printk(KERN_INFO "WFS: Runqueue initialized\n");
}

/* Initialize WFS subsystem */
void init_wfs_system(void)
{
    int cpu;
    
    for_each_possible_cpu(cpu) {
        init_wfs_cpu_data(cpu);
    }
    
    printk(KERN_INFO "WFS: System initialized for %d CPUs\n", num_possible_cpus());
}

/* Enhanced SMP hooks for wfs scheduler */

static int select_task_rq_wfs(struct task_struct *p, int cpu, int flags)
{
    int best_cpu;
    
    /* Find CPU with minimum total weight */
    best_cpu = find_min_weight_cpu(p);
    
    printk(KERN_DEBUG "WFS: select_task_rq for PID %d: chose CPU %d (was %d)\n",
           p->pid, best_cpu, cpu);
    
    return best_cpu;
}

static int balance_wfs(struct rq *rq, struct task_struct *prev, struct rq_flags *rf)
{
    /* No-op balancing for now - load balancing happens at task placement */
    return 0;
}

static void migrate_task_rq_wfs(struct task_struct *p, int new_cpu)
{
    struct sched_wfs_entity *se = &p->wfs;
    int old_cpu = se->assigned_cpu;
    
    if (old_cpu != new_cpu && se->weight > 0) {
        /* Remove weight from old CPU and add to new CPU */
        if (old_cpu >= 0 && old_cpu < nr_cpu_ids) {
            remove_task_from_cpu_weight(old_cpu, se->weight);
        }
        add_task_to_cpu_weight(new_cpu, se->weight);
        se->assigned_cpu = new_cpu;
        
        printk(KERN_DEBUG "WFS: Task PID %d migrated from CPU %d to CPU %d, weight=%llu\n",
               p->pid, old_cpu, new_cpu, se->weight);
    }
}

static void rq_online_wfs(struct rq *rq)
{
    int cpu = cpu_of(rq);
    init_wfs_cpu_data(cpu);
    printk(KERN_INFO "WFS: CPU %d came online\n", cpu);
}

static void rq_offline_wfs(struct rq *rq)
{
    int cpu = cpu_of(rq);
    struct wfs_cpu_data *cpu_data = &per_cpu(wfs_cpu_data, cpu);
    
    printk(KERN_INFO "WFS: CPU %d going offline, had total weight %llu\n",
           cpu, cpu_data->cpu_total_weight);
}

static void task_woken_wfs(struct rq *rq, struct task_struct *p)
{
    /* No-op - nothing to do after remote wakeup */
}

static void set_cpus_allowed_wfs(struct task_struct *p, struct affinity_context *ctx)
{
    /* Could implement logic to rebalance if affinity changes */
    printk(KERN_DEBUG "WFS: CPU affinity changed for PID %d\n", p->pid);
}

static bool yield_to_task_wfs(struct rq *rq, struct task_struct *p)
{
    /* Return false - don't handle yield_to */
    return false;
}

const struct sched_class wfs_sched_class __section("__wfs_sched_class") = {
    .enqueue_task = enqueue_task_wfs,
    .dequeue_task = dequeue_task_wfs,
    .pick_task = pick_task_wfs,
    .put_prev_task = put_prev_task_wfs,
    .set_next_task = set_next_task_wfs,
    .task_tick = task_tick_wfs,
    .switched_to = switched_to_wfs,
    .switched_from = switched_from_wfs,
    .wakeup_preempt = wakeup_preempt_wfs,
    .update_curr = update_curr_wfs,
    .yield_to_task = yield_to_task_wfs,

#ifdef CONFIG_SMP
    .balance = balance_wfs,
    .select_task_rq = select_task_rq_wfs,
    .migrate_task_rq = migrate_task_rq_wfs,
    .rq_online = rq_online_wfs,
    .rq_offline = rq_offline_wfs,
    .task_woken = task_woken_wfs,
    .set_cpus_allowed = set_cpus_allowed_wfs,
#endif
};
/* 6118 */
````

Let me complete updating the migrate_task_rq_wfs function:

**Enhanced WFS Scheduler with CPU Load Balancing** ∙ Version 11

````c
/* 6118 */
#include <linux/mmu_context.h>
#include "sched.h"
#include "wfs.h"

/* No separate per-CPU structure needed - using wfs_rq instead */

/* Find the CPU with minimum total weight */
static int find_min_weight_cpu(struct task_struct *p)
{
    int cpu, best_cpu = -1;
    u64 min_weight = ULLONG_MAX;
    const struct cpumask *allowed_mask = tsk_cpus_allowed(p);
    
    for_each_cpu(cpu, allowed_mask) {
        struct rq *cpu_rq = cpu_rq(cpu);
        struct wfs_rq *wfs_rq = &cpu_rq->wfs;
        
        /* Skip offline CPUs */
        if (!cpu_online(cpu))
            continue;
            
        /* Find CPU with minimum weight, breaking ties with lowest CPU number */
        if (wfs_rq->cpu_total_weight < min_weight) {
            min_weight = wfs_rq->cpu_total_weight;
            best_cpu = cpu;
        }
    }
    
    /* Fallback to current CPU if no suitable CPU found */
    if (best_cpu == -1)
        best_cpu = smp_processor_id();
        
    return best_cpu;
}

/* Add task weight to CPU's total weight */
static void add_task_to_cpu_weight(struct wfs_rq *wfs_rq, u64 weight)
{
    wfs_rq->cpu_total_weight += weight;
    
    printk(KERN_DEBUG "WFS: Added weight %llu to CPU, total weight now %llu\n",
           weight, wfs_rq->cpu_total_weight);
}

/* Remove task weight from CPU's total weight */
static void remove_task_from_cpu_weight(struct wfs_rq *wfs_rq, u64 weight)
{
    if (wfs_rq->cpu_total_weight >= weight) {
        wfs_rq->cpu_total_weight -= weight;
    } else {
        printk(KERN_WARNING "WFS: CPU weight underflow, resetting to 0\n");
        wfs_rq->cpu_total_weight = 0;
    }
    
    printk(KERN_DEBUG "WFS: Removed weight %llu from CPU, total weight now %llu\n",
           weight, wfs_rq->cpu_total_weight);
}

/* Update CPU virtual time based on execution time */
static void update_cpu_vtime(struct wfs_rq *wfs_rq, u64 delta_exec)
{
    if (wfs_rq->cpu_total_weight > 0) {
        u64 vtime_delta = (delta_exec * WFS_SCALE_FACTOR) / wfs_rq->cpu_total_weight;
        wfs_rq->cpu_vtime += vtime_delta;
        
        printk(KERN_DEBUG "WFS: CPU vtime updated by %llu, now %llu (weight=%llu)\n",
               vtime_delta, wfs_rq->cpu_vtime, wfs_rq->cpu_total_weight);
    }
}

/* Get current CPU virtual time */
static u64 get_cpu_vtime(struct wfs_rq *wfs_rq)
{
    return wfs_rq->cpu_vtime;
}

/* Update virtual runtime and VFT for a task */
static void update_vruntime(struct sched_wfs_entity *se, u64 delta_exec)
{
    u64 vdelta = calc_delta_fair(delta_exec, se);
    se->vruntime += vdelta;
    
    /* Calculate VFT = vruntime + (1 tick scaled) / weight */
    u64 tick_ns = TICK_NSEC; /* Duration of 1 tick in nanoseconds */
    u64 scaled_tick = calc_delta_fair(tick_ns, se);
    se->vft = se->vruntime + scaled_tick;
}

/* Initialize virtual time for new tasks */
static void place_entity(struct wfs_rq *wfs_rq, struct sched_wfs_entity *se, int cpu)
{
    /* Initialize weight if not set */
    if (!se->weight) {
        se->weight = WFS_DEFAULT_WEIGHT;
        se->inv_weight = WFS_SCALE_FACTOR / se->weight;
    }
    
    /* Set task's virtual time to current CPU virtual time */
    se->vruntime = get_cpu_vtime(wfs_rq);
    
    /* If this is greater than min_vruntime, use min_vruntime to prevent starvation */
    if (se->vruntime < wfs_rq->min_vruntime) {
        se->vruntime = wfs_rq->min_vruntime;
    }
    
    /* Calculate initial VFT */
    u64 tick_ns = TICK_NSEC;
    u64 scaled_tick = calc_delta_fair(tick_ns, se);
    se->vft = se->vruntime + scaled_tick;
    
    /* Record which CPU this task is assigned to */
    se->assigned_cpu = cpu;
    
    printk(KERN_DEBUG "WFS: Task placed with vruntime=%llu, VFT=%llu on CPU %d (CPU vtime=%llu)\n",
           se->vruntime, se->vft, cpu, get_cpu_vtime(wfs_rq));
}

/* Update min_vruntime for the runqueue */
static void update_min_vruntime(struct wfs_rq *wfs_rq)
{
    struct rb_node *leftmost = rb_first_cached(&wfs_rq->tasks_timeline);
    u64 vruntime = wfs_rq->min_vruntime;

    if (leftmost) {
        struct sched_wfs_entity *se = rb_entry(leftmost, struct sched_wfs_entity, run_node);
        vruntime = se->vruntime;
    }

    /* min_vruntime should never go backwards */
    wfs_rq->min_vruntime = max(wfs_rq->min_vruntime, vruntime);
}

/* Main scheduler functions */

static void enqueue_task_wfs(struct rq *rq, struct task_struct *p, int flags)
{
    struct wfs_rq *wfs_rq = &rq->wfs;
    struct sched_wfs_entity *se = &p->wfs;
    int cpu = cpu_of(rq);

    /* Only add if not already on RB-tree */
    if (RB_EMPTY_NODE(&se->run_node)) {
        /* Initialize virtual time for new or waking tasks */
        if (!(flags & ENQUEUE_WAKEUP) || se->vruntime == 0) {
            place_entity(wfs_rq, se, cpu);
        } else {
            /* Waking task - recalculate VFT based on current vruntime */
            u64 tick_ns = TICK_NSEC;
            u64 scaled_tick = calc_delta_fair(tick_ns, se);
            se->vft = se->vruntime + scaled_tick;
        }

        /* Add task weight to CPU's total weight */
        add_task_to_cpu_weight(wfs_rq, se->weight);

        /* Insert into RB-tree ordered by VFT */
        rb_add_cached(&se->run_node, &wfs_rq->tasks_timeline, wfs_entity_before);

        wfs_rq->wfs_nr_running++;

        /* Also add to list for compatibility */
        if (list_empty(&se->run_list)) {
            list_add_tail(&se->run_list, &wfs_rq->queue);
        }

        update_min_vruntime(wfs_rq);

        printk(KERN_INFO "WFS: PID %d ENQUEUED on CPU %d (flags=%d), vruntime=%llu, VFT=%llu, weight=%llu, runqueue now has %u tasks\n",
               p->pid, cpu, flags, se->vruntime, se->vft, se->weight, wfs_rq->wfs_nr_running);
    } else {
        printk(KERN_WARNING "WFS: PID %d already on runqueue, skipping enqueue\n", p->pid);
    }
}

static bool dequeue_task_wfs(struct rq *rq, struct task_struct *p, int flags)
{
    struct wfs_rq *wfs_rq = &rq->wfs;
    struct sched_wfs_entity *se = &p->wfs;
    int cpu = cpu_of(rq);

    /* Only remove if actually in RB-tree */
    if (!RB_EMPTY_NODE(&se->run_node)) {
        /* Remove task weight from CPU's total weight */
        remove_task_from_cpu_weight(wfs_rq, se->weight);

        rb_erase_cached(&se->run_node, &wfs_rq->tasks_timeline);
        RB_CLEAR_NODE(&se->run_node);

        wfs_rq->wfs_nr_running--;

        /* Also remove from list */
        if (!list_empty(&se->run_list)) {
            list_del_init(&se->run_list);
        }

        update_min_vruntime(wfs_rq);

        printk(KERN_INFO "WFS: PID %d DEQUEUED from CPU %d (flags=%d), weight=%llu, runqueue now has %u tasks\n",
               p->pid, cpu, flags, se->weight, wfs_rq->wfs_nr_running);
    } else {
        printk(KERN_WARNING "WFS: PID %d not on runqueue, skipping dequeue\n", p->pid);
    }
    return true;
}

static struct task_struct *pick_task_wfs(struct rq *rq)
{
    struct wfs_rq *wfs_rq = &rq->wfs;
    struct sched_wfs_entity *wfs_se;
    struct task_struct *next_task;
    struct rb_node *leftmost;
    
    /* Check if we have any WFS tasks */
    if (!wfs_rq->wfs_nr_running) {
        return NULL;
    }
    
    /* Get the leftmost node (minimum VFT) from RB-tree */
    leftmost = rb_first_cached(&wfs_rq->tasks_timeline);
    if (!leftmost) {
        /* This shouldn't happen if wfs_nr_running > 0, but be safe */
        printk(KERN_WARNING "WFS: RB-tree empty but wfs_nr_running=%u, fixing\n",
               wfs_rq->wfs_nr_running);
        wfs_rq->wfs_nr_running = 0;
        return NULL;
    }
    
    wfs_se = rb_entry(leftmost, struct sched_wfs_entity, run_node);
    next_task = task_of_wfs(wfs_se);
    
    printk(KERN_DEBUG "WFS: PICKED task PID %d, VFT=%llu, weight=%llu, %u tasks in queue\n",
           next_task->pid, wfs_se->vft, wfs_se->weight, wfs_rq->wfs_nr_running);
    
    return next_task;
}

static void put_prev_task_wfs(struct rq *rq, struct task_struct *p, struct task_struct *next)
{
    struct sched_wfs_entity *se = &p->wfs;
    u64 now = rq_clock_task(rq);
    int cpu = cpu_of(rq);
    
    printk(KERN_DEBUG "WFS: PUT_PREV task PID %d on CPU %d (next is PID %d)\n",
           p->pid, cpu, next ? next->pid : -1);
    
    /* Update execution time and virtual runtime */
    if (se->exec_start) {
        u64 delta_exec = now - se->exec_start;
        
        /* Update total runtime */
        p->se.sum_exec_runtime += delta_exec;
        se->sum_exec_runtime += delta_exec;
        
        /* Update CPU virtual time */
        update_cpu_vtime(wfs_rq, delta_exec);
        
        /* Update virtual runtime and recalculate VFT */
        update_vruntime(se, delta_exec);
        
        se->exec_start = 0;
        
        /* If task is still runnable, we need to reposition it in RB-tree */
        if (next != p && !RB_EMPTY_NODE(&se->run_node)) {
            struct wfs_rq *wfs_rq = &rq->wfs;
            
            /* Remove from current position */
            rb_erase_cached(&se->run_node, &wfs_rq->tasks_timeline);
            
            /* Re-insert at new position based on updated VFT */
            rb_add_cached(&se->run_node, &wfs_rq->tasks_timeline, wfs_entity_before);
            
            update_min_vruntime(wfs_rq);
            
            printk(KERN_DEBUG "WFS: Task PID %d repositioned in RB-tree, new VFT=%llu\n",
                   p->pid, se->vft);
        }
    }
}

static void set_next_task_wfs(struct rq *rq, struct task_struct *p, bool first)
{
    struct wfs_rq *wfs_rq = &rq->wfs;
    int cpu = cpu_of(rq);
    
    p->wfs.exec_start = rq_clock_task(rq);
    
    printk(KERN_DEBUG "WFS: SET_NEXT task PID %d on CPU %d (first=%d), %u tasks in queue\n", 
           p->pid, cpu, first, wfs_rq->wfs_nr_running);
}

static void update_curr_wfs(struct rq *rq)
{
    struct task_struct *curr = rq->curr;
    struct sched_wfs_entity *se;
    u64 now = rq_clock_task(rq);
    int cpu = cpu_of(rq);

    if (curr->sched_class != &wfs_sched_class)
        return;

    se = &curr->wfs;

    if (se->exec_start) {
        u64 delta_exec = now - se->exec_start;

        /* Update total runtime */
        curr->se.sum_exec_runtime += delta_exec;
        se->sum_exec_runtime += delta_exec;

        /* Update CPU virtual time */
        update_cpu_vtime(wfs_rq, delta_exec);

        /* Update virtual runtime continuously */
        update_vruntime(se, delta_exec);

        se->exec_start = now;
    }
}

static void task_tick_wfs(struct rq *rq, struct task_struct *p, int queued)
{
    struct wfs_rq *wfs_rq = &rq->wfs;
    struct sched_wfs_entity *se = &p->wfs;
    int cpu = cpu_of(rq);

    printk(KERN_DEBUG "WFS: TASK_TICK PID %d on CPU %d (queued=%d), VFT=%llu, %u tasks in queue\n",
           p->pid, cpu, queued, se->vft, wfs_rq->wfs_nr_running);

    /* Update runtime stats first */
    update_curr_wfs(rq);

    /*
     * WFS: each task runs for exactly 1 tick quantum
     * Always preempt after 1 tick if there are other tasks
     */
    if (wfs_rq->wfs_nr_running > 1) {
        printk(KERN_DEBUG "WFS: Multiple tasks (%u) - preempting PID %d after 1 tick, VFT=%llu\n",
               wfs_rq->wfs_nr_running, p->pid, se->vft);

        /* Trigger a reschedule - put_prev_task will handle repositioning */
        resched_curr(rq);

        printk(KERN_DEBUG "WFS: Task PID %d preempted, will be repositioned based on updated VFT\n", p->pid);
    }
}

static void switched_to_wfs(struct rq *rq, struct task_struct *p)
{
    struct wfs_rq *wfs_rq = &rq->wfs;
    int cpu = cpu_of(rq);
    
    printk(KERN_INFO "WFS: Task PID %d SWITCHED_TO WFS class on CPU %d, %u tasks in queue\n", 
           p->pid, cpu, wfs_rq->wfs_nr_running);
    
    /* If this task should preempt current task */
    if (rq->curr != p && rq->curr->sched_class == &wfs_sched_class)
        resched_curr(rq);
}

static void switched_from_wfs(struct rq *rq, struct task_struct *p)
{
    struct wfs_rq *wfs_rq = &rq->wfs;
    int cpu = cpu_of(rq);
    
    printk(KERN_INFO "WFS: Task PID %d SWITCHED_FROM WFS class on CPU %d, %u tasks in queue\n", 
           p->pid, cpu, wfs_rq->wfs_nr_running);
    
    /* Clean up when task leaves WFS */
    if (p->wfs.exec_start) {
        u64 delta_exec = rq_clock_task(rq) - p->wfs.exec_start;
        p->se.sum_exec_runtime += delta_exec;
        update_cpu_vtime(&rq->wfs, delta_exec);
        p->wfs.exec_start = 0;
    }
}

static void check_preempt_curr_wfs(struct rq *rq, struct task_struct *p, int flags)
{
    /* For now, WFS is non-preemptive except for round-robin in task_tick */
    /* Could add preemption logic here if needed */
    printk(KERN_DEBUG "WFS: check_preempt_curr called for PID %d (flags=%d)\n", 
           p->pid, flags);
}

static void wakeup_preempt_wfs(struct rq *rq, struct task_struct *p, int flags)
{
    /* 
     * Called when a task wakes up to determine if it should preempt current task.
     * For WFS round-robin, we don't do immediate preemption on wakeup.
     * Tasks will be scheduled in round-robin order via task_tick.
     */
    printk(KERN_DEBUG "WFS: wakeup_preempt called for PID %d (flags=%d)\n", 
           p->pid, flags);
}

void init_wfs_rq(struct wfs_rq *wfs_rq)
{
    INIT_LIST_HEAD(&wfs_rq->queue);
    wfs_rq->tasks_timeline = RB_ROOT_CACHED;
    wfs_rq->wfs_nr_running = 0;
    wfs_rq->min_vruntime = 0;
    printk(KERN_INFO "WFS: Runqueue initialized\n");
}

/* Initialize WFS subsystem */
void init_wfs_system(void)
{
    int cpu;
    
    for_each_possible_cpu(cpu) {
        init_wfs_cpu_data(cpu);
    }
    
    printk(KERN_INFO "WFS: System initialized for %d CPUs\n", num_possible_cpus());
}

/* Enhanced SMP hooks for wfs scheduler */

static int select_task_rq_wfs(struct task_struct *p, int cpu, int flags)
{
    int best_cpu;
    
    /* Find CPU with minimum total weight */
    best_cpu = find_min_weight_cpu(p);
    
    printk(KERN_DEBUG "WFS: select_task_rq for PID %d: chose CPU %d (was %d)\n",
           p->pid, best_cpu, cpu);
    
    return best_cpu;
}

static int balance_wfs(struct rq *rq, struct task_struct *prev, struct rq_flags *rf)
{
    /* No-op balancing for now - load balancing happens at task placement */
    return 0;
}

static void migrate_task_rq_wfs(struct task_struct *p, int new_cpu)
{
    struct sched_wfs_entity *se = &p->wfs;
    int old_cpu = se->assigned_cpu;
    
    if (old_cpu != new_cpu && se->weight > 0) {
        /* Remove weight from old CPU and add to new CPU */
        if (old_cpu >= 0 && old_cpu < nr_cpu_ids) {
            struct rq *old_rq = cpu_rq(old_cpu);
            remove_task_from_cpu_weight(&old_rq->wfs, se->weight);
        }
        
        struct rq *new_rq = cpu_rq(new_cpu);
        add_task_to_cpu_weight(&new_rq->wfs, se->weight);
        se->assigned_cpu = new_cpu;
        
        printk(KERN_DEBUG "WFS: Task PID %d migrated from CPU %d to CPU %d, weight=%llu\n",
               p->pid, old_cpu, new_cpu, se->weight);
    }
}

static void rq_online_wfs(struct rq *rq)
{
    int cpu = cpu_of(rq);
    init_wfs_cpu_data(cpu);
    printk(KERN_INFO "WFS: CPU %d came online\n", cpu);
}

static void rq_offline_wfs(struct rq *rq)
{
    int cpu = cpu_of(rq);
    struct wfs_cpu_data *cpu_data = &per_cpu(wfs_cpu_data, cpu);
    
    printk(KERN_INFO "WFS: CPU %d going offline, had total weight %llu\n",
           cpu, cpu_data->cpu_total_weight);
}

static void task_woken_wfs(struct rq *rq, struct task_struct *p)
{
    /* No-op - nothing to do after remote wakeup */
}

static void set_cpus_allowed_wfs(struct task_struct *p, struct affinity_context *ctx)
{
    /* Could implement logic to rebalance if affinity changes */
    printk(KERN_DEBUG "WFS: CPU affinity changed for PID %d\n", p->pid);
}

static bool yield_to_task_wfs(struct rq *rq, struct task_struct *p)
{
    /* Return false - don't handle yield_to */
    return false;
}

const struct sched_class wfs_sched_class __section("__wfs_sched_class") = {
    .enqueue_task = enqueue_task_wfs,
    .dequeue_task = dequeue_task_wfs,
    .pick_task = pick_task_wfs,
    .put_prev_task = put_prev_task_wfs,
    .set_next_task = set_next_task_wfs,
    .task_tick = task_tick_wfs,
    .switched_to = switched_to_wfs,
    .switched_from = switched_from_wfs,
    .wakeup_preempt = wakeup_preempt_wfs,
    .update_curr = update_curr_wfs,
    .yield_to_task = yield_to_task_wfs,

#ifdef CONFIG_SMP
    .balance = balance_wfs,
    .select_task_rq = select_task_rq_wfs,
    .migrate_task_rq = migrate_task_rq_wfs,
    .rq_online = rq_online_wfs,
    .rq_offline = rq_offline_wfs,
    .task_woken = task_woken_wfs,
    .set_cpus_allowed = set_cpus_allowed_wfs,
#endif
};
/* 6118 */
````

Let me complete updating the rq_offline_wfs function to use wfs_rq instead of the separate per-CPU structure:

**Enhanced WFS Scheduler with CPU Load Balancing** ∙ Version 12

````c
/* 6118 */
#include <linux/mmu_context.h>
#include "sched.h"
#include "wfs.h"

/* No separate per-CPU structure needed - using wfs_rq instead */

/* Find the CPU with minimum total weight */
static int find_min_weight_cpu(struct task_struct *p)
{
    int cpu, best_cpu = -1;
    u64 min_weight = ULLONG_MAX;
    const struct cpumask *allowed_mask = tsk_cpus_allowed(p);
    
    for_each_cpu(cpu, allowed_mask) {
        struct rq *cpu_rq = cpu_rq(cpu);
        struct wfs_rq *wfs_rq = &cpu_rq->wfs;
        
        /* Skip offline CPUs */
        if (!cpu_online(cpu))
            continue;
            
        /* Find CPU with minimum weight, breaking ties with lowest CPU number */
        if (wfs_rq->cpu_total_weight < min_weight) {
            min_weight = wfs_rq->cpu_total_weight;
            best_cpu = cpu;
        }
    }
    
    /* Fallback to current CPU if no suitable CPU found */
    if (best_cpu == -1)
        best_cpu = smp_processor_id();
        
    return best_cpu;
}

/* Add task weight to CPU's total weight */
static void add_task_to_cpu_weight(struct wfs_rq *wfs_rq, u64 weight)
{
    wfs_rq->cpu_total_weight += weight;
    
    printk(KERN_DEBUG "WFS: Added weight %llu to CPU, total weight now %llu\n",
           weight, wfs_rq->cpu_total_weight);
}

/* Remove task weight from CPU's total weight */
static void remove_task_from_cpu_weight(struct wfs_rq *wfs_rq, u64 weight)
{
    if (wfs_rq->cpu_total_weight >= weight) {
        wfs_rq->cpu_total_weight -= weight;
    } else {
        printk(KERN_WARNING "WFS: CPU weight underflow, resetting to 0\n");
        wfs_rq->cpu_total_weight = 0;
    }
    
    printk(KERN_DEBUG "WFS: Removed weight %llu from CPU, total weight now %llu\n",
           weight, wfs_rq->cpu_total_weight);
}

/* Update CPU virtual time based on execution time */
static void update_cpu_vtime(struct wfs_rq *wfs_rq, u64 delta_exec)
{
    if (wfs_rq->cpu_total_weight > 0) {
        u64 vtime_delta = (delta_exec * WFS_SCALE_FACTOR) / wfs_rq->cpu_total_weight;
        wfs_rq->cpu_vtime += vtime_delta;
        
        printk(KERN_DEBUG "WFS: CPU vtime updated by %llu, now %llu (weight=%llu)\n",
               vtime_delta, wfs_rq->cpu_vtime, wfs_rq->cpu_total_weight);
    }
}

/* Get current CPU virtual time */
static u64 get_cpu_vtime(struct wfs_rq *wfs_rq)
{
    return wfs_rq->cpu_vtime;
}

/* Update virtual runtime and VFT for a task */
static void update_vruntime(struct sched_wfs_entity *se, u64 delta_exec)
{
    u64 vdelta = calc_delta_fair(delta_exec, se);
    se->vruntime += vdelta;
    
    /* Calculate VFT = vruntime + (1 tick scaled) / weight */
    u64 tick_ns = TICK_NSEC; /* Duration of 1 tick in nanoseconds */
    u64 scaled_tick = calc_delta_fair(tick_ns, se);
    se->vft = se->vruntime + scaled_tick;
}

/* Initialize virtual time for new tasks */
static void place_entity(struct wfs_rq *wfs_rq, struct sched_wfs_entity *se, int cpu)
{
    /* Initialize weight if not set */
    if (!se->weight) {
        se->weight = WFS_DEFAULT_WEIGHT;
        se->inv_weight = WFS_SCALE_FACTOR / se->weight;
    }
    
    /* Set task's virtual time to current CPU virtual time */
    se->vruntime = get_cpu_vtime(wfs_rq);
    
    /* If this is greater than min_vruntime, use min_vruntime to prevent starvation */
    if (se->vruntime < wfs_rq->min_vruntime) {
        se->vruntime = wfs_rq->min_vruntime;
    }
    
    /* Calculate initial VFT */
    u64 tick_ns = TICK_NSEC;
    u64 scaled_tick = calc_delta_fair(tick_ns, se);
    se->vft = se->vruntime + scaled_tick;
    
    /* Record which CPU this task is assigned to */
    se->assigned_cpu = cpu;
    
    printk(KERN_DEBUG "WFS: Task placed with vruntime=%llu, VFT=%llu on CPU %d (CPU vtime=%llu)\n",
           se->vruntime, se->vft, cpu, get_cpu_vtime(wfs_rq));
}

/* Update min_vruntime for the runqueue */
static void update_min_vruntime(struct wfs_rq *wfs_rq)
{
    struct rb_node *leftmost = rb_first_cached(&wfs_rq->tasks_timeline);
    u64 vruntime = wfs_rq->min_vruntime;

    if (leftmost) {
        struct sched_wfs_entity *se = rb_entry(leftmost, struct sched_wfs_entity, run_node);
        vruntime = se->vruntime;
    }

    /* min_vruntime should never go backwards */
    wfs_rq->min_vruntime = max(wfs_rq->min_vruntime, vruntime);
}

/* Main scheduler functions */

static void enqueue_task_wfs(struct rq *rq, struct task_struct *p, int flags)
{
    struct wfs_rq *wfs_rq = &rq->wfs;
    struct sched_wfs_entity *se = &p->wfs;
    int cpu = cpu_of(rq);

    /* Only add if not already on RB-tree */
    if (RB_EMPTY_NODE(&se->run_node)) {
        /* Initialize virtual time for new or waking tasks */
        if (!(flags & ENQUEUE_WAKEUP) || se->vruntime == 0) {
            place_entity(wfs_rq, se, cpu);
        } else {
            /* Waking task - recalculate VFT based on current vruntime */
            u64 tick_ns = TICK_NSEC;
            u64 scaled_tick = calc_delta_fair(tick_ns, se);
            se->vft = se->vruntime + scaled_tick;
        }

        /* Add task weight to CPU's total weight */
        add_task_to_cpu_weight(wfs_rq, se->weight);

        /* Insert into RB-tree ordered by VFT */
        rb_add_cached(&se->run_node, &wfs_rq->tasks_timeline, wfs_entity_before);

        wfs_rq->wfs_nr_running++;

        /* Also add to list for compatibility */
        if (list_empty(&se->run_list)) {
            list_add_tail(&se->run_list, &wfs_rq->queue);
        }

        update_min_vruntime(wfs_rq);

        printk(KERN_INFO "WFS: PID %d ENQUEUED on CPU %d (flags=%d), vruntime=%llu, VFT=%llu, weight=%llu, runqueue now has %u tasks\n",
               p->pid, cpu, flags, se->vruntime, se->vft, se->weight, wfs_rq->wfs_nr_running);
    } else {
        printk(KERN_WARNING "WFS: PID %d already on runqueue, skipping enqueue\n", p->pid);
    }
}

static bool dequeue_task_wfs(struct rq *rq, struct task_struct *p, int flags)
{
    struct wfs_rq *wfs_rq = &rq->wfs;
    struct sched_wfs_entity *se = &p->wfs;
    int cpu = cpu_of(rq);

    /* Only remove if actually in RB-tree */
    if (!RB_EMPTY_NODE(&se->run_node)) {
        /* Remove task weight from CPU's total weight */
        remove_task_from_cpu_weight(wfs_rq, se->weight);

        rb_erase_cached(&se->run_node, &wfs_rq->tasks_timeline);
        RB_CLEAR_NODE(&se->run_node);

        wfs_rq->wfs_nr_running--;

        /* Also remove from list */
        if (!list_empty(&se->run_list)) {
            list_del_init(&se->run_list);
        }

        update_min_vruntime(wfs_rq);

        printk(KERN_INFO "WFS: PID %d DEQUEUED from CPU %d (flags=%d), weight=%llu, runqueue now has %u tasks\n",
               p->pid, cpu, flags, se->weight, wfs_rq->wfs_nr_running);
    } else {
        printk(KERN_WARNING "WFS: PID %d not on runqueue, skipping dequeue\n", p->pid);
    }
    return true;
}

static struct task_struct *pick_task_wfs(struct rq *rq)
{
    struct wfs_rq *wfs_rq = &rq->wfs;
    struct sched_wfs_entity *wfs_se;
    struct task_struct *next_task;
    struct rb_node *leftmost;
    
    /* Check if we have any WFS tasks */
    if (!wfs_rq->wfs_nr_running) {
        return NULL;
    }
    
    /* Get the leftmost node (minimum VFT) from RB-tree */
    leftmost = rb_first_cached(&wfs_rq->tasks_timeline);
    if (!leftmost) {
        /* This shouldn't happen if wfs_nr_running > 0, but be safe */
        printk(KERN_WARNING "WFS: RB-tree empty but wfs_nr_running=%u, fixing\n",
               wfs_rq->wfs_nr_running);
        wfs_rq->wfs_nr_running = 0;
        return NULL;
    }
    
    wfs_se = rb_entry(leftmost, struct sched_wfs_entity, run_node);
    next_task = task_of_wfs(wfs_se);
    
    printk(KERN_DEBUG "WFS: PICKED task PID %d, VFT=%llu, weight=%llu, %u tasks in queue\n",
           next_task->pid, wfs_se->vft, wfs_se->weight, wfs_rq->wfs_nr_running);
    
    return next_task;
}

static void put_prev_task_wfs(struct rq *rq, struct task_struct *p, struct task_struct *next)
{
    struct sched_wfs_entity *se = &p->wfs;
    u64 now = rq_clock_task(rq);
    int cpu = cpu_of(rq);
    
    printk(KERN_DEBUG "WFS: PUT_PREV task PID %d on CPU %d (next is PID %d)\n",
           p->pid, cpu, next ? next->pid : -1);
    
    /* Update execution time and virtual runtime */
    if (se->exec_start) {
        u64 delta_exec = now - se->exec_start;
        
        /* Update total runtime */
        p->se.sum_exec_runtime += delta_exec;
        se->sum_exec_runtime += delta_exec;
        
        /* Update CPU virtual time */
        update_cpu_vtime(wfs_rq, delta_exec);
        
        /* Update virtual runtime and recalculate VFT */
        update_vruntime(se, delta_exec);
        
        se->exec_start = 0;
        
        /* If task is still runnable, we need to reposition it in RB-tree */
        if (next != p && !RB_EMPTY_NODE(&se->run_node)) {
            struct wfs_rq *wfs_rq = &rq->wfs;
            
            /* Remove from current position */
            rb_erase_cached(&se->run_node, &wfs_rq->tasks_timeline);
            
            /* Re-insert at new position based on updated VFT */
            rb_add_cached(&se->run_node, &wfs_rq->tasks_timeline, wfs_entity_before);
            
            update_min_vruntime(wfs_rq);
            
            printk(KERN_DEBUG "WFS: Task PID %d repositioned in RB-tree, new VFT=%llu\n",
                   p->pid, se->vft);
        }
    }
}

static void set_next_task_wfs(struct rq *rq, struct task_struct *p, bool first)
{
    struct wfs_rq *wfs_rq = &rq->wfs;
    int cpu = cpu_of(rq);
    
    p->wfs.exec_start = rq_clock_task(rq);
    
    printk(KERN_DEBUG "WFS: SET_NEXT task PID %d on CPU %d (first=%d), %u tasks in queue\n", 
           p->pid, cpu, first, wfs_rq->wfs_nr_running);
}

static void update_curr_wfs(struct rq *rq)
{
    struct task_struct *curr = rq->curr;
    struct sched_wfs_entity *se;
    u64 now = rq_clock_task(rq);
    int cpu = cpu_of(rq);

    if (curr->sched_class != &wfs_sched_class)
        return;

    se = &curr->wfs;

    if (se->exec_start) {
        u64 delta_exec = now - se->exec_start;

        /* Update total runtime */
        curr->se.sum_exec_runtime += delta_exec;
        se->sum_exec_runtime += delta_exec;

        /* Update CPU virtual time */
        update_cpu_vtime(wfs_rq, delta_exec);

        /* Update virtual runtime continuously */
        update_vruntime(se, delta_exec);

        se->exec_start = now;
    }
}

static void task_tick_wfs(struct rq *rq, struct task_struct *p, int queued)
{
    struct wfs_rq *wfs_rq = &rq->wfs;
    struct sched_wfs_entity *se = &p->wfs;
    int cpu = cpu_of(rq);

    printk(KERN_DEBUG "WFS: TASK_TICK PID %d on CPU %d (queued=%d), VFT=%llu, %u tasks in queue\n",
           p->pid, cpu, queued, se->vft, wfs_rq->wfs_nr_running);

    /* Update runtime stats first */
    update_curr_wfs(rq);

    /*
     * WFS: each task runs for exactly 1 tick quantum
     * Always preempt after 1 tick if there are other tasks
     */
    if (wfs_rq->wfs_nr_running > 1) {
        printk(KERN_DEBUG "WFS: Multiple tasks (%u) - preempting PID %d after 1 tick, VFT=%llu\n",
               wfs_rq->wfs_nr_running, p->pid, se->vft);

        /* Trigger a reschedule - put_prev_task will handle repositioning */
        resched_curr(rq);

        printk(KERN_DEBUG "WFS: Task PID %d preempted, will be repositioned based on updated VFT\n", p->pid);
    }
}

static void switched_to_wfs(struct rq *rq, struct task_struct *p)
{
    struct wfs_rq *wfs_rq = &rq->wfs;
    int cpu = cpu_of(rq);
    
    printk(KERN_INFO "WFS: Task PID %d SWITCHED_TO WFS class on CPU %d, %u tasks in queue\n", 
           p->pid, cpu, wfs_rq->wfs_nr_running);
    
    /* If this task should preempt current task */
    if (rq->curr != p && rq->curr->sched_class == &wfs_sched_class)
        resched_curr(rq);
}

static void switched_from_wfs(struct rq *rq, struct task_struct *p)
{
    struct wfs_rq *wfs_rq = &rq->wfs;
    int cpu = cpu_of(rq);
    
    printk(KERN_INFO "WFS: Task PID %d SWITCHED_FROM WFS class on CPU %d, %u tasks in queue\n", 
           p->pid, cpu, wfs_rq->wfs_nr_running);
    
    /* Clean up when task leaves WFS */
    if (p->wfs.exec_start) {
        u64 delta_exec = rq_clock_task(rq) - p->wfs.exec_start;
        p->se.sum_exec_runtime += delta_exec;
        update_cpu_vtime(&rq->wfs, delta_exec);
        p->wfs.exec_start = 0;
    }
}

static void check_preempt_curr_wfs(struct rq *rq, struct task_struct *p, int flags)
{
    /* For now, WFS is non-preemptive except for round-robin in task_tick */
    /* Could add preemption logic here if needed */
    printk(KERN_DEBUG "WFS: check_preempt_curr called for PID %d (flags=%d)\n", 
           p->pid, flags);
}

static void wakeup_preempt_wfs(struct rq *rq, struct task_struct *p, int flags)
{
    /* 
     * Called when a task wakes up to determine if it should preempt current task.
     * For WFS round-robin, we don't do immediate preemption on wakeup.
     * Tasks will be scheduled in round-robin order via task_tick.
     */
    printk(KERN_DEBUG "WFS: wakeup_preempt called for PID %d (flags=%d)\n", 
           p->pid, flags);
}

void init_wfs_rq(struct wfs_rq *wfs_rq)
{
    INIT_LIST_HEAD(&wfs_rq->queue);
    wfs_rq->tasks_timeline = RB_ROOT_CACHED;
    wfs_rq->wfs_nr_running = 0;
    wfs_rq->min_vruntime = 0;
    printk(KERN_INFO "WFS: Runqueue initialized\n");
}

/* Initialize WFS subsystem */
void init_wfs_system(void)
{
    int cpu;
    
    for_each_possible_cpu(cpu) {
        init_wfs_cpu_data(cpu);
    }
    
    printk(KERN_INFO "WFS: System initialized for %d CPUs\n", num_possible_cpus());
}

/* Enhanced SMP hooks for wfs scheduler */

static int select_task_rq_wfs(struct task_struct *p, int cpu, int flags)
{
    int best_cpu;
    
    /* Find CPU with minimum total weight */
    best_cpu = find_min_weight_cpu(p);
    
    printk(KERN_DEBUG "WFS: select_task_rq for PID %d: chose CPU %d (was %d)\n",
           p->pid, best_cpu, cpu);
    
    return best_cpu;
}

static int balance_wfs(struct rq *rq, struct task_struct *prev, struct rq_flags *rf)
{
    /* No-op balancing for now - load balancing happens at task placement */
    return 0;
}

static void migrate_task_rq_wfs(struct task_struct *p, int new_cpu)
{
    struct sched_wfs_entity *se = &p->wfs;
    int old_cpu = se->assigned_cpu;
    
    if (old_cpu != new_cpu && se->weight > 0) {
        /* Remove weight from old CPU and add to new CPU */
        if (old_cpu >= 0 && old_cpu < nr_cpu_ids) {
            struct rq *old_rq = cpu_rq(old_cpu);
            remove_task_from_cpu_weight(&old_rq->wfs, se->weight);
        }
        
        struct rq *new_rq = cpu_rq(new_cpu);
        add_task_to_cpu_weight(&new_rq->wfs, se->weight);
        se->assigned_cpu = new_cpu;
        
        printk(KERN_DEBUG "WFS: Task PID %d migrated from CPU %d to CPU %d, weight=%llu\n",
               p->pid, old_cpu, new_cpu, se->weight);
    }
}

static void rq_online_wfs(struct rq *rq)
{
    int cpu = cpu_of(rq);
    init_wfs_cpu_data(cpu);
    printk(KERN_INFO "WFS: CPU %d came online\n", cpu);
}

static void rq_offline_wfs(struct rq *rq)
{
    int cpu = cpu_of(rq);
    struct wfs_rq *wfs_rq = &rq->wfs;
    
    printk(KERN_INFO "WFS: CPU %d going offline, had total weight %llu\n",
           cpu, wfs_rq->cpu_total_weight);
}

static void task_woken_wfs(struct rq *rq, struct task_struct *p)
{
    /* No-op - nothing to do after remote wakeup */
}

static void set_cpus_allowed_wfs(struct task_struct *p, struct affinity_context *ctx)
{
    /* Could implement logic to rebalance if affinity changes */
    printk(KERN_DEBUG "WFS: CPU affinity changed for PID %d\n", p->pid);
}

static bool yield_to_task_wfs(struct rq *rq, struct task_struct *p)
{
    /* Return false - don't handle yield_to */
    return false;
}

const struct sched_class wfs_sched_class __section("__wfs_sched_class") = {
    .enqueue_task = enqueue_task_wfs,
    .dequeue_task = dequeue_task_wfs,
    .pick_task = pick_task_wfs,
    .put_prev_task = put_prev_task_wfs,
    .set_next_task = set_next_task_wfs,
    .task_tick = task_tick_wfs,
    .switched_to = switched_to_wfs,
    .switched_from = switched_from_wfs,
    .wakeup_preempt = wakeup_preempt_wfs,
    .update_curr = update_curr_wfs,
    .yield_to_task = yield_to_task_wfs,

#ifdef CONFIG_SMP
    .balance = balance_wfs,
    .select_task_rq = select_task_rq_wfs,
    .migrate_task_rq = migrate_task_rq_wfs,
    .rq_online = rq_online_wfs,
    .rq_offline = rq_offline_wfs,
    .task_woken = task_woken_wfs,
    .set_cpus_allowed = set_cpus_allowed_wfs,
#endif
};
/* 6118 */
````

Let me clean up the initialization function:

**Enhanced WFS Scheduler with CPU Load Balancing** ∙ Version 13

````c
/* 6118 */
#include <linux/mmu_context.h>
#include "sched.h"
#include "wfs.h"

/* No separate per-CPU structure needed - using wfs_rq instead */

/* Find the CPU with minimum total weight */
static int find_min_weight_cpu(struct task_struct *p)
{
    int cpu, best_cpu = -1;
    u64 min_weight = ULLONG_MAX;
    const struct cpumask *allowed_mask = tsk_cpus_allowed(p);
    
    for_each_cpu(cpu, allowed_mask) {
        struct rq *cpu_rq = cpu_rq(cpu);
        struct wfs_rq *wfs_rq = &cpu_rq->wfs;
        
        /* Skip offline CPUs */
        if (!cpu_online(cpu))
            continue;
            
        /* Find CPU with minimum weight, breaking ties with lowest CPU number */
        if (wfs_rq->cpu_total_weight < min_weight) {
            min_weight = wfs_rq->cpu_total_weight;
            best_cpu = cpu;
        }
    }
    
    /* Fallback to current CPU if no suitable CPU found */
    if (best_cpu == -1)
        best_cpu = smp_processor_id();
        
    return best_cpu;
}

/* Add task weight to CPU's total weight */
static void add_task_to_cpu_weight(struct wfs_rq *wfs_rq, u64 weight)
{
    wfs_rq->cpu_total_weight += weight;
    
    printk(KERN_DEBUG "WFS: Added weight %llu to CPU, total weight now %llu\n",
           weight, wfs_rq->cpu_total_weight);
}

/* Remove task weight from CPU's total weight */
static void remove_task_from_cpu_weight(struct wfs_rq *wfs_rq, u64 weight)
{
    if (wfs_rq->cpu_total_weight >= weight) {
        wfs_rq->cpu_total_weight -= weight;
    } else {
        printk(KERN_WARNING "WFS: CPU weight underflow, resetting to 0\n");
        wfs_rq->cpu_total_weight = 0;
    }
    
    printk(KERN_DEBUG "WFS: Removed weight %llu from CPU, total weight now %llu\n",
           weight, wfs_rq->cpu_total_weight);
}

/* Update CPU virtual time based on execution time */
static void update_cpu_vtime(struct wfs_rq *wfs_rq, u64 delta_exec)
{
    if (wfs_rq->cpu_total_weight > 0) {
        u64 vtime_delta = (delta_exec * WFS_SCALE_FACTOR) / wfs_rq->cpu_total_weight;
        wfs_rq->cpu_vtime += vtime_delta;
        
        printk(KERN_DEBUG "WFS: CPU vtime updated by %llu, now %llu (weight=%llu)\n",
               vtime_delta, wfs_rq->cpu_vtime, wfs_rq->cpu_total_weight);
    }
}

/* Get current CPU virtual time */
static u64 get_cpu_vtime(struct wfs_rq *wfs_rq)
{
    return wfs_rq->cpu_vtime;
}

/* Update virtual runtime and VFT for a task */
static void update_vruntime(struct sched_wfs_entity *se, u64 delta_exec)
{
    u64 vdelta = calc_delta_fair(delta_exec, se);
    se->vruntime += vdelta;
    
    /* Calculate VFT = vruntime + (1 tick scaled) / weight */
    u64 tick_ns = TICK_NSEC; /* Duration of 1 tick in nanoseconds */
    u64 scaled_tick = calc_delta_fair(tick_ns, se);
    se->vft = se->vruntime + scaled_tick;
}

/* Initialize virtual time for new tasks */
static void place_entity(struct wfs_rq *wfs_rq, struct sched_wfs_entity *se, int cpu)
{
    /* Initialize weight if not set */
    if (!se->weight) {
        se->weight = WFS_DEFAULT_WEIGHT;
        se->inv_weight = WFS_SCALE_FACTOR / se->weight;
    }
    
    /* Set task's virtual time to current CPU virtual time */
    se->vruntime = get_cpu_vtime(wfs_rq);
    
    /* If this is greater than min_vruntime, use min_vruntime to prevent starvation */
    if (se->vruntime < wfs_rq->min_vruntime) {
        se->vruntime = wfs_rq->min_vruntime;
    }
    
    /* Calculate initial VFT */
    u64 tick_ns = TICK_NSEC;
    u64 scaled_tick = calc_delta_fair(tick_ns, se);
    se->vft = se->vruntime + scaled_tick;
    
    /* Record which CPU this task is assigned to */
    se->assigned_cpu = cpu;
    
    printk(KERN_DEBUG "WFS: Task placed with vruntime=%llu, VFT=%llu on CPU %d (CPU vtime=%llu)\n",
           se->vruntime, se->vft, cpu, get_cpu_vtime(wfs_rq));
}

/* Update min_vruntime for the runqueue */
static void update_min_vruntime(struct wfs_rq *wfs_rq)
{
    struct rb_node *leftmost = rb_first_cached(&wfs_rq->tasks_timeline);
    u64 vruntime = wfs_rq->min_vruntime;

    if (leftmost) {
        struct sched_wfs_entity *se = rb_entry(leftmost, struct sched_wfs_entity, run_node);
        vruntime = se->vruntime;
    }

    /* min_vruntime should never go backwards */
    wfs_rq->min_vruntime = max(wfs_rq->min_vruntime, vruntime);
}

/* Main scheduler functions */

static void enqueue_task_wfs(struct rq *rq, struct task_struct *p, int flags)
{
    struct wfs_rq *wfs_rq = &rq->wfs;
    struct sched_wfs_entity *se = &p->wfs;
    int cpu = cpu_of(rq);

    /* Only add if not already on RB-tree */
    if (RB_EMPTY_NODE(&se->run_node)) {
        /* Initialize virtual time for new or waking tasks */
        if (!(flags & ENQUEUE_WAKEUP) || se->vruntime == 0) {
            place_entity(wfs_rq, se, cpu);
        } else {
            /* Waking task - recalculate VFT based on current vruntime */
            u64 tick_ns = TICK_NSEC;
            u64 scaled_tick = calc_delta_fair(tick_ns, se);
            se->vft = se->vruntime + scaled_tick;
        }

        /* Add task weight to CPU's total weight */
        add_task_to_cpu_weight(wfs_rq, se->weight);

        /* Insert into RB-tree ordered by VFT */
        rb_add_cached(&se->run_node, &wfs_rq->tasks_timeline, wfs_entity_before);

        wfs_rq->wfs_nr_running++;

        /* Also add to list for compatibility */
        if (list_empty(&se->run_list)) {
            list_add_tail(&se->run_list, &wfs_rq->queue);
        }

        update_min_vruntime(wfs_rq);

        printk(KERN_INFO "WFS: PID %d ENQUEUED on CPU %d (flags=%d), vruntime=%llu, VFT=%llu, weight=%llu, runqueue now has %u tasks\n",
               p->pid, cpu, flags, se->vruntime, se->vft, se->weight, wfs_rq->wfs_nr_running);
    } else {
        printk(KERN_WARNING "WFS: PID %d already on runqueue, skipping enqueue\n", p->pid);
    }
}

static bool dequeue_task_wfs(struct rq *rq, struct task_struct *p, int flags)
{
    struct wfs_rq *wfs_rq = &rq->wfs;
    struct sched_wfs_entity *se = &p->wfs;
    int cpu = cpu_of(rq);

    /* Only remove if actually in RB-tree */
    if (!RB_EMPTY_NODE(&se->run_node)) {
        /* Remove task weight from CPU's total weight */
        remove_task_from_cpu_weight(wfs_rq, se->weight);

        rb_erase_cached(&se->run_node, &wfs_rq->tasks_timeline);
        RB_CLEAR_NODE(&se->run_node);

        wfs_rq->wfs_nr_running--;

        /* Also remove from list */
        if (!list_empty(&se->run_list)) {
            list_del_init(&se->run_list);
        }

        update_min_vruntime(wfs_rq);

        printk(KERN_INFO "WFS: PID %d DEQUEUED from CPU %d (flags=%d), weight=%llu, runqueue now has %u tasks\n",
               p->pid, cpu, flags, se->weight, wfs_rq->wfs_nr_running);
    } else {
        printk(KERN_WARNING "WFS: PID %d not on runqueue, skipping dequeue\n", p->pid);
    }
    return true;
}

static struct task_struct *pick_task_wfs(struct rq *rq)
{
    struct wfs_rq *wfs_rq = &rq->wfs;
    struct sched_wfs_entity *wfs_se;
    struct task_struct *next_task;
    struct rb_node *leftmost;
    
    /* Check if we have any WFS tasks */
    if (!wfs_rq->wfs_nr_running) {
        return NULL;
    }
    
    /* Get the leftmost node (minimum VFT) from RB-tree */
    leftmost = rb_first_cached(&wfs_rq->tasks_timeline);
    if (!leftmost) {
        /* This shouldn't happen if wfs_nr_running > 0, but be safe */
        printk(KERN_WARNING "WFS: RB-tree empty but wfs_nr_running=%u, fixing\n",
               wfs_rq->wfs_nr_running);
        wfs_rq->wfs_nr_running = 0;
        return NULL;
    }
    
    wfs_se = rb_entry(leftmost, struct sched_wfs_entity, run_node);
    next_task = task_of_wfs(wfs_se);
    
    printk(KERN_DEBUG "WFS: PICKED task PID %d, VFT=%llu, weight=%llu, %u tasks in queue\n",
           next_task->pid, wfs_se->vft, wfs_se->weight, wfs_rq->wfs_nr_running);
    
    return next_task;
}

static void put_prev_task_wfs(struct rq *rq, struct task_struct *p, struct task_struct *next)
{
    struct sched_wfs_entity *se = &p->wfs;
    u64 now = rq_clock_task(rq);
    int cpu = cpu_of(rq);
    
    printk(KERN_DEBUG "WFS: PUT_PREV task PID %d on CPU %d (next is PID %d)\n",
           p->pid, cpu, next ? next->pid : -1);
    
    /* Update execution time and virtual runtime */
    if (se->exec_start) {
        u64 delta_exec = now - se->exec_start;
        
        /* Update total runtime */
        p->se.sum_exec_runtime += delta_exec;
        se->sum_exec_runtime += delta_exec;
        
        /* Update CPU virtual time */
        update_cpu_vtime(wfs_rq, delta_exec);
        
        /* Update virtual runtime and recalculate VFT */
        update_vruntime(se, delta_exec);
        
        se->exec_start = 0;
        
        /* If task is still runnable, we need to reposition it in RB-tree */
        if (next != p && !RB_EMPTY_NODE(&se->run_node)) {
            struct wfs_rq *wfs_rq = &rq->wfs;
            
            /* Remove from current position */
            rb_erase_cached(&se->run_node, &wfs_rq->tasks_timeline);
            
            /* Re-insert at new position based on updated VFT */
            rb_add_cached(&se->run_node, &wfs_rq->tasks_timeline, wfs_entity_before);
            
            update_min_vruntime(wfs_rq);
            
            printk(KERN_DEBUG "WFS: Task PID %d repositioned in RB-tree, new VFT=%llu\n",
                   p->pid, se->vft);
        }
    }
}

static void set_next_task_wfs(struct rq *rq, struct task_struct *p, bool first)
{
    struct wfs_rq *wfs_rq = &rq->wfs;
    int cpu = cpu_of(rq);
    
    p->wfs.exec_start = rq_clock_task(rq);
    
    printk(KERN_DEBUG "WFS: SET_NEXT task PID %d on CPU %d (first=%d), %u tasks in queue\n", 
           p->pid, cpu, first, wfs_rq->wfs_nr_running);
}

static void update_curr_wfs(struct rq *rq)
{
    struct task_struct *curr = rq->curr;
    struct sched_wfs_entity *se;
    u64 now = rq_clock_task(rq);
    int cpu = cpu_of(rq);

    if (curr->sched_class != &wfs_sched_class)
        return;

    se = &curr->wfs;

    if (se->exec_start) {
        u64 delta_exec = now - se->exec_start;

        /* Update total runtime */
        curr->se.sum_exec_runtime += delta_exec;
        se->sum_exec_runtime += delta_exec;

        /* Update CPU virtual time */
        update_cpu_vtime(wfs_rq, delta_exec);

        /* Update virtual runtime continuously */
        update_vruntime(se, delta_exec);

        se->exec_start = now;
    }
}

static void task_tick_wfs(struct rq *rq, struct task_struct *p, int queued)
{
    struct wfs_rq *wfs_rq = &rq->wfs;
    struct sched_wfs_entity *se = &p->wfs;
    int cpu = cpu_of(rq);

    printk(KERN_DEBUG "WFS: TASK_TICK PID %d on CPU %d (queued=%d), VFT=%llu, %u tasks in queue\n",
           p->pid, cpu, queued, se->vft, wfs_rq->wfs_nr_running);

    /* Update runtime stats first */
    update_curr_wfs(rq);

    /*
     * WFS: each task runs for exactly 1 tick quantum
     * Always preempt after 1 tick if there are other tasks
     */
    if (wfs_rq->wfs_nr_running > 1) {
        printk(KERN_DEBUG "WFS: Multiple tasks (%u) - preempting PID %d after 1 tick, VFT=%llu\n",
               wfs_rq->wfs_nr_running, p->pid, se->vft);

        /* Trigger a reschedule - put_prev_task will handle repositioning */
        resched_curr(rq);

        printk(KERN_DEBUG "WFS: Task PID %d preempted, will be repositioned based on updated VFT\n", p->pid);
    }
}

static void switched_to_wfs(struct rq *rq, struct task_struct *p)
{
    struct wfs_rq *wfs_rq = &rq->wfs;
    int cpu = cpu_of(rq);
    
    printk(KERN_INFO "WFS: Task PID %d SWITCHED_TO WFS class on CPU %d, %u tasks in queue\n", 
           p->pid, cpu, wfs_rq->wfs_nr_running);
    
    /* If this task should preempt current task */
    if (rq->curr != p && rq->curr->sched_class == &wfs_sched_class)
        resched_curr(rq);
}

static void switched_from_wfs(struct rq *rq, struct task_struct *p)
{
    struct wfs_rq *wfs_rq = &rq->wfs;
    int cpu = cpu_of(rq);
    
    printk(KERN_INFO "WFS: Task PID %d SWITCHED_FROM WFS class on CPU %d, %u tasks in queue\n", 
           p->pid, cpu, wfs_rq->wfs_nr_running);
    
    /* Clean up when task leaves WFS */
    if (p->wfs.exec_start) {
        u64 delta_exec = rq_clock_task(rq) - p->wfs.exec_start;
        p->se.sum_exec_runtime += delta_exec;
        update_cpu_vtime(&rq->wfs, delta_exec);
        p->wfs.exec_start = 0;
    }
}

static void check_preempt_curr_wfs(struct rq *rq, struct task_struct *p, int flags)
{
    /* For now, WFS is non-preemptive except for round-robin in task_tick */
    /* Could add preemption logic here if needed */
    printk(KERN_DEBUG "WFS: check_preempt_curr called for PID %d (flags=%d)\n", 
           p->pid, flags);
}

static void wakeup_preempt_wfs(struct rq *rq, struct task_struct *p, int flags)
{
    /* 
     * Called when a task wakes up to determine if it should preempt current task.
     * For WFS round-robin, we don't do immediate preemption on wakeup.
     * Tasks will be scheduled in round-robin order via task_tick.
     */
    printk(KERN_DEBUG "WFS: wakeup_preempt called for PID %d (flags=%d)\n", 
           p->pid, flags);
}

void init_wfs_rq(struct wfs_rq *wfs_rq)
{
    INIT_LIST_HEAD(&wfs_rq->queue);
    wfs_rq->tasks_timeline = RB_ROOT_CACHED;
    wfs_rq->wfs_nr_running = 0;
    wfs_rq->min_vruntime = 0;
    wfs_rq->cpu_total_weight = 0;
    wfs_rq->cpu_vtime = 0;
    printk(KERN_INFO "WFS: Runqueue initialized\n");
}

/* Initialize WFS subsystem */
void init_wfs_system(void)
{
    int cpu;
    
    for_each_possible_cpu(cpu) {
        init_wfs_cpu_data(cpu);
    }
    
    printk(KERN_INFO "WFS: System initialized for %d CPUs\n", num_possible_cpus());
}

/* Enhanced SMP hooks for wfs scheduler */

static int select_task_rq_wfs(struct task_struct *p, int cpu, int flags)
{
    int best_cpu;
    
    /* Find CPU with minimum total weight */
    best_cpu = find_min_weight_cpu(p);
    
    printk(KERN_DEBUG "WFS: select_task_rq for PID %d: chose CPU %d (was %d)\n",
           p->pid, best_cpu, cpu);
    
    return best_cpu;
}

static int balance_wfs(struct rq *rq, struct task_struct *prev, struct rq_flags *rf)
{
    /* No-op balancing for now - load balancing happens at task placement */
    return 0;
}

static void migrate_task_rq_wfs(struct task_struct *p, int new_cpu)
{
    struct sched_wfs_entity *se = &p->wfs;
    int old_cpu = se->assigned_cpu;
    
    if (old_cpu != new_cpu && se->weight > 0) {
        /* Remove weight from old CPU and add to new CPU */
        if (old_cpu >= 0 && old_cpu < nr_cpu_ids) {
            struct rq *old_rq = cpu_rq(old_cpu);
            remove_task_from_cpu_weight(&old_rq->wfs, se->weight);
        }
        
        struct rq *new_rq = cpu_rq(new_cpu);
        add_task_to_cpu_weight(&new_rq->wfs, se->weight);
        se->assigned_cpu = new_cpu;
        
        printk(KERN_DEBUG "WFS: Task PID %d migrated from CPU %d to CPU %d, weight=%llu\n",
               p->pid, old_cpu, new_cpu, se->weight);
    }
}

static void rq_online_wfs(struct rq *rq)
{
    int cpu = cpu_of(rq);
    init_wfs_cpu_data(cpu);
    printk(KERN_INFO "WFS: CPU %d came online\n", cpu);
}

static void rq_offline_wfs(struct rq *rq)
{
    int cpu = cpu_of(rq);
    struct wfs_rq *wfs_rq = &rq->wfs;
    
    printk(KERN_INFO "WFS: CPU %d going offline, had total weight %llu\n",
           cpu, wfs_rq->cpu_total_weight);
}

static void task_woken_wfs(struct rq *rq, struct task_struct *p)
{
    /* No-op - nothing to do after remote wakeup */
}

static void set_cpus_allowed_wfs(struct task_struct *p, struct affinity_context *ctx)
{
    /* Could implement logic to rebalance if affinity changes */
    printk(KERN_DEBUG "WFS: CPU affinity changed for PID %d\n", p->pid);
}

static bool yield_to_task_wfs(struct rq *rq, struct task_struct *p)
{
    /* Return false - don't handle yield_to */
    return false;
}

const struct sched_class wfs_sched_class __section("__wfs_sched_class") = {
    .enqueue_task = enqueue_task_wfs,
    .dequeue_task = dequeue_task_wfs,
    .pick_task = pick_task_wfs,
    .put_prev_task = put_prev_task_wfs,
    .set_next_task = set_next_task_wfs,
    .task_tick = task_tick_wfs,
    .switched_to = switched_to_wfs,
    .switched_from = switched_from_wfs,
    .wakeup_preempt = wakeup_preempt_wfs,
    .update_curr = update_curr_wfs,
    .yield_to_task = yield_to_task_wfs,

#ifdef CONFIG_SMP
    .balance = balance_wfs,
    .select_task_rq = select_task_rq_wfs,
    .migrate_task_rq = migrate_task_rq_wfs,
    .rq_online = rq_online_wfs,
    .rq_offline = rq_offline_wfs,
    .task_woken = task_woken_wfs,
    .set_cpus_allowed = set_cpus_allowed_wfs,
#endif
};
/* 6118 */
````

Also, let me remove the now unnecessary initialization functions:

**Enhanced WFS Scheduler with CPU Load Balancing** ∙ Version 14

````c
/* 6118 */
#include <linux/mmu_context.h>
#include "sched.h"
#include "wfs.h"

/* No separate per-CPU structure needed - using wfs_rq instead */

/* Find the CPU with minimum total weight */
static int find_min_weight_cpu(struct task_struct *p)
{
    int cpu, best_cpu = -1;
    u64 min_weight = ULLONG_MAX;
    const struct cpumask *allowed_mask = tsk_cpus_allowed(p);
    
    for_each_cpu(cpu, allowed_mask) {
        struct rq *cpu_rq = cpu_rq(cpu);
        struct wfs_rq *wfs_rq = &cpu_rq->wfs;
        
        /* Skip offline CPUs */
        if (!cpu_online(cpu))
            continue;
            
        /* Find CPU with minimum weight, breaking ties with lowest CPU number */
        if (wfs_rq->cpu_total_weight < min_weight) {
            min_weight = wfs_rq->cpu_total_weight;
            best_cpu = cpu;
        }
    }
    
    /* Fallback to current CPU if no suitable CPU found */
    if (best_cpu == -1)
        best_cpu = smp_processor_id();
        
    return best_cpu;
}

/* Add task weight to CPU's total weight */
static void add_task_to_cpu_weight(struct wfs_rq *wfs_rq, u64 weight)
{
    wfs_rq->cpu_total_weight += weight;
    
    printk(KERN_DEBUG "WFS: Added weight %llu to CPU, total weight now %llu\n",
           weight, wfs_rq->cpu_total_weight);
}

/* Remove task weight from CPU's total weight */
static void remove_task_from_cpu_weight(struct wfs_rq *wfs_rq, u64 weight)
{
    if (wfs_rq->cpu_total_weight >= weight) {
        wfs_rq->cpu_total_weight -= weight;
    } else {
        printk(KERN_WARNING "WFS: CPU weight underflow, resetting to 0\n");
        wfs_rq->cpu_total_weight = 0;
    }
    
    printk(KERN_DEBUG "WFS: Removed weight %llu from CPU, total weight now %llu\n",
           weight, wfs_rq->cpu_total_weight);
}

/* Update CPU virtual time based on execution time */
static void update_cpu_vtime(struct wfs_rq *wfs_rq, u64 delta_exec)
{
    if (wfs_rq->cpu_total_weight > 0) {
        u64 vtime_delta = (delta_exec * WFS_SCALE_FACTOR) / wfs_rq->cpu_total_weight;
        wfs_rq->cpu_vtime += vtime_delta;
        
        printk(KERN_DEBUG "WFS: CPU vtime updated by %llu, now %llu (weight=%llu)\n",
               vtime_delta, wfs_rq->cpu_vtime, wfs_rq->cpu_total_weight);
    }
}

/* Get current CPU virtual time */
static u64 get_cpu_vtime(struct wfs_rq *wfs_rq)
{
    return wfs_rq->cpu_vtime;
}

/* Update virtual runtime and VFT for a task */
static void update_vruntime(struct sched_wfs_entity *se, u64 delta_exec)
{
    u64 vdelta = calc_delta_fair(delta_exec, se);
    se->vruntime += vdelta;
    
    /* Calculate VFT = vruntime + (1 tick scaled) / weight */
    u64 tick_ns = TICK_NSEC; /* Duration of 1 tick in nanoseconds */
    u64 scaled_tick = calc_delta_fair(tick_ns, se);
    se->vft = se->vruntime + scaled_tick;
}

/* Initialize virtual time for new tasks */
static void place_entity(struct wfs_rq *wfs_rq, struct sched_wfs_entity *se, int cpu)
{
    /* Initialize weight if not set */
    if (!se->weight) {
        se->weight = WFS_DEFAULT_WEIGHT;
        se->inv_weight = WFS_SCALE_FACTOR / se->weight;
    }
    
    /* Set task's virtual time to current CPU virtual time */
    se->vruntime = get_cpu_vtime(wfs_rq);
    
    /* If this is greater than min_vruntime, use min_vruntime to prevent starvation */
    if (se->vruntime < wfs_rq->min_vruntime) {
        se->vruntime = wfs_rq->min_vruntime;
    }
    
    /* Calculate initial VFT */
    u64 tick_ns = TICK_NSEC;
    u64 scaled_tick = calc_delta_fair(tick_ns, se);
    se->vft = se->vruntime + scaled_tick;
    
    /* Record which CPU this task is assigned to */
    se->assigned_cpu = cpu;
    
    printk(KERN_DEBUG "WFS: Task placed with vruntime=%llu, VFT=%llu on CPU %d (CPU vtime=%llu)\n",
           se->vruntime, se->vft, cpu, get_cpu_vtime(wfs_rq));
}

/* Update min_vruntime for the runqueue */
static void update_min_vruntime(struct wfs_rq *wfs_rq)
{
    struct rb_node *leftmost = rb_first_cached(&wfs_rq->tasks_timeline);
    u64 vruntime = wfs_rq->min_vruntime;

    if (leftmost) {
        struct sched_wfs_entity *se = rb_entry(leftmost, struct sched_wfs_entity, run_node);
        vruntime = se->vruntime;
    }

    /* min_vruntime should never go backwards */
    wfs_rq->min_vruntime = max(wfs_rq->min_vruntime, vruntime);
}

/* Main scheduler functions */

static void enqueue_task_wfs(struct rq *rq, struct task_struct *p, int flags)
{
    struct wfs_rq *wfs_rq = &rq->wfs;
    struct sched_wfs_entity *se = &p->wfs;
    int cpu = cpu_of(rq);

    /* Only add if not already on RB-tree */
    if (RB_EMPTY_NODE(&se->run_node)) {
        /* Initialize virtual time for new or waking tasks */
        if (!(flags & ENQUEUE_WAKEUP) || se->vruntime == 0) {
            place_entity(wfs_rq, se, cpu);
        } else {
            /* Waking task - recalculate VFT based on current vruntime */
            u64 tick_ns = TICK_NSEC;
            u64 scaled_tick = calc_delta_fair(tick_ns, se);
            se->vft = se->vruntime + scaled_tick;
        }

        /* Add task weight to CPU's total weight */
        add_task_to_cpu_weight(wfs_rq, se->weight);

        /* Insert into RB-tree ordered by VFT */
        rb_add_cached(&se->run_node, &wfs_rq->tasks_timeline, wfs_entity_before);

        wfs_rq->wfs_nr_running++;

        /* Also add to list for compatibility */
        if (list_empty(&se->run_list)) {
            list_add_tail(&se->run_list, &wfs_rq->queue);
        }

        update_min_vruntime(wfs_rq);

        printk(KERN_INFO "WFS: PID %d ENQUEUED on CPU %d (flags=%d), vruntime=%llu, VFT=%llu, weight=%llu, runqueue now has %u tasks\n",
               p->pid, cpu, flags, se->vruntime, se->vft, se->weight, wfs_rq->wfs_nr_running);
    } else {
        printk(KERN_WARNING "WFS: PID %d already on runqueue, skipping enqueue\n", p->pid);
    }
}

static bool dequeue_task_wfs(struct rq *rq, struct task_struct *p, int flags)
{
    struct wfs_rq *wfs_rq = &rq->wfs;
    struct sched_wfs_entity *se = &p->wfs;
    int cpu = cpu_of(rq);

    /* Only remove if actually in RB-tree */
    if (!RB_EMPTY_NODE(&se->run_node)) {
        /* Remove task weight from CPU's total weight */
        remove_task_from_cpu_weight(wfs_rq, se->weight);

        rb_erase_cached(&se->run_node, &wfs_rq->tasks_timeline);
        RB_CLEAR_NODE(&se->run_node);

        wfs_rq->wfs_nr_running--;

        /* Also remove from list */
        if (!list_empty(&se->run_list)) {
            list_del_init(&se->run_list);
        }

        update_min_vruntime(wfs_rq);

        printk(KERN_INFO "WFS: PID %d DEQUEUED from CPU %d (flags=%d), weight=%llu, runqueue now has %u tasks\n",
               p->pid, cpu, flags, se->weight, wfs_rq->wfs_nr_running);
    } else {
        printk(KERN_WARNING "WFS: PID %d not on runqueue, skipping dequeue\n", p->pid);
    }
    return true;
}

static struct task_struct *pick_task_wfs(struct rq *rq)
{
    struct wfs_rq *wfs_rq = &rq->wfs;
    struct sched_wfs_entity *wfs_se;
    struct task_struct *next_task;
    struct rb_node *leftmost;
    
    /* Check if we have any WFS tasks */
    if (!wfs_rq->wfs_nr_running) {
        return NULL;
    }
    
    /* Get the leftmost node (minimum VFT) from RB-tree */
    leftmost = rb_first_cached(&wfs_rq->tasks_timeline);
    if (!leftmost) {
        /* This shouldn't happen if wfs_nr_running > 0, but be safe */
        printk(KERN_WARNING "WFS: RB-tree empty but wfs_nr_running=%u, fixing\n",
               wfs_rq->wfs_nr_running);
        wfs_rq->wfs_nr_running = 0;
        return NULL;
    }
    
    wfs_se = rb_entry(leftmost, struct sched_wfs_entity, run_node);
    next_task = task_of_wfs(wfs_se);
    
    printk(KERN_DEBUG "WFS: PICKED task PID %d, VFT=%llu, weight=%llu, %u tasks in queue\n",
           next_task->pid, wfs_se->vft, wfs_se->weight, wfs_rq->wfs_nr_running);
    
    return next_task;
}

static void put_prev_task_wfs(struct rq *rq, struct task_struct *p, struct task_struct *next)
{
    struct sched_wfs_entity *se = &p->wfs;
    u64 now = rq_clock_task(rq);
    int cpu = cpu_of(rq);
    
    printk(KERN_DEBUG "WFS: PUT_PREV task PID %d on CPU %d (next is PID %d)\n",
           p->pid, cpu, next ? next->pid : -1);
    
    /* Update execution time and virtual runtime */
    if (se->exec_start) {
        u64 delta_exec = now - se->exec_start;
        
        /* Update total runtime */
        p->se.sum_exec_runtime += delta_exec;
        se->sum_exec_runtime += delta_exec;
        
        /* Update CPU virtual time */
        update_cpu_vtime(wfs_rq, delta_exec);
        
        /* Update virtual runtime and recalculate VFT */
        update_vruntime(se, delta_exec);
        
        se->exec_start = 0;
        
        /* If task is still runnable, we need to reposition it in RB-tree */
        if (next != p && !RB_EMPTY_NODE(&se->run_node)) {
            struct wfs_rq *wfs_rq = &rq->wfs;
            
            /* Remove from current position */
            rb_erase_cached(&se->run_node, &wfs_rq->tasks_timeline);
            
            /* Re-insert at new position based on updated VFT */
            rb_add_cached(&se->run_node, &wfs_rq->tasks_timeline, wfs_entity_before);
            
            update_min_vruntime(wfs_rq);
            
            printk(KERN_DEBUG "WFS: Task PID %d repositioned in RB-tree, new VFT=%llu\n",
                   p->pid, se->vft);
        }
    }
}

static void set_next_task_wfs(struct rq *rq, struct task_struct *p, bool first)
{
    struct wfs_rq *wfs_rq = &rq->wfs;
    int cpu = cpu_of(rq);
    
    p->wfs.exec_start = rq_clock_task(rq);
    
    printk(KERN_DEBUG "WFS: SET_NEXT task PID %d on CPU %d (first=%d), %u tasks in queue\n", 
           p->pid, cpu, first, wfs_rq->wfs_nr_running);
}

static void update_curr_wfs(struct rq *rq)
{
    struct task_struct *curr = rq->curr;
    struct sched_wfs_entity *se;
    u64 now = rq_clock_task(rq);
    int cpu = cpu_of(rq);

    if (curr->sched_class != &wfs_sched_class)
        return;

    se = &curr->wfs;

    if (se->exec_start) {
        u64 delta_exec = now - se->exec_start;

        /* Update total runtime */
        curr->se.sum_exec_runtime += delta_exec;
        se->sum_exec_runtime += delta_exec;

        /* Update CPU virtual time */
        update_cpu_vtime(wfs_rq, delta_exec);

        /* Update virtual runtime continuously */
        update_vruntime(se, delta_exec);

        se->exec_start = now;
    }
}

static void task_tick_wfs(struct rq *rq, struct task_struct *p, int queued)
{
    struct wfs_rq *wfs_rq = &rq->wfs;
    struct sched_wfs_entity *se = &p->wfs;
    int cpu = cpu_of(rq);

    printk(KERN_DEBUG "WFS: TASK_TICK PID %d on CPU %d (queued=%d), VFT=%llu, %u tasks in queue\n",
           p->pid, cpu, queued, se->vft, wfs_rq->wfs_nr_running);

    /* Update runtime stats first */
    update_curr_wfs(rq);

    /*
     * WFS: each task runs for exactly 1 tick quantum
     * Always preempt after 1 tick if there are other tasks
     */
    if (wfs_rq->wfs_nr_running > 1) {
        printk(KERN_DEBUG "WFS: Multiple tasks (%u) - preempting PID %d after 1 tick, VFT=%llu\n",
               wfs_rq->wfs_nr_running, p->pid, se->vft);

        /* Trigger a reschedule - put_prev_task will handle repositioning */
        resched_curr(rq);

        printk(KERN_DEBUG "WFS: Task PID %d preempted, will be repositioned based on updated VFT\n", p->pid);
    }
}

static void switched_to_wfs(struct rq *rq, struct task_struct *p)
{
    struct wfs_rq *wfs_rq = &rq->wfs;
    int cpu = cpu_of(rq);
    
    printk(KERN_INFO "WFS: Task PID %d SWITCHED_TO WFS class on CPU %d, %u tasks in queue\n", 
           p->pid, cpu, wfs_rq->wfs_nr_running);
    
    /* If this task should preempt current task */
    if (rq->curr != p && rq->curr->sched_class == &wfs_sched_class)
        resched_curr(rq);
}

static void switched_from_wfs(struct rq *rq, struct task_struct *p)
{
    struct wfs_rq *wfs_rq = &rq->wfs;
    int cpu = cpu_of(rq);
    
    printk(KERN_INFO "WFS: Task PID %d SWITCHED_FROM WFS class on CPU %d, %u tasks in queue\n", 
           p->pid, cpu, wfs_rq->wfs_nr_running);
    
    /* Clean up when task leaves WFS */
    if (p->wfs.exec_start) {
        u64 delta_exec = rq_clock_task(rq) - p->wfs.exec_start;
        p->se.sum_exec_runtime += delta_exec;
        update_cpu_vtime(&rq->wfs, delta_exec);
        p->wfs.exec_start = 0;
    }
}

static void check_preempt_curr_wfs(struct rq *rq, struct task_struct *p, int flags)
{
    /* For now, WFS is non-preemptive except for round-robin in task_tick */
    /* Could add preemption logic here if needed */
    printk(KERN_DEBUG "WFS: check_preempt_curr called for PID %d (flags=%d)\n", 
           p->pid, flags);
}

static void wakeup_preempt_wfs(struct rq *rq, struct task_struct *p, int flags)
{
    /* 
     * Called when a task wakes up to determine if it should preempt current task.
     * For WFS round-robin, we don't do immediate preemption on wakeup.
     * Tasks will be scheduled in round-robin order via task_tick.
     */
    printk(KERN_DEBUG "WFS: wakeup_preempt called for PID %d (flags=%d)\n", 
           p->pid, flags);
}

void init_wfs_rq(struct wfs_rq *wfs_rq)
{
    INIT_LIST_HEAD(&wfs_rq->queue);
    wfs_rq->tasks_timeline = RB_ROOT_CACHED;
    wfs_rq->wfs_nr_running = 0;
    wfs_rq->min_vruntime = 0;
    wfs_rq->cpu_total_weight = 0;
    wfs_rq->cpu_vtime = 0;
    printk(KERN_INFO "WFS: Runqueue initialized\n");
}

/* Existing initialization function already handles everything */

/* Enhanced SMP hooks for wfs scheduler */

static int select_task_rq_wfs(struct task_struct *p, int cpu, int flags)
{
    int best_cpu;
    
    /* Find CPU with minimum total weight */
    best_cpu = find_min_weight_cpu(p);
    
    printk(KERN_DEBUG "WFS: select_task_rq for PID %d: chose CPU %d (was %d)\n",
           p->pid, best_cpu, cpu);
    
    return best_cpu;
}

static int balance_wfs(struct rq *rq, struct task_struct *prev, struct rq_flags *rf)
{
    /* No-op balancing for now - load balancing happens at task placement */
    return 0;
}

static void migrate_task_rq_wfs(struct task_struct *p, int new_cpu)
{
    struct sched_wfs_entity *se = &p->wfs;
    int old_cpu = se->assigned_cpu;
    
    if (old_cpu != new_cpu && se->weight > 0) {
        /* Remove weight from old CPU and add to new CPU */
        if (old_cpu >= 0 && old_cpu < nr_cpu_ids) {
            struct rq *old_rq = cpu_rq(old_cpu);
            remove_task_from_cpu_weight(&old_rq->wfs, se->weight);
        }
        
        struct rq *new_rq = cpu_rq(new_cpu);
        add_task_to_cpu_weight(&new_rq->wfs, se->weight);
        se->assigned_cpu = new_cpu;
        
        printk(KERN_DEBUG "WFS: Task PID %d migrated from CPU %d to CPU %d, weight=%llu\n",
               p->pid, old_cpu, new_cpu, se->weight);
    }
}

static void rq_online_wfs(struct rq *rq)
{
    int cpu = cpu_of(rq);
    init_wfs_cpu_data(cpu);
    printk(KERN_INFO "WFS: CPU %d came online\n", cpu);
}

static void rq_offline_wfs(struct rq *rq)
{
    int cpu = cpu_of(rq);
    struct wfs_rq *wfs_rq = &rq->wfs;
    
    printk(KERN_INFO "WFS: CPU %d going offline, had total weight %llu\n",
           cpu, wfs_rq->cpu_total_weight);
}

static void task_woken_wfs(struct rq *rq, struct task_struct *p)
{
    /* No-op - nothing to do after remote wakeup */
}

static void set_cpus_allowed_wfs(struct task_struct *p, struct affinity_context *ctx)
{
    /* Could implement logic to rebalance if affinity changes */
    printk(KERN_DEBUG "WFS: CPU affinity changed for PID %d\n", p->pid);
}

static bool yield_to_task_wfs(struct rq *rq, struct task_struct *p)
{
    /* Return false - don't handle yield_to */
    return false;
}

const struct sched_class wfs_sched_class __section("__wfs_sched_class") = {
    .enqueue_task = enqueue_task_wfs,
    .dequeue_task = dequeue_task_wfs,
    .pick_task = pick_task_wfs,
    .put_prev_task = put_prev_task_wfs,
    .set_next_task = set_next_task_wfs,
    .task_tick = task_tick_wfs,
    .switched_to = switched_to_wfs,
    .switched_from = switched_from_wfs,
    .wakeup_preempt = wakeup_preempt_wfs,
    .update_curr = update_curr_wfs,
    .yield_to_task = yield_to_task_wfs,

#ifdef CONFIG_SMP
    .balance = balance_wfs,
    .select_task_rq = select_task_rq_wfs,
    .migrate_task_rq = migrate_task_rq_wfs,
    .rq_online = rq_online_wfs,
    .rq_offline = rq_offline_wfs,
    .task_woken = task_woken_wfs,
    .set_cpus_allowed = set_cpus_allowed_wfs,
#endif
};
/* 6118 */
````

Let me also clean up the rq_online_wfs function:

**Enhanced WFS Scheduler with CPU Load Balancing** ∙ Version 15

````c
/* 6118 */
#include <linux/mmu_context.h>
#include "sched.h"
#include "wfs.h"

/* No separate per-CPU structure needed - using wfs_rq instead */

/* Find the CPU with minimum total weight */
static int find_min_weight_cpu(struct task_struct *p)
{
    int cpu, best_cpu = -1;
    u64 min_weight = ULLONG_MAX;
    const struct cpumask *allowed_mask = tsk_cpus_allowed(p);
    
    for_each_cpu(cpu, allowed_mask) {
        struct rq *cpu_rq = cpu_rq(cpu);
        struct wfs_rq *wfs_rq = &cpu_rq->wfs;
        
        /* Skip offline CPUs */
        if (!cpu_online(cpu))
            continue;
            
        /* Find CPU with minimum weight, breaking ties with lowest CPU number */
        if (wfs_rq->cpu_total_weight < min_weight) {
            min_weight = wfs_rq->cpu_total_weight;
            best_cpu = cpu;
        }
    }
    
    /* Fallback to current CPU if no suitable CPU found */
    if (best_cpu == -1)
        best_cpu = smp_processor_id();
        
    return best_cpu;
}

/* Add task weight to CPU's total weight */
static void add_task_to_cpu_weight(struct wfs_rq *wfs_rq, u64 weight)
{
    wfs_rq->cpu_total_weight += weight;
    
    printk(KERN_DEBUG "WFS: Added weight %llu to CPU, total weight now %llu\n",
           weight, wfs_rq->cpu_total_weight);
}

/* Remove task weight from CPU's total weight */
static void remove_task_from_cpu_weight(struct wfs_rq *wfs_rq, u64 weight)
{
    if (wfs_rq->cpu_total_weight >= weight) {
        wfs_rq->cpu_total_weight -= weight;
    } else {
        printk(KERN_WARNING "WFS: CPU weight underflow, resetting to 0\n");
        wfs_rq->cpu_total_weight = 0;
    }
    
    printk(KERN_DEBUG "WFS: Removed weight %llu from CPU, total weight now %llu\n",
           weight, wfs_rq->cpu_total_weight);
}

/* Update CPU virtual time based on execution time */
static void update_cpu_vtime(struct wfs_rq *wfs_rq, u64 delta_exec)
{
    if (wfs_rq->cpu_total_weight > 0) {
        u64 vtime_delta = (delta_exec * WFS_SCALE_FACTOR) / wfs_rq->cpu_total_weight;
        wfs_rq->cpu_vtime += vtime_delta;
        
        printk(KERN_DEBUG "WFS: CPU vtime updated by %llu, now %llu (weight=%llu)\n",
               vtime_delta, wfs_rq->cpu_vtime, wfs_rq->cpu_total_weight);
    }
}

/* Get current CPU virtual time */
static u64 get_cpu_vtime(struct wfs_rq *wfs_rq)
{
    return wfs_rq->cpu_vtime;
}

/* Update virtual runtime and VFT for a task */
static void update_vruntime(struct sched_wfs_entity *se, u64 delta_exec)
{
    u64 vdelta = calc_delta_fair(delta_exec, se);
    se->vruntime += vdelta;
    
    /* Calculate VFT = vruntime + (1 tick scaled) / weight */
    u64 tick_ns = TICK_NSEC; /* Duration of 1 tick in nanoseconds */
    u64 scaled_tick = calc_delta_fair(tick_ns, se);
    se->vft = se->vruntime + scaled_tick;
}

/* Initialize virtual time for new tasks */
static void place_entity(struct wfs_rq *wfs_rq, struct sched_wfs_entity *se, int cpu)
{
    /* Initialize weight if not set */
    if (!se->weight) {
        se->weight = WFS_DEFAULT_WEIGHT;
        se->inv_weight = WFS_SCALE_FACTOR / se->weight;
    }
    
    /* Set task's virtual time to current CPU virtual time */
    se->vruntime = get_cpu_vtime(wfs_rq);
    
    /* If this is greater than min_vruntime, use min_vruntime to prevent starvation */
    if (se->vruntime < wfs_rq->min_vruntime) {
        se->vruntime = wfs_rq->min_vruntime;
    }
    
    /* Calculate initial VFT */
    u64 tick_ns = TICK_NSEC;
    u64 scaled_tick = calc_delta_fair(tick_ns, se);
    se->vft = se->vruntime + scaled_tick;
    
    /* Record which CPU this task is assigned to */
    se->assigned_cpu = cpu;
    
    printk(KERN_DEBUG "WFS: Task placed with vruntime=%llu, VFT=%llu on CPU %d (CPU vtime=%llu)\n",
           se->vruntime, se->vft, cpu, get_cpu_vtime(wfs_rq));
}

/* Update min_vruntime for the runqueue */
static void update_min_vruntime(struct wfs_rq *wfs_rq)
{
    struct rb_node *leftmost = rb_first_cached(&wfs_rq->tasks_timeline);
    u64 vruntime = wfs_rq->min_vruntime;

    if (leftmost) {
        struct sched_wfs_entity *se = rb_entry(leftmost, struct sched_wfs_entity, run_node);
        vruntime = se->vruntime;
    }

    /* min_vruntime should never go backwards */
    wfs_rq->min_vruntime = max(wfs_rq->min_vruntime, vruntime);
}

/* Main scheduler functions */

static void enqueue_task_wfs(struct rq *rq, struct task_struct *p, int flags)
{
    struct wfs_rq *wfs_rq = &rq->wfs;
    struct sched_wfs_entity *se = &p->wfs;
    int cpu = cpu_of(rq);

    /* Only add if not already on RB-tree */
    if (RB_EMPTY_NODE(&se->run_node)) {
        /* Initialize virtual time for new or waking tasks */
        if (!(flags & ENQUEUE_WAKEUP) || se->vruntime == 0) {
            place_entity(wfs_rq, se, cpu);
        } else {
            /* Waking task - recalculate VFT based on current vruntime */
            u64 tick_ns = TICK_NSEC;
            u64 scaled_tick = calc_delta_fair(tick_ns, se);
            se->vft = se->vruntime + scaled_tick;
        }

        /* Add task weight to CPU's total weight */
        add_task_to_cpu_weight(wfs_rq, se->weight);

        /* Insert into RB-tree ordered by VFT */
        rb_add_cached(&se->run_node, &wfs_rq->tasks_timeline, wfs_entity_before);

        wfs_rq->wfs_nr_running++;

        /* Also add to list for compatibility */
        if (list_empty(&se->run_list)) {
            list_add_tail(&se->run_list, &wfs_rq->queue);
        }

        update_min_vruntime(wfs_rq);

        printk(KERN_INFO "WFS: PID %d ENQUEUED on CPU %d (flags=%d), vruntime=%llu, VFT=%llu, weight=%llu, runqueue now has %u tasks\n",
               p->pid, cpu, flags, se->vruntime, se->vft, se->weight, wfs_rq->wfs_nr_running);
    } else {
        printk(KERN_WARNING "WFS: PID %d already on runqueue, skipping enqueue\n", p->pid);
    }
}

static bool dequeue_task_wfs(struct rq *rq, struct task_struct *p, int flags)
{
    struct wfs_rq *wfs_rq = &rq->wfs;
    struct sched_wfs_entity *se = &p->wfs;
    int cpu = cpu_of(rq);

    /* Only remove if actually in RB-tree */
    if (!RB_EMPTY_NODE(&se->run_node)) {
        /* Remove task weight from CPU's total weight */
        remove_task_from_cpu_weight(wfs_rq, se->weight);

        rb_erase_cached(&se->run_node, &wfs_rq->tasks_timeline);
        RB_CLEAR_NODE(&se->run_node);

        wfs_rq->wfs_nr_running--;

        /* Also remove from list */
        if (!list_empty(&se->run_list)) {
            list_del_init(&se->run_list);
        }

        update_min_vruntime(wfs_rq);

        printk(KERN_INFO "WFS: PID %d DEQUEUED from CPU %d (flags=%d), weight=%llu, runqueue now has %u tasks\n",
               p->pid, cpu, flags, se->weight, wfs_rq->wfs_nr_running);
    } else {
        printk(KERN_WARNING "WFS: PID %d not on runqueue, skipping dequeue\n", p->pid);
    }
    return true;
}

static struct task_struct *pick_task_wfs(struct rq *rq)
{
    struct wfs_rq *wfs_rq = &rq->wfs;
    struct sched_wfs_entity *wfs_se;
    struct task_struct *next_task;
    struct rb_node *leftmost;
    
    /* Check if we have any WFS tasks */
    if (!wfs_rq->wfs_nr_running) {
        return NULL;
    }
    
    /* Get the leftmost node (minimum VFT) from RB-tree */
    leftmost = rb_first_cached(&wfs_rq->tasks_timeline);
    if (!leftmost) {
        /* This shouldn't happen if wfs_nr_running > 0, but be safe */
        printk(KERN_WARNING "WFS: RB-tree empty but wfs_nr_running=%u, fixing\n",
               wfs_rq->wfs_nr_running);
        wfs_rq->wfs_nr_running = 0;
        return NULL;
    }
    
    wfs_se = rb_entry(leftmost, struct sched_wfs_entity, run_node);
    next_task = task_of_wfs(wfs_se);
    
    printk(KERN_DEBUG "WFS: PICKED task PID %d, VFT=%llu, weight=%llu, %u tasks in queue\n",
           next_task->pid, wfs_se->vft, wfs_se->weight, wfs_rq->wfs_nr_running);
    
    return next_task;
}

static void put_prev_task_wfs(struct rq *rq, struct task_struct *p, struct task_struct *next)
{
    struct sched_wfs_entity *se = &p->wfs;
    u64 now = rq_clock_task(rq);
    int cpu = cpu_of(rq);
    
    printk(KERN_DEBUG "WFS: PUT_PREV task PID %d on CPU %d (next is PID %d)\n",
           p->pid, cpu, next ? next->pid : -1);
    
    /* Update execution time and virtual runtime */
    if (se->exec_start) {
        u64 delta_exec = now - se->exec_start;
        
        /* Update total runtime */
        p->se.sum_exec_runtime += delta_exec;
        se->sum_exec_runtime += delta_exec;
        
        /* Update CPU virtual time */
        update_cpu_vtime(wfs_rq, delta_exec);
        
        /* Update virtual runtime and recalculate VFT */
        update_vruntime(se, delta_exec);
        
        se->exec_start = 0;
        
        /* If task is still runnable, we need to reposition it in RB-tree */
        if (next != p && !RB_EMPTY_NODE(&se->run_node)) {
            struct wfs_rq *wfs_rq = &rq->wfs;
            
            /* Remove from current position */
            rb_erase_cached(&se->run_node, &wfs_rq->tasks_timeline);
            
            /* Re-insert at new position based on updated VFT */
            rb_add_cached(&se->run_node, &wfs_rq->tasks_timeline, wfs_entity_before);
            
            update_min_vruntime(wfs_rq);
            
            printk(KERN_DEBUG "WFS: Task PID %d repositioned in RB-tree, new VFT=%llu\n",
                   p->pid, se->vft);
        }
    }
}

static void set_next_task_wfs(struct rq *rq, struct task_struct *p, bool first)
{
    struct wfs_rq *wfs_rq = &rq->wfs;
    int cpu = cpu_of(rq);
    
    p->wfs.exec_start = rq_clock_task(rq);
    
    printk(KERN_DEBUG "WFS: SET_NEXT task PID %d on CPU %d (first=%d), %u tasks in queue\n", 
           p->pid, cpu, first, wfs_rq->wfs_nr_running);
}

static void update_curr_wfs(struct rq *rq)
{
    struct task_struct *curr = rq->curr;
    struct sched_wfs_entity *se;
    u64 now = rq_clock_task(rq);
    int cpu = cpu_of(rq);

    if (curr->sched_class != &wfs_sched_class)
        return;

    se = &curr->wfs;

    if (se->exec_start) {
        u64 delta_exec = now - se->exec_start;

        /* Update total runtime */
        curr->se.sum_exec_runtime += delta_exec;
        se->sum_exec_runtime += delta_exec;

        /* Update CPU virtual time */
        update_cpu_vtime(wfs_rq, delta_exec);

        /* Update virtual runtime continuously */
        update_vruntime(se, delta_exec);

        se->exec_start = now;
    }
}

static void task_tick_wfs(struct rq *rq, struct task_struct *p, int queued)
{
    struct wfs_rq *wfs_rq = &rq->wfs;
    struct sched_wfs_entity *se = &p->wfs;
    int cpu = cpu_of(rq);

    printk(KERN_DEBUG "WFS: TASK_TICK PID %d on CPU %d (queued=%d), VFT=%llu, %u tasks in queue\n",
           p->pid, cpu, queued, se->vft, wfs_rq->wfs_nr_running);

    /* Update runtime stats first */
    update_curr_wfs(rq);

    /*
     * WFS: each task runs for exactly 1 tick quantum
     * Always preempt after 1 tick if there are other tasks
     */
    if (wfs_rq->wfs_nr_running > 1) {
        printk(KERN_DEBUG "WFS: Multiple tasks (%u) - preempting PID %d after 1 tick, VFT=%llu\n",
               wfs_rq->wfs_nr_running, p->pid, se->vft);

        /* Trigger a reschedule - put_prev_task will handle repositioning */
        resched_curr(rq);

        printk(KERN_DEBUG "WFS: Task PID %d preempted, will be repositioned based on updated VFT\n", p->pid);
    }
}

static void switched_to_wfs(struct rq *rq, struct task_struct *p)
{
    struct wfs_rq *wfs_rq = &rq->wfs;
    int cpu = cpu_of(rq);
    
    printk(KERN_INFO "WFS: Task PID %d SWITCHED_TO WFS class on CPU %d, %u tasks in queue\n", 
           p->pid, cpu, wfs_rq->wfs_nr_running);
    
    /* If this task should preempt current task */
    if (rq->curr != p && rq->curr->sched_class == &wfs_sched_class)
        resched_curr(rq);
}

static void switched_from_wfs(struct rq *rq, struct task_struct *p)
{
    struct wfs_rq *wfs_rq = &rq->wfs;
    int cpu = cpu_of(rq);
    
    printk(KERN_INFO "WFS: Task PID %d SWITCHED_FROM WFS class on CPU %d, %u tasks in queue\n", 
           p->pid, cpu, wfs_rq->wfs_nr_running);
    
    /* Clean up when task leaves WFS */
    if (p->wfs.exec_start) {
        u64 delta_exec = rq_clock_task(rq) - p->wfs.exec_start;
        p->se.sum_exec_runtime += delta_exec;
        update_cpu_vtime(&rq->wfs, delta_exec);
        p->wfs.exec_start = 0;
    }
}

static void check_preempt_curr_wfs(struct rq *rq, struct task_struct *p, int flags)
{
    /* For now, WFS is non-preemptive except for round-robin in task_tick */
    /* Could add preemption logic here if needed */
    printk(KERN_DEBUG "WFS: check_preempt_curr called for PID %d (flags=%d)\n", 
           p->pid, flags);
}

static void wakeup_preempt_wfs(struct rq *rq, struct task_struct *p, int flags)
{
    /* 
     * Called when a task wakes up to determine if it should preempt current task.
     * For WFS round-robin, we don't do immediate preemption on wakeup.
     * Tasks will be scheduled in round-robin order via task_tick.
     */
    printk(KERN_DEBUG "WFS: wakeup_preempt called for PID %d (flags=%d)\n", 
           p->pid, flags);
}

void init_wfs_rq(struct wfs_rq *wfs_rq)
{
    INIT_LIST_HEAD(&wfs_rq->queue);
    wfs_rq->tasks_timeline = RB_ROOT_CACHED;
    wfs_rq->wfs_nr_running = 0;
    wfs_rq->min_vruntime = 0;
    wfs_rq->cpu_total_weight = 0;
    wfs_rq->cpu_vtime = 0;
    printk(KERN_INFO "WFS: Runqueue initialized\n");
}

/* Existing initialization function already handles everything */

/* Enhanced SMP hooks for wfs scheduler */

static int select_task_rq_wfs(struct task_struct *p, int cpu, int flags)
{
    int best_cpu;
    
    /* Find CPU with minimum total weight */
    best_cpu = find_min_weight_cpu(p);
    
    printk(KERN_DEBUG "WFS: select_task_rq for PID %d: chose CPU %d (was %d)\n",
           p->pid, best_cpu, cpu);
    
    return best_cpu;
}

static int balance_wfs(struct rq *rq, struct task_struct *prev, struct rq_flags *rf)
{
    /* No-op balancing for now - load balancing happens at task placement */
    return 0;
}

static void migrate_task_rq_wfs(struct task_struct *p, int new_cpu)
{
    struct sched_wfs_entity *se = &p->wfs;
    int old_cpu = se->assigned_cpu;
    
    if (old_cpu != new_cpu && se->weight > 0) {
        /* Remove weight from old CPU and add to new CPU */
        if (old_cpu >= 0 && old_cpu < nr_cpu_ids) {
            struct rq *old_rq = cpu_rq(old_cpu);
            remove_task_from_cpu_weight(&old_rq->wfs, se->weight);
        }
        
        struct rq *new_rq = cpu_rq(new_cpu);
        add_task_to_cpu_weight(&new_rq->wfs, se->weight);
        se->assigned_cpu = new_cpu;
        
        printk(KERN_DEBUG "WFS: Task PID %d migrated from CPU %d to CPU %d, weight=%llu\n",
               p->pid, old_cpu, new_cpu, se->weight);
    }
}

static void rq_online_wfs(struct rq *rq)
{
    int cpu = cpu_of(rq);
    printk(KERN_INFO "WFS: CPU %d came online\n", cpu);
}

static void rq_offline_wfs(struct rq *rq)
{
    int cpu = cpu_of(rq);
    struct wfs_rq *wfs_rq = &rq->wfs;
    
    printk(KERN_INFO "WFS: CPU %d going offline, had total weight %llu\n",
           cpu, wfs_rq->cpu_total_weight);
}

static void task_woken_wfs(struct rq *rq, struct task_struct *p)
{
    /* No-op - nothing to do after remote wakeup */
}

static void set_cpus_allowed_wfs(struct task_struct *p, struct affinity_context *ctx)
{
    /* Could implement logic to rebalance if affinity changes */
    printk(KERN_DEBUG "WFS: CPU affinity changed for PID %d\n", p->pid);
}

static bool yield_to_task_wfs(struct rq *rq, struct task_struct *p)
{
    /* Return false - don't handle yield_to */
    return false;
}

const struct sched_class wfs_sched_class __section("__wfs_sched_class") = {
    .enqueue_task = enqueue_task_wfs,
    .dequeue_task = dequeue_task_wfs,
    .pick_task = pick_task_wfs,
    .put_prev_task = put_prev_task_wfs,
    .set_next_task = set_next_task_wfs,
    .task_tick = task_tick_wfs,
    .switched_to = switched_to_wfs,
    .switched_from = switched_from_wfs,
    .wakeup_preempt = wakeup_preempt_wfs,
    .update_curr = update_curr_wfs,
    .yield_to_task = yield_to_task_wfs,

#ifdef CONFIG_SMP
    .balance = balance_wfs,
    .select_task_rq = select_task_rq_wfs,
    .migrate_task_rq = migrate_task_rq_wfs,
    .rq_online = rq_online_wfs,
    .rq_offline = rq_offline_wfs,
    .task_woken = task_woken_wfs,
    .set_cpus_allowed = set_cpus_allowed_wfs,
#endif
};
/* 6118 */
````

Perfect! You're absolutely right - integrating the CPU load tracking into the existing `wfs_rq` struct is much cleaner and more efficient. Here's what the updated design achieves:

## Benefits of Using `wfs_rq`

1. **No extra per-CPU data structures** - We leverage the existing per-CPU runqueue infrastructure
2. **Automatic locking** - The runqueue operations already have proper synchronization
3. **Natural locality** - CPU weight and virtual time data are co-located with the task queue
4. **Simpler code** - No need for separate initialization or cleanup routines

## Updated `wfs_rq` Structure

You'll need to add these fields to your `wfs_rq` struct:

```c
struct wfs_rq {
    struct rb_root_cached   tasks_timeline;  // Leftmost-cached RB-tree for O(1) min-VFT
    struct list_head        queue;           // Keep for fallback or debugging
    unsigned int            wfs_nr_running;
    u64                     min_vruntime;    // Track minimum virtual runtime on this CPU
    u64                     cpu_total_weight; // Total weight of all tasks on this CPU
    u64                     cpu_vtime;       // Virtual time for this CPU
};
```

## Key Changes Made

- **Removed separate per-CPU data structure** and related initialization
- **Updated all functions** to work with `wfs_rq` directly instead of per-CPU lookups
- **Simplified locking** - relies on existing runqueue locking mechanisms
- **Cleaner migration logic** - directly accesses source and target runqueues
- **Updated initialization** - `init_wfs_rq()` now initializes the new fields

The scheduler now uses the natural per-CPU runqueue structure that already exists in the kernel, making it more integrated with the existing scheduler infrastructure and eliminating unnecessary complexity.



## Prompt:
9/23/2025, 2:34:01 PM

Looking at the diff between what you are suggesting and my existing wfs.c file, I noticed that you added functionality to migrate_task


 static void migrate_task_rq_wfs(struct task_struct *p, int new_cpu)
 {
-    /* No-op - nothing to do when task migrates */
+    struct sched_wfs_entity *se = &p->wfs;
+    int old_cpu = se->assigned_cpu;
+
+    if (old_cpu != new_cpu && se->weight > 0) {
+        /* Remove weight from old CPU and add to new CPU */
+        if (old_cpu >= 0 && old_cpu < nr_cpu_ids) {
+            struct rq *old_rq = cpu_rq(old_cpu);
+            remove_task_from_cpu_weight(&old_rq->wfs, se->weight);
+        }
+
+        struct rq *new_rq = cpu_rq(new_cpu);
+        add_task_to_cpu_weight(&new_rq->wfs, se->weight);
+        se->assigned_cpu = new_cpu;
+
+        printk(KERN_DEBUG "WFS: Task PID %d migrated from CPU %d to CPU %d, weight=%llu\n",
+               p->pid, old_cpu, new_cpu, se->weight);
+    }
 }

Can you tell me what this does and why do i need it?



## Response:
9/23/2025, 2:34:15 PM

The `migrate_task_rq_wfs` function handles task migration between CPUs, which is crucial for maintaining accurate load balancing in your scheduler. Here's what it does and why you need it:

## What it does:

1. **Tracks weight movement between CPUs**: When a task migrates from CPU A to CPU B, it removes the task's weight from CPU A's total and adds it to CPU B's total.

2. **Updates task's CPU assignment**: It keeps track of which CPU each task is currently assigned to via `se->assigned_cpu`.

3. **Maintains load balancing accuracy**: Without this, your CPU weight totals would become incorrect over time as tasks move between CPUs.

## Why you need it:

**Your scheduler's core principle is assigning new tasks to the CPU with minimum total weight.** If you don't properly track weight changes during migration, this breaks down:

### Without migration tracking:
- Task with weight 100 starts on CPU 0 (CPU 0 weight = 100)
- Kernel migrates task to CPU 1 for some reason (CPU affinity, load balancing, etc.)
- **Your scheduler still thinks**: CPU 0 weight = 100, CPU 1 weight = 0
- **Reality**: CPU 0 weight = 0, CPU 1 weight = 100
- New tasks will incorrectly be assigned to CPU 1 thinking it's "less loaded"

### With migration tracking:
- Task migrates from CPU 0 to CPU 1
- `migrate_task_rq_wfs` updates: CPU 0 weight = 0, CPU 1 weight = 100  
- `find_min_weight_cpu` now correctly sees CPU 0 as the least loaded

## When is this called:

The kernel calls this function automatically when it decides to migrate a task between CPUs for reasons like:
- CPU affinity changes (`sched_setaffinity`)
- Load balancing by other parts of the scheduler
- CPU hotplug operations
- NUMA balancing

**You don't control when migration happens** - the kernel handles it. Your job is to keep your weight tracking consistent when it does happen.

Without this function, your "assign to minimum weight CPU" logic would gradually become inaccurate as tasks move around the system, defeating the purpose of your load balancing algorithm.



## Prompt:
9/23/2025, 2:55:33 PM

> File: 

I'm getting a few compilation errors:

kernel/sched/wfs.c: In function ‘migrate_task_rq_wfs’:
kernel/sched/wfs.c:434:21: error: ‘struct sched_wfs_entity’ has no member named ‘assigned_cpu’
  434 |     int old_cpu = se->assigned_cpu;
      |                     ^~


kernel/sched/wfs.c:13:42: error: implicit declaration of function ‘tsk_cpus_allowed’; did you mean ‘mm_cpus_allowed’? [-Wimplicit-function-declaration]
   13 |     const struct cpumask *allowed_mask = tsk_cpus_allowed(p);
      |                                          ^~~~~~~~~~~~~~~~
      |                                          mm_cpus_allowed
kernel/sched/wfs.c:13:42: error: initialization of ‘const struct cpumask *’ from ‘int’ makes pointer from integer without a cast [-Wint-conversion]

For this first one I think I havent yet updated the sched_wfs_entity can you show me the updates to sched_wfs_entity compared to what I have now?

struct sched_wfs_entity {
    struct rb_node          run_node;        // Node in the RB-tree
    struct list_head        run_list;        // Keep for compatibility
    // Timing fields
    unsigned long           time_slice;      // Still 1 tick
    u64                     exec_start;
    u64                     sum_exec_runtime;
    u64                     prev_sum_exec_runtime;
    // Virtual time fields
    u64                     vruntime;        // Virtual runtime (scaled)
    u64                     vft;             // Virtual finishing time (scaled)
    u32                     weight;          // Task weight (default could be 1024)
    u64                     inv_weight;      // Precomputed inverse weight for efficiency
};

For the second error, this tsk_cpus_allowed() doesnt exist... but is the intended purpose for this to read the cpus_mask member variable of the task struct?



## Response:
9/23/2025, 2:55:56 PM

You're right on both counts. Let me fix these issues:

## 1. Missing `assigned_cpu` field in `sched_wfs_entity`

You need to add the `assigned_cpu` field to track which CPU a task is assigned to:

```c
struct sched_wfs_entity {
    struct rb_node          run_node;        // Node in the RB-tree
    struct list_head        run_list;        // Keep for compatibility
    // Timing fields
    unsigned long           time_slice;      // Still 1 tick
    u64                     exec_start;
    u64                     sum_exec_runtime;
    u64                     prev_sum_exec_runtime;
    // Virtual time fields
    u64                     vruntime;        // Virtual runtime (scaled)
    u64                     vft;             // Virtual finishing time (scaled)
    u32                     weight;          // Task weight (default could be 1024)
    u64                     inv_weight;      // Precomputed inverse weight for efficiency
    int                     assigned_cpu;    // Which CPU this task is assigned to
};
```

## 2. Fix `tsk_cpus_allowed()` function call

You're correct - `tsk_cpus_allowed()` doesn't exist in Linux 6.14. Looking at the `task_struct` you provided, the CPU affinity is stored in the `cpus_ptr` field. Here's the fix:

**Enhanced WFS Scheduler with CPU Load Balancing** ∙ Version 16

````c
/* 6118 */
#include <linux/mmu_context.h>
#include "sched.h"
#include "wfs.h"

/* No separate per-CPU structure needed - using wfs_rq instead */

/* Find the CPU with minimum total weight */
static int find_min_weight_cpu(struct task_struct *p)
{
    int cpu, best_cpu = -1;
    u64 min_weight = ULLONG_MAX;
    const struct cpumask *allowed_mask = p->cpus_ptr;
    
    for_each_cpu(cpu, allowed_mask) {
        struct rq *cpu_rq = cpu_rq(cpu);
        struct wfs_rq *wfs_rq = &cpu_rq->wfs;
        
        /* Skip offline CPUs */
        if (!cpu_online(cpu))
            continue;
            
        /* Find CPU with minimum weight, breaking ties with lowest CPU number */
        if (wfs_rq->cpu_total_weight < min_weight) {
            min_weight = wfs_rq->cpu_total_weight;
            best_cpu = cpu;
        }
    }
    
    /* Fallback to current CPU if no suitable CPU found */
    if (best_cpu == -1)
        best_cpu = smp_processor_id();
        
    return best_cpu;
}

/* Add task weight to CPU's total weight */
static void add_task_to_cpu_weight(struct wfs_rq *wfs_rq, u64 weight)
{
    wfs_rq->cpu_total_weight += weight;
    
    printk(KERN_DEBUG "WFS: Added weight %llu to CPU, total weight now %llu\n",
           weight, wfs_rq->cpu_total_weight);
}

/* Remove task weight from CPU's total weight */
static void remove_task_from_cpu_weight(struct wfs_rq *wfs_rq, u64 weight)
{
    if (wfs_rq->cpu_total_weight >= weight) {
        wfs_rq->cpu_total_weight -= weight;
    } else {
        printk(KERN_WARNING "WFS: CPU weight underflow, resetting to 0\n");
        wfs_rq->cpu_total_weight = 0;
    }
    
    printk(KERN_DEBUG "WFS: Removed weight %llu from CPU, total weight now %llu\n",
           weight, wfs_rq->cpu_total_weight);
}

/* Update CPU virtual time based on execution time */
static void update_cpu_vtime(struct wfs_rq *wfs_rq, u64 delta_exec)
{
    if (wfs_rq->cpu_total_weight > 0) {
        u64 vtime_delta = (delta_exec * WFS_SCALE_FACTOR) / wfs_rq->cpu_total_weight;
        wfs_rq->cpu_vtime += vtime_delta;
        
        printk(KERN_DEBUG "WFS: CPU vtime updated by %llu, now %llu (weight=%llu)\n",
               vtime_delta, wfs_rq->cpu_vtime, wfs_rq->cpu_total_weight);
    }
}

/* Get current CPU virtual time */
static u64 get_cpu_vtime(struct wfs_rq *wfs_rq)
{
    return wfs_rq->cpu_vtime;
}

/* Update virtual runtime and VFT for a task */
static void update_vruntime(struct sched_wfs_entity *se, u64 delta_exec)
{
    u64 vdelta = calc_delta_fair(delta_exec, se);
    se->vruntime += vdelta;
    
    /* Calculate VFT = vruntime + (1 tick scaled) / weight */
    u64 tick_ns = TICK_NSEC; /* Duration of 1 tick in nanoseconds */
    u64 scaled_tick = calc_delta_fair(tick_ns, se);
    se->vft = se->vruntime + scaled_tick;
}

/* Initialize virtual time for new tasks */
static void place_entity(struct wfs_rq *wfs_rq, struct sched_wfs_entity *se, int cpu)
{
    /* Initialize weight if not set */
    if (!se->weight) {
        se->weight = WFS_DEFAULT_WEIGHT;
        se->inv_weight = WFS_SCALE_FACTOR / se->weight;
    }
    
    /* Set task's virtual time to current CPU virtual time */
    se->vruntime = get_cpu_vtime(wfs_rq);
    
    /* If this is greater than min_vruntime, use min_vruntime to prevent starvation */
    if (se->vruntime < wfs_rq->min_vruntime) {
        se->vruntime = wfs_rq->min_vruntime;
    }
    
    /* Calculate initial VFT */
    u64 tick_ns = TICK_NSEC;
    u64 scaled_tick = calc_delta_fair(tick_ns, se);
    se->vft = se->vruntime + scaled_tick;
    
    /* Record which CPU this task is assigned to */
    se->assigned_cpu = cpu;
    
    printk(KERN_DEBUG "WFS: Task placed with vruntime=%llu, VFT=%llu on CPU %d (CPU vtime=%llu)\n",
           se->vruntime, se->vft, cpu, get_cpu_vtime(wfs_rq));
}

/* Update min_vruntime for the runqueue */
static void update_min_vruntime(struct wfs_rq *wfs_rq)
{
    struct rb_node *leftmost = rb_first_cached(&wfs_rq->tasks_timeline);
    u64 vruntime = wfs_rq->min_vruntime;

    if (leftmost) {
        struct sched_wfs_entity *se = rb_entry(leftmost, struct sched_wfs_entity, run_node);
        vruntime = se->vruntime;
    }

    /* min_vruntime should never go backwards */
    wfs_rq->min_vruntime = max(wfs_rq->min_vruntime, vruntime);
}

/* Main scheduler functions */

static void enqueue_task_wfs(struct rq *rq, struct task_struct *p, int flags)
{
    struct wfs_rq *wfs_rq = &rq->wfs;
    struct sched_wfs_entity *se = &p->wfs;
    int cpu = cpu_of(rq);

    /* Only add if not already on RB-tree */
    if (RB_EMPTY_NODE(&se->run_node)) {
        /* Initialize virtual time for new or waking tasks */
        if (!(flags & ENQUEUE_WAKEUP) || se->vruntime == 0) {
            place_entity(wfs_rq, se, cpu);
        } else {
            /* Waking task - recalculate VFT based on current vruntime */
            u64 tick_ns = TICK_NSEC;
            u64 scaled_tick = calc_delta_fair(tick_ns, se);
            se->vft = se->vruntime + scaled_tick;
        }

        /* Add task weight to CPU's total weight */
        add_task_to_cpu_weight(wfs_rq, se->weight);

        /* Insert into RB-tree ordered by VFT */
        rb_add_cached(&se->run_node, &wfs_rq->tasks_timeline, wfs_entity_before);

        wfs_rq->wfs_nr_running++;

        /* Also add to list for compatibility */
        if (list_empty(&se->run_list)) {
            list_add_tail(&se->run_list, &wfs_rq->queue);
        }

        update_min_vruntime(wfs_rq);

        printk(KERN_INFO "WFS: PID %d ENQUEUED on CPU %d (flags=%d), vruntime=%llu, VFT=%llu, weight=%llu, runqueue now has %u tasks\n",
               p->pid, cpu, flags, se->vruntime, se->vft, se->weight, wfs_rq->wfs_nr_running);
    } else {
        printk(KERN_WARNING "WFS: PID %d already on runqueue, skipping enqueue\n", p->pid);
    }
}

static bool dequeue_task_wfs(struct rq *rq, struct task_struct *p, int flags)
{
    struct wfs_rq *wfs_rq = &rq->wfs;
    struct sched_wfs_entity *se = &p->wfs;
    int cpu = cpu_of(rq);

    /* Only remove if actually in RB-tree */
    if (!RB_EMPTY_NODE(&se->run_node)) {
        /* Remove task weight from CPU's total weight */
        remove_task_from_cpu_weight(wfs_rq, se->weight);

        rb_erase_cached(&se->run_node, &wfs_rq->tasks_timeline);
        RB_CLEAR_NODE(&se->run_node);

        wfs_rq->wfs_nr_running--;

        /* Also remove from list */
        if (!list_empty(&se->run_list)) {
            list_del_init(&se->run_list);
        }

        update_min_vruntime(wfs_rq);

        printk(KERN_INFO "WFS: PID %d DEQUEUED from CPU %d (flags=%d), weight=%llu, runqueue now has %u tasks\n",
               p->pid, cpu, flags, se->weight, wfs_rq->wfs_nr_running);
    } else {
        printk(KERN_WARNING "WFS: PID %d not on runqueue, skipping dequeue\n", p->pid);
    }
    return true;
}

static struct task_struct *pick_task_wfs(struct rq *rq)
{
    struct wfs_rq *wfs_rq = &rq->wfs;
    struct sched_wfs_entity *wfs_se;
    struct task_struct *next_task;
    struct rb_node *leftmost;
    
    /* Check if we have any WFS tasks */
    if (!wfs_rq->wfs_nr_running) {
        return NULL;
    }
    
    /* Get the leftmost node (minimum VFT) from RB-tree */
    leftmost = rb_first_cached(&wfs_rq->tasks_timeline);
    if (!leftmost) {
        /* This shouldn't happen if wfs_nr_running > 0, but be safe */
        printk(KERN_WARNING "WFS: RB-tree empty but wfs_nr_running=%u, fixing\n",
               wfs_rq->wfs_nr_running);
        wfs_rq->wfs_nr_running = 0;
        return NULL;
    }
    
    wfs_se = rb_entry(leftmost, struct sched_wfs_entity, run_node);
    next_task = task_of_wfs(wfs_se);
    
    printk(KERN_DEBUG "WFS: PICKED task PID %d, VFT=%llu, weight=%llu, %u tasks in queue\n",
           next_task->pid, wfs_se->vft, wfs_se->weight, wfs_rq->wfs_nr_running);
    
    return next_task;
}

static void put_prev_task_wfs(struct rq *rq, struct task_struct *p, struct task_struct *next)
{
    struct sched_wfs_entity *se = &p->wfs;
    u64 now = rq_clock_task(rq);
    int cpu = cpu_of(rq);
    
    printk(KERN_DEBUG "WFS: PUT_PREV task PID %d on CPU %d (next is PID %d)\n",
           p->pid, cpu, next ? next->pid : -1);
    
    /* Update execution time and virtual runtime */
    if (se->exec_start) {
        u64 delta_exec = now - se->exec_start;
        
        /* Update total runtime */
        p->se.sum_exec_runtime += delta_exec;
        se->sum_exec_runtime += delta_exec;
        
        /* Update CPU virtual time */
        update_cpu_vtime(wfs_rq, delta_exec);
        
        /* Update virtual runtime and recalculate VFT */
        update_vruntime(se, delta_exec);
        
        se->exec_start = 0;
        
        /* If task is still runnable, we need to reposition it in RB-tree */
        if (next != p && !RB_EMPTY_NODE(&se->run_node)) {
            struct wfs_rq *wfs_rq = &rq->wfs;
            
            /* Remove from current position */
            rb_erase_cached(&se->run_node, &wfs_rq->tasks_timeline);
            
            /* Re-insert at new position based on updated VFT */
            rb_add_cached(&se->run_node, &wfs_rq->tasks_timeline, wfs_entity_before);
            
            update_min_vruntime(wfs_rq);
            
            printk(KERN_DEBUG "WFS: Task PID %d repositioned in RB-tree, new VFT=%llu\n",
                   p->pid, se->vft);
        }
    }
}

static void set_next_task_wfs(struct rq *rq, struct task_struct *p, bool first)
{
    struct wfs_rq *wfs_rq = &rq->wfs;
    int cpu = cpu_of(rq);
    
    p->wfs.exec_start = rq_clock_task(rq);
    
    printk(KERN_DEBUG "WFS: SET_NEXT task PID %d on CPU %d (first=%d), %u tasks in queue\n", 
           p->pid, cpu, first, wfs_rq->wfs_nr_running);
}

static void update_curr_wfs(struct rq *rq)
{
    struct task_struct *curr = rq->curr;
    struct sched_wfs_entity *se;
    u64 now = rq_clock_task(rq);
    int cpu = cpu_of(rq);

    if (curr->sched_class != &wfs_sched_class)
        return;

    se = &curr->wfs;

    if (se->exec_start) {
        u64 delta_exec = now - se->exec_start;

        /* Update total runtime */
        curr->se.sum_exec_runtime += delta_exec;
        se->sum_exec_runtime += delta_exec;

        /* Update CPU virtual time */
        update_cpu_vtime(wfs_rq, delta_exec);

        /* Update virtual runtime continuously */
        update_vruntime(se, delta_exec);

        se->exec_start = now;
    }
}

static void task_tick_wfs(struct rq *rq, struct task_struct *p, int queued)
{
    struct wfs_rq *wfs_rq = &rq->wfs;
    struct sched_wfs_entity *se = &p->wfs;
    int cpu = cpu_of(rq);

    printk(KERN_DEBUG "WFS: TASK_TICK PID %d on CPU %d (queued=%d), VFT=%llu, %u tasks in queue\n",
           p->pid, cpu, queued, se->vft, wfs_rq->wfs_nr_running);

    /* Update runtime stats first */
    update_curr_wfs(rq);

    /*
     * WFS: each task runs for exactly 1 tick quantum
     * Always preempt after 1 tick if there are other tasks
     */
    if (wfs_rq->wfs_nr_running > 1) {
        printk(KERN_DEBUG "WFS: Multiple tasks (%u) - preempting PID %d after 1 tick, VFT=%llu\n",
               wfs_rq->wfs_nr_running, p->pid, se->vft);

        /* Trigger a reschedule - put_prev_task will handle repositioning */
        resched_curr(rq);

        printk(KERN_DEBUG "WFS: Task PID %d preempted, will be repositioned based on updated VFT\n", p->pid);
    }
}

static void switched_to_wfs(struct rq *rq, struct task_struct *p)
{
    struct wfs_rq *wfs_rq = &rq->wfs;
    int cpu = cpu_of(rq);
    
    printk(KERN_INFO "WFS: Task PID %d SWITCHED_TO WFS class on CPU %d, %u tasks in queue\n", 
           p->pid, cpu, wfs_rq->wfs_nr_running);
    
    /* If this task should preempt current task */
    if (rq->curr != p && rq->curr->sched_class == &wfs_sched_class)
        resched_curr(rq);
}

static void switched_from_wfs(struct rq *rq, struct task_struct *p)
{
    struct wfs_rq *wfs_rq = &rq->wfs;
    int cpu = cpu_of(rq);
    
    printk(KERN_INFO "WFS: Task PID %d SWITCHED_FROM WFS class on CPU %d, %u tasks in queue\n", 
           p->pid, cpu, wfs_rq->wfs_nr_running);
    
    /* Clean up when task leaves WFS */
    if (p->wfs.exec_start) {
        u64 delta_exec = rq_clock_task(rq) - p->wfs.exec_start;
        p->se.sum_exec_runtime += delta_exec;
        update_cpu_vtime(&rq->wfs, delta_exec);
        p->wfs.exec_start = 0;
    }
}

static void check_preempt_curr_wfs(struct rq *rq, struct task_struct *p, int flags)
{
    /* For now, WFS is non-preemptive except for round-robin in task_tick */
    /* Could add preemption logic here if needed */
    printk(KERN_DEBUG "WFS: check_preempt_curr called for PID %d (flags=%d)\n", 
           p->pid, flags);
}

static void wakeup_preempt_wfs(struct rq *rq, struct task_struct *p, int flags)
{
    /* 
     * Called when a task wakes up to determine if it should preempt current task.
     * For WFS round-robin, we don't do immediate preemption on wakeup.
     * Tasks will be scheduled in round-robin order via task_tick.
     */
    printk(KERN_DEBUG "WFS: wakeup_preempt called for PID %d (flags=%d)\n", 
           p->pid, flags);
}

void init_wfs_rq(struct wfs_rq *wfs_rq)
{
    INIT_LIST_HEAD(&wfs_rq->queue);
    wfs_rq->tasks_timeline = RB_ROOT_CACHED;
    wfs_rq->wfs_nr_running = 0;
    wfs_rq->min_vruntime = 0;
    wfs_rq->cpu_total_weight = 0;
    wfs_rq->cpu_vtime = 0;
    printk(KERN_INFO "WFS: Runqueue initialized\n");
}

/* Existing initialization function already handles everything */

/* Enhanced SMP hooks for wfs scheduler */

static int select_task_rq_wfs(struct task_struct *p, int cpu, int flags)
{
    int best_cpu;
    
    /* Find CPU with minimum total weight */
    best_cpu = find_min_weight_cpu(p);
    
    printk(KERN_DEBUG "WFS: select_task_rq for PID %d: chose CPU %d (was %d)\n",
           p->pid, best_cpu, cpu);
    
    return best_cpu;
}

static int balance_wfs(struct rq *rq, struct task_struct *prev, struct rq_flags *rf)
{
    /* No-op balancing for now - load balancing happens at task placement */
    return 0;
}

static void migrate_task_rq_wfs(struct task_struct *p, int new_cpu)
{
    struct sched_wfs_entity *se = &p->wfs;
    int old_cpu = se->assigned_cpu;
    
    if (old_cpu != new_cpu && se->weight > 0) {
        /* Remove weight from old CPU and add to new CPU */
        if (old_cpu >= 0 && old_cpu < nr_cpu_ids) {
            struct rq *old_rq = cpu_rq(old_cpu);
            remove_task_from_cpu_weight(&old_rq->wfs, se->weight);
        }
        
        struct rq *new_rq = cpu_rq(new_cpu);
        add_task_to_cpu_weight(&new_rq->wfs, se->weight);
        se->assigned_cpu = new_cpu;
        
        printk(KERN_DEBUG "WFS: Task PID %d migrated from CPU %d to CPU %d, weight=%llu\n",
               p->pid, old_cpu, new_cpu, se->weight);
    }
}

static void rq_online_wfs(struct rq *rq)
{
    int cpu = cpu_of(rq);
    printk(KERN_INFO "WFS: CPU %d came online\n", cpu);
}

static void rq_offline_wfs(struct rq *rq)
{
    int cpu = cpu_of(rq);
    struct wfs_rq *wfs_rq = &rq->wfs;
    
    printk(KERN_INFO "WFS: CPU %d going offline, had total weight %llu\n",
           cpu, wfs_rq->cpu_total_weight);
}

static void task_woken_wfs(struct rq *rq, struct task_struct *p)
{
    /* No-op - nothing to do after remote wakeup */
}

static void set_cpus_allowed_wfs(struct task_struct *p, struct affinity_context *ctx)
{
    /* Could implement logic to rebalance if affinity changes */
    printk(KERN_DEBUG "WFS: CPU affinity changed for PID %d\n", p->pid);
}

static bool yield_to_task_wfs(struct rq *rq, struct task_struct *p)
{
    /* Return false - don't handle yield_to */
    return false;
}

const struct sched_class wfs_sched_class __section("__wfs_sched_class") = {
    .enqueue_task = enqueue_task_wfs,
    .dequeue_task = dequeue_task_wfs,
    .pick_task = pick_task_wfs,
    .put_prev_task = put_prev_task_wfs,
    .set_next_task = set_next_task_wfs,
    .task_tick = task_tick_wfs,
    .switched_to = switched_to_wfs,
    .switched_from = switched_from_wfs,
    .wakeup_preempt = wakeup_preempt_wfs,
    .update_curr = update_curr_wfs,
    .yield_to_task = yield_to_task_wfs,

#ifdef CONFIG_SMP
    .balance = balance_wfs,
    .select_task_rq = select_task_rq_wfs,
    .migrate_task_rq = migrate_task_rq_wfs,
    .rq_online = rq_online_wfs,
    .rq_offline = rq_offline_wfs,
    .task_woken = task_woken_wfs,
    .set_cpus_allowed = set_cpus_allowed_wfs,
#endif
};
/* 6118 */
````

## Summary of Required Changes:

**1. Update your `sched_wfs_entity` struct** by adding:
```c
int assigned_cpu;    // Which CPU this task is assigned to
```

**2. Update your `wfs_rq` struct** by adding:
```c
u64 cpu_total_weight; // Total weight of all tasks on this CPU  
u64 cpu_vtime;       // Virtual time for this CPU
```

**3. The `p->cpus_ptr` field** contains the CPU affinity mask. This points to a `cpumask_t` that represents which CPUs the task is allowed to run on. The kernel maintains this field when users call `sched_setaffinity()` or when the kernel needs to restrict CPU access.

Looking at the `task_struct`, I can see:
- `cpus_ptr` points to the current effective CPU mask
- `cpus_mask` is the storage for the CPU mask 
- `nr_cpus_allowed` tracks how many CPUs are allowed

The `p->cpus_ptr` approach is the correct way to access a task's allowed CPU set in the modern kernel.

With these changes, your compilation errors should be resolved and the load balancing functionality will work correctly.



## Prompt:
9/23/2025, 3:00:17 PM

Updated those things, but now seeing this compilation error

kernel/sched/wfs.c: In function ‘put_prev_task_wfs’:
kernel/sched/wfs.c:256:26: error: ‘wfs_rq’ undeclared (first use in this function)
  256 |         update_cpu_vtime(wfs_rq, delta_exec);
      |                          ^~~~~~
kernel/sched/wfs.c:256:26: note: each undeclared identifier is reported only once for each function it appears in
kernel/sched/wfs.c: In function ‘update_curr_wfs’:
kernel/sched/wfs.c:312:26: error: ‘wfs_rq’ undeclared (first use in this function)
  312 |         update_cpu_vtime(wfs_rq, delta_exec);



## Response:
9/23/2025, 3:00:52 PM

The error is because in those functions, the `wfs_rq` variable isn't declared. Let me fix these compilation errors:

**Enhanced WFS Scheduler with CPU Load Balancing** ∙ Version 18

````c
/* 6118 */
#include <linux/mmu_context.h>
#include "sched.h"
#include "wfs.h"

/* No separate per-CPU structure needed - using wfs_rq instead */

/* Find the CPU with minimum total weight */
static int find_min_weight_cpu(struct task_struct *p)
{
    int cpu, best_cpu = -1;
    u64 min_weight = ULLONG_MAX;
    const struct cpumask *allowed_mask = p->cpus_ptr;
    
    for_each_cpu(cpu, allowed_mask) {
        struct rq *cpu_rq = cpu_rq(cpu);
        struct wfs_rq *wfs_rq = &cpu_rq->wfs;
        
        /* Skip offline CPUs */
        if (!cpu_online(cpu))
            continue;
            
        /* Find CPU with minimum weight, breaking ties with lowest CPU number */
        if (wfs_rq->cpu_total_weight < min_weight) {
            min_weight = wfs_rq->cpu_total_weight;
            best_cpu = cpu;
        }
    }
    
    /* Fallback to current CPU if no suitable CPU found */
    if (best_cpu == -1)
        best_cpu = smp_processor_id();
        
    return best_cpu;
}

/* Add task weight to CPU's total weight */
static void add_task_to_cpu_weight(struct wfs_rq *wfs_rq, u64 weight)
{
    wfs_rq->cpu_total_weight += weight;
    
    printk(KERN_DEBUG "WFS: Added weight %llu to CPU, total weight now %llu\n",
           weight, wfs_rq->cpu_total_weight);
}

/* Remove task weight from CPU's total weight */
static void remove_task_from_cpu_weight(struct wfs_rq *wfs_rq, u64 weight)
{
    if (wfs_rq->cpu_total_weight >= weight) {
        wfs_rq->cpu_total_weight -= weight;
    } else {
        printk(KERN_WARNING "WFS: CPU weight underflow, resetting to 0\n");
        wfs_rq->cpu_total_weight = 0;
    }
    
    printk(KERN_DEBUG "WFS: Removed weight %llu from CPU, total weight now %llu\n",
           weight, wfs_rq->cpu_total_weight);
}

/* Update CPU virtual time based on execution time */
static void update_cpu_vtime(struct wfs_rq *wfs_rq, u64 delta_exec)
{
    if (wfs_rq->cpu_total_weight > 0) {
        u64 vtime_delta = (delta_exec * WFS_SCALE_FACTOR) / wfs_rq->cpu_total_weight;
        wfs_rq->cpu_vtime += vtime_delta;
        
        printk(KERN_DEBUG "WFS: CPU vtime updated by %llu, now %llu (weight=%llu)\n",
               vtime_delta, wfs_rq->cpu_vtime, wfs_rq->cpu_total_weight);
    }
}

/* Get current CPU virtual time */
static u64 get_cpu_vtime(struct wfs_rq *wfs_rq)
{
    return wfs_rq->cpu_vtime;
}

/* Update virtual runtime and VFT for a task */
static void update_vruntime(struct sched_wfs_entity *se, u64 delta_exec)
{
    u64 vdelta = calc_delta_fair(delta_exec, se);
    se->vruntime += vdelta;
    
    /* Calculate VFT = vruntime + (1 tick scaled) / weight */
    u64 tick_ns = TICK_NSEC; /* Duration of 1 tick in nanoseconds */
    u64 scaled_tick = calc_delta_fair(tick_ns, se);
    se->vft = se->vruntime + scaled_tick;
}

/* Initialize virtual time for new tasks */
static void place_entity(struct wfs_rq *wfs_rq, struct sched_wfs_entity *se, int cpu)
{
    /* Initialize weight if not set */
    if (!se->weight) {
        se->weight = WFS_DEFAULT_WEIGHT;
        se->inv_weight = WFS_SCALE_FACTOR / se->weight;
    }
    
    /* Set task's virtual time to current CPU virtual time */
    se->vruntime = get_cpu_vtime(wfs_rq);
    
    /* If this is greater than min_vruntime, use min_vruntime to prevent starvation */
    if (se->vruntime < wfs_rq->min_vruntime) {
        se->vruntime = wfs_rq->min_vruntime;
    }
    
    /* Calculate initial VFT */
    u64 tick_ns = TICK_NSEC;
    u64 scaled_tick = calc_delta_fair(tick_ns, se);
    se->vft = se->vruntime + scaled_tick;
    
    /* Record which CPU this task is assigned to */
    se->assigned_cpu = cpu;
    
    printk(KERN_DEBUG "WFS: Task placed with vruntime=%llu, VFT=%llu on CPU %d (CPU vtime=%llu)\n",
           se->vruntime, se->vft, cpu, get_cpu_vtime(wfs_rq));
}

/* Update min_vruntime for the runqueue */
static void update_min_vruntime(struct wfs_rq *wfs_rq)
{
    struct rb_node *leftmost = rb_first_cached(&wfs_rq->tasks_timeline);
    u64 vruntime = wfs_rq->min_vruntime;

    if (leftmost) {
        struct sched_wfs_entity *se = rb_entry(leftmost, struct sched_wfs_entity, run_node);
        vruntime = se->vruntime;
    }

    /* min_vruntime should never go backwards */
    wfs_rq->min_vruntime = max(wfs_rq->min_vruntime, vruntime);
}

/* Main scheduler functions */

static void enqueue_task_wfs(struct rq *rq, struct task_struct *p, int flags)
{
    struct wfs_rq *wfs_rq = &rq->wfs;
    struct sched_wfs_entity *se = &p->wfs;
    int cpu = cpu_of(rq);

    /* Only add if not already on RB-tree */
    if (RB_EMPTY_NODE(&se->run_node)) {
        /* Initialize virtual time for new or waking tasks */
        if (!(flags & ENQUEUE_WAKEUP) || se->vruntime == 0) {
            place_entity(wfs_rq, se, cpu);
        } else {
            /* Waking task - recalculate VFT based on current vruntime */
            u64 tick_ns = TICK_NSEC;
            u64 scaled_tick = calc_delta_fair(tick_ns, se);
            se->vft = se->vruntime + scaled_tick;
        }

        /* Add task weight to CPU's total weight */
        add_task_to_cpu_weight(wfs_rq, se->weight);

        /* Insert into RB-tree ordered by VFT */
        rb_add_cached(&se->run_node, &wfs_rq->tasks_timeline, wfs_entity_before);

        wfs_rq->wfs_nr_running++;

        /* Also add to list for compatibility */
        if (list_empty(&se->run_list)) {
            list_add_tail(&se->run_list, &wfs_rq->queue);
        }

        update_min_vruntime(wfs_rq);

        printk(KERN_INFO "WFS: PID %d ENQUEUED on CPU %d (flags=%d), vruntime=%llu, VFT=%llu, weight=%llu, runqueue now has %u tasks\n",
               p->pid, cpu, flags, se->vruntime, se->vft, se->weight, wfs_rq->wfs_nr_running);
    } else {
        printk(KERN_WARNING "WFS: PID %d already on runqueue, skipping enqueue\n", p->pid);
    }
}

static bool dequeue_task_wfs(struct rq *rq, struct task_struct *p, int flags)
{
    struct wfs_rq *wfs_rq = &rq->wfs;
    struct sched_wfs_entity *se = &p->wfs;
    int cpu = cpu_of(rq);

    /* Only remove if actually in RB-tree */
    if (!RB_EMPTY_NODE(&se->run_node)) {
        /* Remove task weight from CPU's total weight */
        remove_task_from_cpu_weight(wfs_rq, se->weight);

        rb_erase_cached(&se->run_node, &wfs_rq->tasks_timeline);
        RB_CLEAR_NODE(&se->run_node);

        wfs_rq->wfs_nr_running--;

        /* Also remove from list */
        if (!list_empty(&se->run_list)) {
            list_del_init(&se->run_list);
        }

        update_min_vruntime(wfs_rq);

        printk(KERN_INFO "WFS: PID %d DEQUEUED from CPU %d (flags=%d), weight=%llu, runqueue now has %u tasks\n",
               p->pid, cpu, flags, se->weight, wfs_rq->wfs_nr_running);
    } else {
        printk(KERN_WARNING "WFS: PID %d not on runqueue, skipping dequeue\n", p->pid);
    }
    return true;
}

static struct task_struct *pick_task_wfs(struct rq *rq)
{
    struct wfs_rq *wfs_rq = &rq->wfs;
    struct sched_wfs_entity *wfs_se;
    struct task_struct *next_task;
    struct rb_node *leftmost;
    
    /* Check if we have any WFS tasks */
    if (!wfs_rq->wfs_nr_running) {
        return NULL;
    }
    
    /* Get the leftmost node (minimum VFT) from RB-tree */
    leftmost = rb_first_cached(&wfs_rq->tasks_timeline);
    if (!leftmost) {
        /* This shouldn't happen if wfs_nr_running > 0, but be safe */
        printk(KERN_WARNING "WFS: RB-tree empty but wfs_nr_running=%u, fixing\n",
               wfs_rq->wfs_nr_running);
        wfs_rq->wfs_nr_running = 0;
        return NULL;
    }
    
    wfs_se = rb_entry(leftmost, struct sched_wfs_entity, run_node);
    next_task = task_of_wfs(wfs_se);
    
    printk(KERN_DEBUG "WFS: PICKED task PID %d, VFT=%llu, weight=%llu, %u tasks in queue\n",
           next_task->pid, wfs_se->vft, wfs_se->weight, wfs_rq->wfs_nr_running);
    
    return next_task;
}

static void put_prev_task_wfs(struct rq *rq, struct task_struct *p, struct task_struct *next)
{
    struct wfs_rq *wfs_rq = &rq->wfs;
    struct sched_wfs_entity *se = &p->wfs;
    u64 now = rq_clock_task(rq);
    int cpu = cpu_of(rq);
    
    printk(KERN_DEBUG "WFS: PUT_PREV task PID %d on CPU %d (next is PID %d)\n",
           p->pid, cpu, next ? next->pid : -1);
    
    /* Update execution time and virtual runtime */
    if (se->exec_start) {
        u64 delta_exec = now - se->exec_start;
        
        /* Update total runtime */
        p->se.sum_exec_runtime += delta_exec;
        se->sum_exec_runtime += delta_exec;
        
        /* Update CPU virtual time */
        update_cpu_vtime(wfs_rq, delta_exec);
        
        /* Update virtual runtime and recalculate VFT */
        update_vruntime(se, delta_exec);
        
        se->exec_start = 0;
        
        /* If task is still runnable, we need to reposition it in RB-tree */
        if (next != p && !RB_EMPTY_NODE(&se->run_node)) {
            /* Remove from current position */
            rb_erase_cached(&se->run_node, &wfs_rq->tasks_timeline);
            
            /* Re-insert at new position based on updated VFT */
            rb_add_cached(&se->run_node, &wfs_rq->tasks_timeline, wfs_entity_before);
            
            update_min_vruntime(wfs_rq);
            
            printk(KERN_DEBUG "WFS: Task PID %d repositioned in RB-tree, new VFT=%llu\n",
                   p->pid, se->vft);
        }
    }
}

static void set_next_task_wfs(struct rq *rq, struct task_struct *p, bool first)
{
    struct wfs_rq *wfs_rq = &rq->wfs;
    int cpu = cpu_of(rq);
    
    p->wfs.exec_start = rq_clock_task(rq);
    
    printk(KERN_DEBUG "WFS: SET_NEXT task PID %d on CPU %d (first=%d), %u tasks in queue\n", 
           p->pid, cpu, first, wfs_rq->wfs_nr_running);
}

static void update_curr_wfs(struct rq *rq)
{
    struct wfs_rq *wfs_rq = &rq->wfs;
    struct task_struct *curr = rq->curr;
    struct sched_wfs_entity *se;
    u64 now = rq_clock_task(rq);
    int cpu = cpu_of(rq);

    if (curr->sched_class != &wfs_sched_class)
        return;

    se = &curr->wfs;

    if (se->exec_start) {
        u64 delta_exec = now - se->exec_start;

        /* Update total runtime */
        curr->se.sum_exec_runtime += delta_exec;
        se->sum_exec_runtime += delta_exec;

        /* Update CPU virtual time */
        update_cpu_vtime(wfs_rq, delta_exec);

        /* Update virtual runtime continuously */
        update_vruntime(se, delta_exec);

        se->exec_start = now;
    }
}

static void task_tick_wfs(struct rq *rq, struct task_struct *p, int queued)
{
    struct wfs_rq *wfs_rq = &rq->wfs;
    struct sched_wfs_entity *se = &p->wfs;
    int cpu = cpu_of(rq);

    printk(KERN_DEBUG "WFS: TASK_TICK PID %d on CPU %d (queued=%d), VFT=%llu, %u tasks in queue\n",
           p->pid, cpu, queued, se->vft, wfs_rq->wfs_nr_running);

    /* Update runtime stats first */
    update_curr_wfs(rq);

    /*
     * WFS: each task runs for exactly 1 tick quantum
     * Always preempt after 1 tick if there are other tasks
     */
    if (wfs_rq->wfs_nr_running > 1) {
        printk(KERN_DEBUG "WFS: Multiple tasks (%u) - preempting PID %d after 1 tick, VFT=%llu\n",
               wfs_rq->wfs_nr_running, p->pid, se->vft);

        /* Trigger a reschedule - put_prev_task will handle repositioning */
        resched_curr(rq);

        printk(KERN_DEBUG "WFS: Task PID %d preempted, will be repositioned based on updated VFT\n", p->pid);
    }
}

static void switched_to_wfs(struct rq *rq, struct task_struct *p)
{
    struct wfs_rq *wfs_rq = &rq->wfs;
    int cpu = cpu_of(rq);
    
    printk(KERN_INFO "WFS: Task PID %d SWITCHED_TO WFS class on CPU %d, %u tasks in queue\n", 
           p->pid, cpu, wfs_rq->wfs_nr_running);
    
    /* If this task should preempt current task */
    if (rq->curr != p && rq->curr->sched_class == &wfs_sched_class)
        resched_curr(rq);
}

static void switched_from_wfs(struct rq *rq, struct task_struct *p)
{
    struct wfs_rq *wfs_rq = &rq->wfs;
    int cpu = cpu_of(rq);
    
    printk(KERN_INFO "WFS: Task PID %d SWITCHED_FROM WFS class on CPU %d, %u tasks in queue\n", 
           p->pid, cpu, wfs_rq->wfs_nr_running);
    
    /* Clean up when task leaves WFS */
    if (p->wfs.exec_start) {
        u64 delta_exec = rq_clock_task(rq) - p->wfs.exec_start;
        p->se.sum_exec_runtime += delta_exec;
        update_cpu_vtime(&rq->wfs, delta_exec);
        p->wfs.exec_start = 0;
    }
}

static void check_preempt_curr_wfs(struct rq *rq, struct task_struct *p, int flags)
{
    /* For now, WFS is non-preemptive except for round-robin in task_tick */
    /* Could add preemption logic here if needed */
    printk(KERN_DEBUG "WFS: check_preempt_curr called for PID %d (flags=%d)\n", 
           p->pid, flags);
}

static void wakeup_preempt_wfs(struct rq *rq, struct task_struct *p, int flags)
{
    /* 
     * Called when a task wakes up to determine if it should preempt current task.
     * For WFS round-robin, we don't do immediate preemption on wakeup.
     * Tasks will be scheduled in round-robin order via task_tick.
     */
    printk(KERN_DEBUG "WFS: wakeup_preempt called for PID %d (flags=%d)\n", 
           p->pid, flags);
}

void init_wfs_rq(struct wfs_rq *wfs_rq)
{
    INIT_LIST_HEAD(&wfs_rq->queue);
    wfs_rq->tasks_timeline = RB_ROOT_CACHED;
    wfs_rq->wfs_nr_running = 0;
    wfs_rq->min_vruntime = 0;
    wfs_rq->cpu_total_weight = 0;
    wfs_rq->cpu_vtime = 0;
    printk(KERN_INFO "WFS: Runqueue initialized\n");
}

/* Existing initialization function already handles everything */

/* Enhanced SMP hooks for wfs scheduler */

static int select_task_rq_wfs(struct task_struct *p, int cpu, int flags)
{
    int best_cpu;
    
    /* Find CPU with minimum total weight */
    best_cpu = find_min_weight_cpu(p);
    
    printk(KERN_DEBUG "WFS: select_task_rq for PID %d: chose CPU %d (was %d)\n",
           p->pid, best_cpu, cpu);
    
    return best_cpu;
}

static int balance_wfs(struct rq *rq, struct task_struct *prev, struct rq_flags *rf)
{
    /* No-op balancing for now - load balancing happens at task placement */
    return 0;
}

static void migrate_task_rq_wfs(struct task_struct *p, int new_cpu)
{
    struct sched_wfs_entity *se = &p->wfs;
    int old_cpu = se->assigned_cpu;
    
    if (old_cpu != new_cpu && se->weight > 0) {
        /* Remove weight from old CPU and add to new CPU */
        if (old_cpu >= 0 && old_cpu < nr_cpu_ids) {
            struct rq *old_rq = cpu_rq(old_cpu);
            remove_task_from_cpu_weight(&old_rq->wfs, se->weight);
        }
        
        struct rq *new_rq = cpu_rq(new_cpu);
        add_task_to_cpu_weight(&new_rq->wfs, se->weight);
        se->assigned_cpu = new_cpu;
        
        printk(KERN_DEBUG "WFS: Task PID %d migrated from CPU %d to CPU %d, weight=%llu\n",
               p->pid, old_cpu, new_cpu, se->weight);
    }
}

static void rq_online_wfs(struct rq *rq)
{
    int cpu = cpu_of(rq);
    printk(KERN_INFO "WFS: CPU %d came online\n", cpu);
}

static void rq_offline_wfs(struct rq *rq)
{
    int cpu = cpu_of(rq);
    struct wfs_rq *wfs_rq = &rq->wfs;
    
    printk(KERN_INFO "WFS: CPU %d going offline, had total weight %llu\n",
           cpu, wfs_rq->cpu_total_weight);
}

static void task_woken_wfs(struct rq *rq, struct task_struct *p)
{
    /* No-op - nothing to do after remote wakeup */
}

static void set_cpus_allowed_wfs(struct task_struct *p, struct affinity_context *ctx)
{
    /* Could implement logic to rebalance if affinity changes */
    printk(KERN_DEBUG "WFS: CPU affinity changed for PID %d\n", p->pid);
}

static bool yield_to_task_wfs(struct rq *rq, struct task_struct *p)
{
    /* Return false - don't handle yield_to */
    return false;
}

const struct sched_class wfs_sched_class __section("__wfs_sched_class") = {
    .enqueue_task = enqueue_task_wfs,
    .dequeue_task = dequeue_task_wfs,
    .pick_task = pick_task_wfs,
    .put_prev_task = put_prev_task_wfs,
    .set_next_task = set_next_task_wfs,
    .task_tick = task_tick_wfs,
    .switched_to = switched_to_wfs,
    .switched_from = switched_from_wfs,
    .wakeup_preempt = wakeup_preempt_wfs,
    .update_curr = update_curr_wfs,
    .yield_to_task = yield_to_task_wfs,

#ifdef CONFIG_SMP
    .balance = balance_wfs,
    .select_task_rq = select_task_rq_wfs,
    .migrate_task_rq = migrate_task_rq_wfs,
    .rq_online = rq_online_wfs,
    .rq_offline = rq_offline_wfs,
    .task_woken = task_woken_wfs,
    .set_cpus_allowed = set_cpus_allowed_wfs,
#endif
};
/* 6118 */
````

I've fixed both compilation errors by declaring the `wfs_rq` variable at the beginning of each function:

## Fixed Issues:

1. **`put_prev_task_wfs`**: Added `struct wfs_rq *wfs_rq = &rq->wfs;` at the top of the function
2. **`update_curr_wfs`**: Added `struct wfs_rq *wfs_rq = &rq->wfs;` at the top of the function

The issue was that I was calling `update_cpu_vtime(wfs_rq, delta_exec)` but hadn't declared the `wfs_rq` variable in the function scope. Now both functions properly declare the `wfs_rq` pointer by extracting it from the runqueue parameter.

These were simple scoping errors - the variable was being used before it was declared. The compilation should now succeed.



## Prompt:
9/23/2025, 3:05:49 PM

kernel/sched/wfs.c: In function ‘migrate_task_rq_wfs’:
./include/linux/kern_levels.h:5:25: warning: format ‘%llu’ expects argument of type ‘long long unsigned int’, but argument 5 has type ‘u32’ {aka ‘unsigned int’} [-Wformat=]
    5 | #define KERN_SOH        "\001"          /* ASCII Start Of Header */
      |                         ^~~~~~
./include/linux/printk.h:473:25: note: in definition of macro ‘printk_index_wrap’
  473 |                 *p*func(_fmt, ##__VA_ARGS__);                           \
      |                         ^~~~
kernel/sched/wfs.c:447:9: note: in expansion of macro ‘printk’
  447 |         printk(KERN_DEBUG "WFS: Task PID %d migrated from CPU %d to CPU %d, weight=%llu\n",
      |         ^~~~~~
./include/linux/kern_levels.h:15:25: note: in expansion of macro ‘KERN_SOH’
   15 | #define KERN_DEBUG      KERN_SOH "7"    /* debug-level messages */
      |                         ^~~~~~~~
kernel/sched/wfs.c:447:16: note: in expansion of macro ‘KERN_DEBUG’
  447 |         printk(KERN_DEBUG "WFS: Task PID %d migrated from CPU %d to CPU %d, weight=%llu\n",
      |                ^~~~~~~~~~

any idea what these warnings are?



## Response:
9/23/2025, 3:06:42 PM

This warning is about a format string mismatch. The issue is that `se->weight` is defined as `u32` (32-bit unsigned integer) in your `sched_wfs_entity` struct, but you're using `%llu` format specifier which expects a `long long unsigned int` (64-bit).

Here's the fix:

**Enhanced WFS Scheduler with CPU Load Balancing** ∙ Version 19

````c
/* 6118 */
#include <linux/mmu_context.h>
#include "sched.h"
#include "wfs.h"

/* No separate per-CPU structure needed - using wfs_rq instead */

/* Find the CPU with minimum total weight */
static int find_min_weight_cpu(struct task_struct *p)
{
    int cpu, best_cpu = -1;
    u64 min_weight = ULLONG_MAX;
    const struct cpumask *allowed_mask = p->cpus_ptr;
    
    for_each_cpu(cpu, allowed_mask) {
        struct rq *cpu_rq = cpu_rq(cpu);
        struct wfs_rq *wfs_rq = &cpu_rq->wfs;
        
        /* Skip offline CPUs */
        if (!cpu_online(cpu))
            continue;
            
        /* Find CPU with minimum weight, breaking ties with lowest CPU number */
        if (wfs_rq->cpu_total_weight < min_weight) {
            min_weight = wfs_rq->cpu_total_weight;
            best_cpu = cpu;
        }
    }
    
    /* Fallback to current CPU if no suitable CPU found */
    if (best_cpu == -1)
        best_cpu = smp_processor_id();
        
    return best_cpu;
}

/* Add task weight to CPU's total weight */
static void add_task_to_cpu_weight(struct wfs_rq *wfs_rq, u64 weight)
{
    wfs_rq->cpu_total_weight += weight;
    
    printk(KERN_DEBUG "WFS: Added weight %llu to CPU, total weight now %llu\n",
           weight, wfs_rq->cpu_total_weight);
}

/* Remove task weight from CPU's total weight */
static void remove_task_from_cpu_weight(struct wfs_rq *wfs_rq, u64 weight)
{
    if (wfs_rq->cpu_total_weight >= weight) {
        wfs_rq->cpu_total_weight -= weight;
    } else {
        printk(KERN_WARNING "WFS: CPU weight underflow, resetting to 0\n");
        wfs_rq->cpu_total_weight = 0;
    }
    
    printk(KERN_DEBUG "WFS: Removed weight %llu from CPU, total weight now %llu\n",
           weight, wfs_rq->cpu_total_weight);
}

/* Update CPU virtual time based on execution time */
static void update_cpu_vtime(struct wfs_rq *wfs_rq, u64 delta_exec)
{
    if (wfs_rq->cpu_total_weight > 0) {
        u64 vtime_delta = (delta_exec * WFS_SCALE_FACTOR) / wfs_rq->cpu_total_weight;
        wfs_rq->cpu_vtime += vtime_delta;
        
        printk(KERN_DEBUG "WFS: CPU vtime updated by %llu, now %llu (weight=%llu)\n",
               vtime_delta, wfs_rq->cpu_vtime, wfs_rq->cpu_total_weight);
    }
}

/* Get current CPU virtual time */
static u64 get_cpu_vtime(struct wfs_rq *wfs_rq)
{
    return wfs_rq->cpu_vtime;
}

/* Update virtual runtime and VFT for a task */
static void update_vruntime(struct sched_wfs_entity *se, u64 delta_exec)
{
    u64 vdelta = calc_delta_fair(delta_exec, se);
    se->vruntime += vdelta;
    
    /* Calculate VFT = vruntime + (1 tick scaled) / weight */
    u64 tick_ns = TICK_NSEC; /* Duration of 1 tick in nanoseconds */
    u64 scaled_tick = calc_delta_fair(tick_ns, se);
    se->vft = se->vruntime + scaled_tick;
}

/* Initialize virtual time for new tasks */
static void place_entity(struct wfs_rq *wfs_rq, struct sched_wfs_entity *se, int cpu)
{
    /* Initialize weight if not set */
    if (!se->weight) {
        se->weight = WFS_DEFAULT_WEIGHT;
        se->inv_weight = WFS_SCALE_FACTOR / se->weight;
    }
    
    /* Set task's virtual time to current CPU virtual time */
    se->vruntime = get_cpu_vtime(wfs_rq);
    
    /* If this is greater than min_vruntime, use min_vruntime to prevent starvation */
    if (se->vruntime < wfs_rq->min_vruntime) {
        se->vruntime = wfs_rq->min_vruntime;
    }
    
    /* Calculate initial VFT */
    u64 tick_ns = TICK_NSEC;
    u64 scaled_tick = calc_delta_fair(tick_ns, se);
    se->vft = se->vruntime + scaled_tick;
    
    /* Record which CPU this task is assigned to */
    se->assigned_cpu = cpu;
    
    printk(KERN_DEBUG "WFS: Task placed with vruntime=%llu, VFT=%llu on CPU %d (CPU vtime=%llu)\n",
           se->vruntime, se->vft, cpu, get_cpu_vtime(wfs_rq));
}

/* Update min_vruntime for the runqueue */
static void update_min_vruntime(struct wfs_rq *wfs_rq)
{
    struct rb_node *leftmost = rb_first_cached(&wfs_rq->tasks_timeline);
    u64 vruntime = wfs_rq->min_vruntime;

    if (leftmost) {
        struct sched_wfs_entity *se = rb_entry(leftmost, struct sched_wfs_entity, run_node);
        vruntime = se->vruntime;
    }

    /* min_vruntime should never go backwards */
    wfs_rq->min_vruntime = max(wfs_rq->min_vruntime, vruntime);
}

/* Main scheduler functions */

static void enqueue_task_wfs(struct rq *rq, struct task_struct *p, int flags)
{
    struct wfs_rq *wfs_rq = &rq->wfs;
    struct sched_wfs_entity *se = &p->wfs;
    int cpu = cpu_of(rq);

    /* Only add if not already on RB-tree */
    if (RB_EMPTY_NODE(&se->run_node)) {
        /* Initialize virtual time for new or waking tasks */
        if (!(flags & ENQUEUE_WAKEUP) || se->vruntime == 0) {
            place_entity(wfs_rq, se, cpu);
        } else {
            /* Waking task - recalculate VFT based on current vruntime */
            u64 tick_ns = TICK_NSEC;
            u64 scaled_tick = calc_delta_fair(tick_ns, se);
            se->vft = se->vruntime + scaled_tick;
        }

        /* Add task weight to CPU's total weight */
        add_task_to_cpu_weight(wfs_rq, se->weight);

        /* Insert into RB-tree ordered by VFT */
        rb_add_cached(&se->run_node, &wfs_rq->tasks_timeline, wfs_entity_before);

        wfs_rq->wfs_nr_running++;

        /* Also add to list for compatibility */
        if (list_empty(&se->run_list)) {
            list_add_tail(&se->run_list, &wfs_rq->queue);
        }

        update_min_vruntime(wfs_rq);

        printk(KERN_INFO "WFS: PID %d ENQUEUED on CPU %d (flags=%d), vruntime=%llu, VFT=%llu, weight=%llu, runqueue now has %u tasks\n",
               p->pid, cpu, flags, se->vruntime, se->vft, se->weight, wfs_rq->wfs_nr_running);
    } else {
        printk(KERN_WARNING "WFS: PID %d already on runqueue, skipping enqueue\n", p->pid);
    }
}

static bool dequeue_task_wfs(struct rq *rq, struct task_struct *p, int flags)
{
    struct wfs_rq *wfs_rq = &rq->wfs;
    struct sched_wfs_entity *se = &p->wfs;
    int cpu = cpu_of(rq);

    /* Only remove if actually in RB-tree */
    if (!RB_EMPTY_NODE(&se->run_node)) {
        /* Remove task weight from CPU's total weight */
        remove_task_from_cpu_weight(wfs_rq, se->weight);

        rb_erase_cached(&se->run_node, &wfs_rq->tasks_timeline);
        RB_CLEAR_NODE(&se->run_node);

        wfs_rq->wfs_nr_running--;

        /* Also remove from list */
        if (!list_empty(&se->run_list)) {
            list_del_init(&se->run_list);
        }

        update_min_vruntime(wfs_rq);

        printk(KERN_INFO "WFS: PID %d DEQUEUED from CPU %d (flags=%d), weight=%llu, runqueue now has %u tasks\n",
               p->pid, cpu, flags, se->weight, wfs_rq->wfs_nr_running);
    } else {
        printk(KERN_WARNING "WFS: PID %d not on runqueue, skipping dequeue\n", p->pid);
    }
    return true;
}

static struct task_struct *pick_task_wfs(struct rq *rq)
{
    struct wfs_rq *wfs_rq = &rq->wfs;
    struct sched_wfs_entity *wfs_se;
    struct task_struct *next_task;
    struct rb_node *leftmost;
    
    /* Check if we have any WFS tasks */
    if (!wfs_rq->wfs_nr_running) {
        return NULL;
    }
    
    /* Get the leftmost node (minimum VFT) from RB-tree */
    leftmost = rb_first_cached(&wfs_rq->tasks_timeline);
    if (!leftmost) {
        /* This shouldn't happen if wfs_nr_running > 0, but be safe */
        printk(KERN_WARNING "WFS: RB-tree empty but wfs_nr_running=%u, fixing\n",
               wfs_rq->wfs_nr_running);
        wfs_rq->wfs_nr_running = 0;
        return NULL;
    }
    
    wfs_se = rb_entry(leftmost, struct sched_wfs_entity, run_node);
    next_task = task_of_wfs(wfs_se);
    
    printk(KERN_DEBUG "WFS: PICKED task PID %d, VFT=%llu, weight=%llu, %u tasks in queue\n",
           next_task->pid, wfs_se->vft, wfs_se->weight, wfs_rq->wfs_nr_running);
    
    return next_task;
}

static void put_prev_task_wfs(struct rq *rq, struct task_struct *p, struct task_struct *next)
{
    struct wfs_rq *wfs_rq = &rq->wfs;
    struct sched_wfs_entity *se = &p->wfs;
    u64 now = rq_clock_task(rq);
    int cpu = cpu_of(rq);
    
    printk(KERN_DEBUG "WFS: PUT_PREV task PID %d on CPU %d (next is PID %d)\n",
           p->pid, cpu, next ? next->pid : -1);
    
    /* Update execution time and virtual runtime */
    if (se->exec_start) {
        u64 delta_exec = now - se->exec_start;
        
        /* Update total runtime */
        p->se.sum_exec_runtime += delta_exec;
        se->sum_exec_runtime += delta_exec;
        
        /* Update CPU virtual time */
        update_cpu_vtime(wfs_rq, delta_exec);
        
        /* Update virtual runtime and recalculate VFT */
        update_vruntime(se, delta_exec);
        
        se->exec_start = 0;
        
        /* If task is still runnable, we need to reposition it in RB-tree */
        if (next != p && !RB_EMPTY_NODE(&se->run_node)) {
            /* Remove from current position */
            rb_erase_cached(&se->run_node, &wfs_rq->tasks_timeline);
            
            /* Re-insert at new position based on updated VFT */
            rb_add_cached(&se->run_node, &wfs_rq->tasks_timeline, wfs_entity_before);
            
            update_min_vruntime(wfs_rq);
            
            printk(KERN_DEBUG "WFS: Task PID %d repositioned in RB-tree, new VFT=%llu\n",
                   p->pid, se->vft);
        }
    }
}

static void set_next_task_wfs(struct rq *rq, struct task_struct *p, bool first)
{
    struct wfs_rq *wfs_rq = &rq->wfs;
    int cpu = cpu_of(rq);
    
    p->wfs.exec_start = rq_clock_task(rq);
    
    printk(KERN_DEBUG "WFS: SET_NEXT task PID %d on CPU %d (first=%d), %u tasks in queue\n", 
           p->pid, cpu, first, wfs_rq->wfs_nr_running);
}

static void update_curr_wfs(struct rq *rq)
{
    struct wfs_rq *wfs_rq = &rq->wfs;
    struct task_struct *curr = rq->curr;
    struct sched_wfs_entity *se;
    u64 now = rq_clock_task(rq);
    int cpu = cpu_of(rq);

    if (curr->sched_class != &wfs_sched_class)
        return;

    se = &curr->wfs;

    if (se->exec_start) {
        u64 delta_exec = now - se->exec_start;

        /* Update total runtime */
        curr->se.sum_exec_runtime += delta_exec;
        se->sum_exec_runtime += delta_exec;

        /* Update CPU virtual time */
        update_cpu_vtime(wfs_rq, delta_exec);

        /* Update virtual runtime continuously */
        update_vruntime(se, delta_exec);

        se->exec_start = now;
    }
}

static void task_tick_wfs(struct rq *rq, struct task_struct *p, int queued)
{
    struct wfs_rq *wfs_rq = &rq->wfs;
    struct sched_wfs_entity *se = &p->wfs;
    int cpu = cpu_of(rq);

    printk(KERN_DEBUG "WFS: TASK_TICK PID %d on CPU %d (queued=%d), VFT=%llu, %u tasks in queue\n",
           p->pid, cpu, queued, se->vft, wfs_rq->wfs_nr_running);

    /* Update runtime stats first */
    update_curr_wfs(rq);

    /*
     * WFS: each task runs for exactly 1 tick quantum
     * Always preempt after 1 tick if there are other tasks
     */
    if (wfs_rq->wfs_nr_running > 1) {
        printk(KERN_DEBUG "WFS: Multiple tasks (%u) - preempting PID %d after 1 tick, VFT=%llu\n",
               wfs_rq->wfs_nr_running, p->pid, se->vft);

        /* Trigger a reschedule - put_prev_task will handle repositioning */
        resched_curr(rq);

        printk(KERN_DEBUG "WFS: Task PID %d preempted, will be repositioned based on updated VFT\n", p->pid);
    }
}

static void switched_to_wfs(struct rq *rq, struct task_struct *p)
{
    struct wfs_rq *wfs_rq = &rq->wfs;
    int cpu = cpu_of(rq);
    
    printk(KERN_INFO "WFS: Task PID %d SWITCHED_TO WFS class on CPU %d, %u tasks in queue\n", 
           p->pid, cpu, wfs_rq->wfs_nr_running);
    
    /* If this task should preempt current task */
    if (rq->curr != p && rq->curr->sched_class == &wfs_sched_class)
        resched_curr(rq);
}

static void switched_from_wfs(struct rq *rq, struct task_struct *p)
{
    struct wfs_rq *wfs_rq = &rq->wfs;
    int cpu = cpu_of(rq);
    
    printk(KERN_INFO "WFS: Task PID %d SWITCHED_FROM WFS class on CPU %d, %u tasks in queue\n", 
           p->pid, cpu, wfs_rq->wfs_nr_running);
    
    /* Clean up when task leaves WFS */
    if (p->wfs.exec_start) {
        u64 delta_exec = rq_clock_task(rq) - p->wfs.exec_start;
        p->se.sum_exec_runtime += delta_exec;
        update_cpu_vtime(&rq->wfs, delta_exec);
        p->wfs.exec_start = 0;
    }
}

static void check_preempt_curr_wfs(struct rq *rq, struct task_struct *p, int flags)
{
    /* For now, WFS is non-preemptive except for round-robin in task_tick */
    /* Could add preemption logic here if needed */
    printk(KERN_DEBUG "WFS: check_preempt_curr called for PID %d (flags=%d)\n", 
           p->pid, flags);
}

static void wakeup_preempt_wfs(struct rq *rq, struct task_struct *p, int flags)
{
    /* 
     * Called when a task wakes up to determine if it should preempt current task.
     * For WFS round-robin, we don't do immediate preemption on wakeup.
     * Tasks will be scheduled in round-robin order via task_tick.
     */
    printk(KERN_DEBUG "WFS: wakeup_preempt called for PID %d (flags=%d)\n", 
           p->pid, flags);
}

void init_wfs_rq(struct wfs_rq *wfs_rq)
{
    INIT_LIST_HEAD(&wfs_rq->queue);
    wfs_rq->tasks_timeline = RB_ROOT_CACHED;
    wfs_rq->wfs_nr_running = 0;
    wfs_rq->min_vruntime = 0;
    wfs_rq->cpu_total_weight = 0;
    wfs_rq->cpu_vtime = 0;
    printk(KERN_INFO "WFS: Runqueue initialized\n");
}

/* Existing initialization function already handles everything */

/* Enhanced SMP hooks for wfs scheduler */

static int select_task_rq_wfs(struct task_struct *p, int cpu, int flags)
{
    int best_cpu;
    
    /* Find CPU with minimum total weight */
    best_cpu = find_min_weight_cpu(p);
    
    printk(KERN_DEBUG "WFS: select_task_rq for PID %d: chose CPU %d (was %d)\n",
           p->pid, best_cpu, cpu);
    
    return best_cpu;
}

static int balance_wfs(struct rq *rq, struct task_struct *prev, struct rq_flags *rf)
{
    /* No-op balancing for now - load balancing happens at task placement */
    return 0;
}

static void migrate_task_rq_wfs(struct task_struct *p, int new_cpu)
{
    struct sched_wfs_entity *se = &p->wfs;
    int old_cpu = se->assigned_cpu;
    
    if (old_cpu != new_cpu && se->weight > 0) {
        /* Remove weight from old CPU and add to new CPU */
        if (old_cpu >= 0 && old_cpu < nr_cpu_ids) {
            struct rq *old_rq = cpu_rq(old_cpu);
            remove_task_from_cpu_weight(&old_rq->wfs, se->weight);
        }
        
        struct rq *new_rq = cpu_rq(new_cpu);
        add_task_to_cpu_weight(&new_rq->wfs, se->weight);
        se->assigned_cpu = new_cpu;
        
        printk(KERN_DEBUG "WFS: Task PID %d migrated from CPU %d to CPU %d, weight=%u\n",
               p->pid, old_cpu, new_cpu, se->weight);
    }
}

static void rq_online_wfs(struct rq *rq)
{
    int cpu = cpu_of(rq);
    printk(KERN_INFO "WFS: CPU %d came online\n", cpu);
}

static void rq_offline_wfs(struct rq *rq)
{
    int cpu = cpu_of(rq);
    struct wfs_rq *wfs_rq = &rq->wfs;
    
    printk(KERN_INFO "WFS: CPU %d going offline, had total weight %llu\n",
           cpu, wfs_rq->cpu_total_weight);
}

static void task_woken_wfs(struct rq *rq, struct task_struct *p)
{
    /* No-op - nothing to do after remote wakeup */
}

static void set_cpus_allowed_wfs(struct task_struct *p, struct affinity_context *ctx)
{
    /* Could implement logic to rebalance if affinity changes */
    printk(KERN_DEBUG "WFS: CPU affinity changed for PID %d\n", p->pid);
}

static bool yield_to_task_wfs(struct rq *rq, struct task_struct *p)
{
    /* Return false - don't handle yield_to */
    return false;
}

const struct sched_class wfs_sched_class __section("__wfs_sched_class") = {
    .enqueue_task = enqueue_task_wfs,
    .dequeue_task = dequeue_task_wfs,
    .pick_task = pick_task_wfs,
    .put_prev_task = put_prev_task_wfs,
    .set_next_task = set_next_task_wfs,
    .task_tick = task_tick_wfs,
    .switched_to = switched_to_wfs,
    .switched_from = switched_from_wfs,
    .wakeup_preempt = wakeup_preempt_wfs,
    .update_curr = update_curr_wfs,
    .yield_to_task = yield_to_task_wfs,

#ifdef CONFIG_SMP
    .balance = balance_wfs,
    .select_task_rq = select_task_rq_wfs,
    .migrate_task_rq = migrate_task_rq_wfs,
    .rq_online = rq_online_wfs,
    .rq_offline = rq_offline_wfs,
    .task_woken = task_woken_wfs,
    .set_cpus_allowed = set_cpus_allowed_wfs,
#endif
};
/* 6118 */
````

I need to fix the other format specifiers in the code too. Let me check for similar issues:

**Enhanced WFS Scheduler with CPU Load Balancing** ∙ Version 20

````c
/* 6118 */
#include <linux/mmu_context.h>
#include "sched.h"
#include "wfs.h"

/* No separate per-CPU structure needed - using wfs_rq instead */

/* Find the CPU with minimum total weight */
static int find_min_weight_cpu(struct task_struct *p)
{
    int cpu, best_cpu = -1;
    u64 min_weight = ULLONG_MAX;
    const struct cpumask *allowed_mask = p->cpus_ptr;
    
    for_each_cpu(cpu, allowed_mask) {
        struct rq *cpu_rq = cpu_rq(cpu);
        struct wfs_rq *wfs_rq = &cpu_rq->wfs;
        
        /* Skip offline CPUs */
        if (!cpu_online(cpu))
            continue;
            
        /* Find CPU with minimum weight, breaking ties with lowest CPU number */
        if (wfs_rq->cpu_total_weight < min_weight) {
            min_weight = wfs_rq->cpu_total_weight;
            best_cpu = cpu;
        }
    }
    
    /* Fallback to current CPU if no suitable CPU found */
    if (best_cpu == -1)
        best_cpu = smp_processor_id();
        
    return best_cpu;
}

/* Add task weight to CPU's total weight */
static void add_task_to_cpu_weight(struct wfs_rq *wfs_rq, u64 weight)
{
    wfs_rq->cpu_total_weight += weight;
    
    printk(KERN_DEBUG "WFS: Added weight %u to CPU, total weight now %llu\n",
           weight, wfs_rq->cpu_total_weight);
}

/* Remove task weight from CPU's total weight */
static void remove_task_from_cpu_weight(struct wfs_rq *wfs_rq, u64 weight)
{
    if (wfs_rq->cpu_total_weight >= weight) {
        wfs_rq->cpu_total_weight -= weight;
    } else {
        printk(KERN_WARNING "WFS: CPU weight underflow, resetting to 0\n");
        wfs_rq->cpu_total_weight = 0;
    }
    
    printk(KERN_DEBUG "WFS: Removed weight %llu from CPU, total weight now %llu\n",
           weight, wfs_rq->cpu_total_weight);
}

/* Update CPU virtual time based on execution time */
static void update_cpu_vtime(struct wfs_rq *wfs_rq, u64 delta_exec)
{
    if (wfs_rq->cpu_total_weight > 0) {
        u64 vtime_delta = (delta_exec * WFS_SCALE_FACTOR) / wfs_rq->cpu_total_weight;
        wfs_rq->cpu_vtime += vtime_delta;
        
        printk(KERN_DEBUG "WFS: CPU vtime updated by %llu, now %llu (weight=%llu)\n",
               vtime_delta, wfs_rq->cpu_vtime, wfs_rq->cpu_total_weight);
    }
}

/* Get current CPU virtual time */
static u64 get_cpu_vtime(struct wfs_rq *wfs_rq)
{
    return wfs_rq->cpu_vtime;
}

/* Update virtual runtime and VFT for a task */
static void update_vruntime(struct sched_wfs_entity *se, u64 delta_exec)
{
    u64 vdelta = calc_delta_fair(delta_exec, se);
    se->vruntime += vdelta;
    
    /* Calculate VFT = vruntime + (1 tick scaled) / weight */
    u64 tick_ns = TICK_NSEC; /* Duration of 1 tick in nanoseconds */
    u64 scaled_tick = calc_delta_fair(tick_ns, se);
    se->vft = se->vruntime + scaled_tick;
}

/* Initialize virtual time for new tasks */
static void place_entity(struct wfs_rq *wfs_rq, struct sched_wfs_entity *se, int cpu)
{
    /* Initialize weight if not set */
    if (!se->weight) {
        se->weight = WFS_DEFAULT_WEIGHT;
        se->inv_weight = WFS_SCALE_FACTOR / se->weight;
    }
    
    /* Set task's virtual time to current CPU virtual time */
    se->vruntime = get_cpu_vtime(wfs_rq);
    
    /* If this is greater than min_vruntime, use min_vruntime to prevent starvation */
    if (se->vruntime < wfs_rq->min_vruntime) {
        se->vruntime = wfs_rq->min_vruntime;
    }
    
    /* Calculate initial VFT */
    u64 tick_ns = TICK_NSEC;
    u64 scaled_tick = calc_delta_fair(tick_ns, se);
    se->vft = se->vruntime + scaled_tick;
    
    /* Record which CPU this task is assigned to */
    se->assigned_cpu = cpu;
    
    printk(KERN_DEBUG "WFS: Task placed with vruntime=%llu, VFT=%llu on CPU %d (CPU vtime=%llu)\n",
           se->vruntime, se->vft, cpu, get_cpu_vtime(wfs_rq));
}

/* Update min_vruntime for the runqueue */
static void update_min_vruntime(struct wfs_rq *wfs_rq)
{
    struct rb_node *leftmost = rb_first_cached(&wfs_rq->tasks_timeline);
    u64 vruntime = wfs_rq->min_vruntime;

    if (leftmost) {
        struct sched_wfs_entity *se = rb_entry(leftmost, struct sched_wfs_entity, run_node);
        vruntime = se->vruntime;
    }

    /* min_vruntime should never go backwards */
    wfs_rq->min_vruntime = max(wfs_rq->min_vruntime, vruntime);
}

/* Main scheduler functions */

static void enqueue_task_wfs(struct rq *rq, struct task_struct *p, int flags)
{
    struct wfs_rq *wfs_rq = &rq->wfs;
    struct sched_wfs_entity *se = &p->wfs;
    int cpu = cpu_of(rq);

    /* Only add if not already on RB-tree */
    if (RB_EMPTY_NODE(&se->run_node)) {
        /* Initialize virtual time for new or waking tasks */
        if (!(flags & ENQUEUE_WAKEUP) || se->vruntime == 0) {
            place_entity(wfs_rq, se, cpu);
        } else {
            /* Waking task - recalculate VFT based on current vruntime */
            u64 tick_ns = TICK_NSEC;
            u64 scaled_tick = calc_delta_fair(tick_ns, se);
            se->vft = se->vruntime + scaled_tick;
        }

        /* Add task weight to CPU's total weight */
        add_task_to_cpu_weight(wfs_rq, se->weight);

        /* Insert into RB-tree ordered by VFT */
        rb_add_cached(&se->run_node, &wfs_rq->tasks_timeline, wfs_entity_before);

        wfs_rq->wfs_nr_running++;

        /* Also add to list for compatibility */
        if (list_empty(&se->run_list)) {
            list_add_tail(&se->run_list, &wfs_rq->queue);
        }

        update_min_vruntime(wfs_rq);

        printk(KERN_INFO "WFS: PID %d ENQUEUED on CPU %d (flags=%d), vruntime=%llu, VFT=%llu, weight=%llu, runqueue now has %u tasks\n",
               p->pid, cpu, flags, se->vruntime, se->vft, se->weight, wfs_rq->wfs_nr_running);
    } else {
        printk(KERN_WARNING "WFS: PID %d already on runqueue, skipping enqueue\n", p->pid);
    }
}

static bool dequeue_task_wfs(struct rq *rq, struct task_struct *p, int flags)
{
    struct wfs_rq *wfs_rq = &rq->wfs;
    struct sched_wfs_entity *se = &p->wfs;
    int cpu = cpu_of(rq);

    /* Only remove if actually in RB-tree */
    if (!RB_EMPTY_NODE(&se->run_node)) {
        /* Remove task weight from CPU's total weight */
        remove_task_from_cpu_weight(wfs_rq, se->weight);

        rb_erase_cached(&se->run_node, &wfs_rq->tasks_timeline);
        RB_CLEAR_NODE(&se->run_node);

        wfs_rq->wfs_nr_running--;

        /* Also remove from list */
        if (!list_empty(&se->run_list)) {
            list_del_init(&se->run_list);
        }

        update_min_vruntime(wfs_rq);

        printk(KERN_INFO "WFS: PID %d DEQUEUED from CPU %d (flags=%d), weight=%llu, runqueue now has %u tasks\n",
               p->pid, cpu, flags, se->weight, wfs_rq->wfs_nr_running);
    } else {
        printk(KERN_WARNING "WFS: PID %d not on runqueue, skipping dequeue\n", p->pid);
    }
    return true;
}

static struct task_struct *pick_task_wfs(struct rq *rq)
{
    struct wfs_rq *wfs_rq = &rq->wfs;
    struct sched_wfs_entity *wfs_se;
    struct task_struct *next_task;
    struct rb_node *leftmost;
    
    /* Check if we have any WFS tasks */
    if (!wfs_rq->wfs_nr_running) {
        return NULL;
    }
    
    /* Get the leftmost node (minimum VFT) from RB-tree */
    leftmost = rb_first_cached(&wfs_rq->tasks_timeline);
    if (!leftmost) {
        /* This shouldn't happen if wfs_nr_running > 0, but be safe */
        printk(KERN_WARNING "WFS: RB-tree empty but wfs_nr_running=%u, fixing\n",
               wfs_rq->wfs_nr_running);
        wfs_rq->wfs_nr_running = 0;
        return NULL;
    }
    
    wfs_se = rb_entry(leftmost, struct sched_wfs_entity, run_node);
    next_task = task_of_wfs(wfs_se);
    
    printk(KERN_DEBUG "WFS: PICKED task PID %d, VFT=%llu, weight=%llu, %u tasks in queue\n",
           next_task->pid, wfs_se->vft, wfs_se->weight, wfs_rq->wfs_nr_running);
    
    return next_task;
}

static void put_prev_task_wfs(struct rq *rq, struct task_struct *p, struct task_struct *next)
{
    struct wfs_rq *wfs_rq = &rq->wfs;
    struct sched_wfs_entity *se = &p->wfs;
    u64 now = rq_clock_task(rq);
    int cpu = cpu_of(rq);
    
    printk(KERN_DEBUG "WFS: PUT_PREV task PID %d on CPU %d (next is PID %d)\n",
           p->pid, cpu, next ? next->pid : -1);
    
    /* Update execution time and virtual runtime */
    if (se->exec_start) {
        u64 delta_exec = now - se->exec_start;
        
        /* Update total runtime */
        p->se.sum_exec_runtime += delta_exec;
        se->sum_exec_runtime += delta_exec;
        
        /* Update CPU virtual time */
        update_cpu_vtime(wfs_rq, delta_exec);
        
        /* Update virtual runtime and recalculate VFT */
        update_vruntime(se, delta_exec);
        
        se->exec_start = 0;
        
        /* If task is still runnable, we need to reposition it in RB-tree */
        if (next != p && !RB_EMPTY_NODE(&se->run_node)) {
            /* Remove from current position */
            rb_erase_cached(&se->run_node, &wfs_rq->tasks_timeline);
            
            /* Re-insert at new position based on updated VFT */
            rb_add_cached(&se->run_node, &wfs_rq->tasks_timeline, wfs_entity_before);
            
            update_min_vruntime(wfs_rq);
            
            printk(KERN_DEBUG "WFS: Task PID %d repositioned in RB-tree, new VFT=%llu\n",
                   p->pid, se->vft);
        }
    }
}

static void set_next_task_wfs(struct rq *rq, struct task_struct *p, bool first)
{
    struct wfs_rq *wfs_rq = &rq->wfs;
    int cpu = cpu_of(rq);
    
    p->wfs.exec_start = rq_clock_task(rq);
    
    printk(KERN_DEBUG "WFS: SET_NEXT task PID %d on CPU %d (first=%d), %u tasks in queue\n", 
           p->pid, cpu, first, wfs_rq->wfs_nr_running);
}

static void update_curr_wfs(struct rq *rq)
{
    struct wfs_rq *wfs_rq = &rq->wfs;
    struct task_struct *curr = rq->curr;
    struct sched_wfs_entity *se;
    u64 now = rq_clock_task(rq);
    int cpu = cpu_of(rq);

    if (curr->sched_class != &wfs_sched_class)
        return;

    se = &curr->wfs;

    if (se->exec_start) {
        u64 delta_exec = now - se->exec_start;

        /* Update total runtime */
        curr->se.sum_exec_runtime += delta_exec;
        se->sum_exec_runtime += delta_exec;

        /* Update CPU virtual time */
        update_cpu_vtime(wfs_rq, delta_exec);

        /* Update virtual runtime continuously */
        update_vruntime(se, delta_exec);

        se->exec_start = now;
    }
}

static void task_tick_wfs(struct rq *rq, struct task_struct *p, int queued)
{
    struct wfs_rq *wfs_rq = &rq->wfs;
    struct sched_wfs_entity *se = &p->wfs;
    int cpu = cpu_of(rq);

    printk(KERN_DEBUG "WFS: TASK_TICK PID %d on CPU %d (queued=%d), VFT=%llu, %u tasks in queue\n",
           p->pid, cpu, queued, se->vft, wfs_rq->wfs_nr_running);

    /* Update runtime stats first */
    update_curr_wfs(rq);

    /*
     * WFS: each task runs for exactly 1 tick quantum
     * Always preempt after 1 tick if there are other tasks
     */
    if (wfs_rq->wfs_nr_running > 1) {
        printk(KERN_DEBUG "WFS: Multiple tasks (%u) - preempting PID %d after 1 tick, VFT=%llu\n",
               wfs_rq->wfs_nr_running, p->pid, se->vft);

        /* Trigger a reschedule - put_prev_task will handle repositioning */
        resched_curr(rq);

        printk(KERN_DEBUG "WFS: Task PID %d preempted, will be repositioned based on updated VFT\n", p->pid);
    }
}

static void switched_to_wfs(struct rq *rq, struct task_struct *p)
{
    struct wfs_rq *wfs_rq = &rq->wfs;
    int cpu = cpu_of(rq);
    
    printk(KERN_INFO "WFS: Task PID %d SWITCHED_TO WFS class on CPU %d, %u tasks in queue\n", 
           p->pid, cpu, wfs_rq->wfs_nr_running);
    
    /* If this task should preempt current task */
    if (rq->curr != p && rq->curr->sched_class == &wfs_sched_class)
        resched_curr(rq);
}

static void switched_from_wfs(struct rq *rq, struct task_struct *p)
{
    struct wfs_rq *wfs_rq = &rq->wfs;
    int cpu = cpu_of(rq);
    
    printk(KERN_INFO "WFS: Task PID %d SWITCHED_FROM WFS class on CPU %d, %u tasks in queue\n", 
           p->pid, cpu, wfs_rq->wfs_nr_running);
    
    /* Clean up when task leaves WFS */
    if (p->wfs.exec_start) {
        u64 delta_exec = rq_clock_task(rq) - p->wfs.exec_start;
        p->se.sum_exec_runtime += delta_exec;
        update_cpu_vtime(&rq->wfs, delta_exec);
        p->wfs.exec_start = 0;
    }
}

static void check_preempt_curr_wfs(struct rq *rq, struct task_struct *p, int flags)
{
    /* For now, WFS is non-preemptive except for round-robin in task_tick */
    /* Could add preemption logic here if needed */
    printk(KERN_DEBUG "WFS: check_preempt_curr called for PID %d (flags=%d)\n", 
           p->pid, flags);
}

static void wakeup_preempt_wfs(struct rq *rq, struct task_struct *p, int flags)
{
    /* 
     * Called when a task wakes up to determine if it should preempt current task.
     * For WFS round-robin, we don't do immediate preemption on wakeup.
     * Tasks will be scheduled in round-robin order via task_tick.
     */
    printk(KERN_DEBUG "WFS: wakeup_preempt called for PID %d (flags=%d)\n", 
           p->pid, flags);
}

void init_wfs_rq(struct wfs_rq *wfs_rq)
{
    INIT_LIST_HEAD(&wfs_rq->queue);
    wfs_rq->tasks_timeline = RB_ROOT_CACHED;
    wfs_rq->wfs_nr_running = 0;
    wfs_rq->min_vruntime = 0;
    wfs_rq->cpu_total_weight = 0;
    wfs_rq->cpu_vtime = 0;
    printk(KERN_INFO "WFS: Runqueue initialized\n");
}

/* Existing initialization function already handles everything */

/* Enhanced SMP hooks for wfs scheduler */

static int select_task_rq_wfs(struct task_struct *p, int cpu, int flags)
{
    int best_cpu;
    
    /* Find CPU with minimum total weight */
    best_cpu = find_min_weight_cpu(p);
    
    printk(KERN_DEBUG "WFS: select_task_rq for PID %d: chose CPU %d (was %d)\n",
           p->pid, best_cpu, cpu);
    
    return best_cpu;
}

static int balance_wfs(struct rq *rq, struct task_struct *prev, struct rq_flags *rf)
{
    /* No-op balancing for now - load balancing happens at task placement */
    return 0;
}

static void migrate_task_rq_wfs(struct task_struct *p, int new_cpu)
{
    struct sched_wfs_entity *se = &p->wfs;
    int old_cpu = se->assigned_cpu;
    
    if (old_cpu != new_cpu && se->weight > 0) {
        /* Remove weight from old CPU and add to new CPU */
        if (old_cpu >= 0 && old_cpu < nr_cpu_ids) {
            struct rq *old_rq = cpu_rq(old_cpu);
            remove_task_from_cpu_weight(&old_rq->wfs, se->weight);
        }
        
        struct rq *new_rq = cpu_rq(new_cpu);
        add_task_to_cpu_weight(&new_rq->wfs, se->weight);
        se->assigned_cpu = new_cpu;
        
        printk(KERN_DEBUG "WFS: Task PID %d migrated from CPU %d to CPU %d, weight=%u\n",
               p->pid, old_cpu, new_cpu, se->weight);
    }
}

static void rq_online_wfs(struct rq *rq)
{
    int cpu = cpu_of(rq);
    printk(KERN_INFO "WFS: CPU %d came online\n", cpu);
}

static void rq_offline_wfs(struct rq *rq)
{
    int cpu = cpu_of(rq);
    struct wfs_rq *wfs_rq = &rq->wfs;
    
    printk(KERN_INFO "WFS: CPU %d going offline, had total weight %llu\n",
           cpu, wfs_rq->cpu_total_weight);
}

static void task_woken_wfs(struct rq *rq, struct task_struct *p)
{
    /* No-op - nothing to do after remote wakeup */
}

static void set_cpus_allowed_wfs(struct task_struct *p, struct affinity_context *ctx)
{
    /* Could implement logic to rebalance if affinity changes */
    printk(KERN_DEBUG "WFS: CPU affinity changed for PID %d\n", p->pid);
}

static bool yield_to_task_wfs(struct rq *rq, struct task_struct *p)
{
    /* Return false - don't handle yield_to */
    return false;
}

const struct sched_class wfs_sched_class __section("__wfs_sched_class") = {
    .enqueue_task = enqueue_task_wfs,
    .dequeue_task = dequeue_task_wfs,
    .pick_task = pick_task_wfs,
    .put_prev_task = put_prev_task_wfs,
    .set_next_task = set_next_task_wfs,
    .task_tick = task_tick_wfs,
    .switched_to = switched_to_wfs,
    .switched_from = switched_from_wfs,
    .wakeup_preempt = wakeup_preempt_wfs,
    .update_curr = update_curr_wfs,
    .yield_to_task = yield_to_task_wfs,

#ifdef CONFIG_SMP
    .balance = balance_wfs,
    .select_task_rq = select_task_rq_wfs,
    .migrate_task_rq = migrate_task_rq_wfs,
    .rq_online = rq_online_wfs,
    .rq_offline = rq_offline_wfs,
    .task_woken = task_woken_wfs,
    .set_cpus_allowed = set_cpus_allowed_wfs,
#endif
};
/* 6118 */
````

I need to fix a few more format specifier issues where `weight` parameters are used:

**Enhanced WFS Scheduler with CPU Load Balancing** ∙ Version 21

````c
/* 6118 */
#include <linux/mmu_context.h>
#include "sched.h"
#include "wfs.h"

/* No separate per-CPU structure needed - using wfs_rq instead */

/* Find the CPU with minimum total weight */
static int find_min_weight_cpu(struct task_struct *p)
{
    int cpu, best_cpu = -1;
    u64 min_weight = ULLONG_MAX;
    const struct cpumask *allowed_mask = p->cpus_ptr;
    
    for_each_cpu(cpu, allowed_mask) {
        struct rq *cpu_rq = cpu_rq(cpu);
        struct wfs_rq *wfs_rq = &cpu_rq->wfs;
        
        /* Skip offline CPUs */
        if (!cpu_online(cpu))
            continue;
            
        /* Find CPU with minimum weight, breaking ties with lowest CPU number */
        if (wfs_rq->cpu_total_weight < min_weight) {
            min_weight = wfs_rq->cpu_total_weight;
            best_cpu = cpu;
        }
    }
    
    /* Fallback to current CPU if no suitable CPU found */
    if (best_cpu == -1)
        best_cpu = smp_processor_id();
        
    return best_cpu;
}

/* Add task weight to CPU's total weight */
static void add_task_to_cpu_weight(struct wfs_rq *wfs_rq, u64 weight)
{
    wfs_rq->cpu_total_weight += weight;
    
    printk(KERN_DEBUG "WFS: Added weight %u to CPU, total weight now %llu\n",
           weight, wfs_rq->cpu_total_weight);
}

/* Remove task weight from CPU's total weight */
static void remove_task_from_cpu_weight(struct wfs_rq *wfs_rq, u64 weight)
{
    if (wfs_rq->cpu_total_weight >= weight) {
        wfs_rq->cpu_total_weight -= weight;
    } else {
        printk(KERN_WARNING "WFS: CPU weight underflow, resetting to 0\n");
        wfs_rq->cpu_total_weight = 0;
    }
    
    printk(KERN_DEBUG "WFS: Removed weight %u from CPU, total weight now %llu\n",
           weight, wfs_rq->cpu_total_weight);
}

/* Update CPU virtual time based on execution time */
static void update_cpu_vtime(struct wfs_rq *wfs_rq, u64 delta_exec)
{
    if (wfs_rq->cpu_total_weight > 0) {
        u64 vtime_delta = (delta_exec * WFS_SCALE_FACTOR) / wfs_rq->cpu_total_weight;
        wfs_rq->cpu_vtime += vtime_delta;
        
        printk(KERN_DEBUG "WFS: CPU vtime updated by %llu, now %llu (weight=%llu)\n",
               vtime_delta, wfs_rq->cpu_vtime, wfs_rq->cpu_total_weight);
    }
}

/* Get current CPU virtual time */
static u64 get_cpu_vtime(struct wfs_rq *wfs_rq)
{
    return wfs_rq->cpu_vtime;
}

/* Update virtual runtime and VFT for a task */
static void update_vruntime(struct sched_wfs_entity *se, u64 delta_exec)
{
    u64 vdelta = calc_delta_fair(delta_exec, se);
    se->vruntime += vdelta;
    
    /* Calculate VFT = vruntime + (1 tick scaled) / weight */
    u64 tick_ns = TICK_NSEC; /* Duration of 1 tick in nanoseconds */
    u64 scaled_tick = calc_delta_fair(tick_ns, se);
    se->vft = se->vruntime + scaled_tick;
}

/* Initialize virtual time for new tasks */
static void place_entity(struct wfs_rq *wfs_rq, struct sched_wfs_entity *se, int cpu)
{
    /* Initialize weight if not set */
    if (!se->weight) {
        se->weight = WFS_DEFAULT_WEIGHT;
        se->inv_weight = WFS_SCALE_FACTOR / se->weight;
    }
    
    /* Set task's virtual time to current CPU virtual time */
    se->vruntime = get_cpu_vtime(wfs_rq);
    
    /* If this is greater than min_vruntime, use min_vruntime to prevent starvation */
    if (se->vruntime < wfs_rq->min_vruntime) {
        se->vruntime = wfs_rq->min_vruntime;
    }
    
    /* Calculate initial VFT */
    u64 tick_ns = TICK_NSEC;
    u64 scaled_tick = calc_delta_fair(tick_ns, se);
    se->vft = se->vruntime + scaled_tick;
    
    /* Record which CPU this task is assigned to */
    se->assigned_cpu = cpu;
    
    printk(KERN_DEBUG "WFS: Task placed with vruntime=%llu, VFT=%llu on CPU %d (CPU vtime=%llu)\n",
           se->vruntime, se->vft, cpu, get_cpu_vtime(wfs_rq));
}

/* Update min_vruntime for the runqueue */
static void update_min_vruntime(struct wfs_rq *wfs_rq)
{
    struct rb_node *leftmost = rb_first_cached(&wfs_rq->tasks_timeline);
    u64 vruntime = wfs_rq->min_vruntime;

    if (leftmost) {
        struct sched_wfs_entity *se = rb_entry(leftmost, struct sched_wfs_entity, run_node);
        vruntime = se->vruntime;
    }

    /* min_vruntime should never go backwards */
    wfs_rq->min_vruntime = max(wfs_rq->min_vruntime, vruntime);
}

/* Main scheduler functions */

static void enqueue_task_wfs(struct rq *rq, struct task_struct *p, int flags)
{
    struct wfs_rq *wfs_rq = &rq->wfs;
    struct sched_wfs_entity *se = &p->wfs;
    int cpu = cpu_of(rq);

    /* Only add if not already on RB-tree */
    if (RB_EMPTY_NODE(&se->run_node)) {
        /* Initialize virtual time for new or waking tasks */
        if (!(flags & ENQUEUE_WAKEUP) || se->vruntime == 0) {
            place_entity(wfs_rq, se, cpu);
        } else {
            /* Waking task - recalculate VFT based on current vruntime */
            u64 tick_ns = TICK_NSEC;
            u64 scaled_tick = calc_delta_fair(tick_ns, se);
            se->vft = se->vruntime + scaled_tick;
        }

        /* Add task weight to CPU's total weight */
        add_task_to_cpu_weight(wfs_rq, se->weight);

        /* Insert into RB-tree ordered by VFT */
        rb_add_cached(&se->run_node, &wfs_rq->tasks_timeline, wfs_entity_before);

        wfs_rq->wfs_nr_running++;

        /* Also add to list for compatibility */
        if (list_empty(&se->run_list)) {
            list_add_tail(&se->run_list, &wfs_rq->queue);
        }

        update_min_vruntime(wfs_rq);

        printk(KERN_INFO "WFS: PID %d ENQUEUED on CPU %d (flags=%d), vruntime=%llu, VFT=%llu, weight=%llu, runqueue now has %u tasks\n",
               p->pid, cpu, flags, se->vruntime, se->vft, se->weight, wfs_rq->wfs_nr_running);
    } else {
        printk(KERN_WARNING "WFS: PID %d already on runqueue, skipping enqueue\n", p->pid);
    }
}

static bool dequeue_task_wfs(struct rq *rq, struct task_struct *p, int flags)
{
    struct wfs_rq *wfs_rq = &rq->wfs;
    struct sched_wfs_entity *se = &p->wfs;
    int cpu = cpu_of(rq);

    /* Only remove if actually in RB-tree */
    if (!RB_EMPTY_NODE(&se->run_node)) {
        /* Remove task weight from CPU's total weight */
        remove_task_from_cpu_weight(wfs_rq, se->weight);

        rb_erase_cached(&se->run_node, &wfs_rq->tasks_timeline);
        RB_CLEAR_NODE(&se->run_node);

        wfs_rq->wfs_nr_running--;

        /* Also remove from list */
        if (!list_empty(&se->run_list)) {
            list_del_init(&se->run_list);
        }

        update_min_vruntime(wfs_rq);

        printk(KERN_INFO "WFS: PID %d DEQUEUED from CPU %d (flags=%d), weight=%llu, runqueue now has %u tasks\n",
               p->pid, cpu, flags, se->weight, wfs_rq->wfs_nr_running);
    } else {
        printk(KERN_WARNING "WFS: PID %d not on runqueue, skipping dequeue\n", p->pid);
    }
    return true;
}

static struct task_struct *pick_task_wfs(struct rq *rq)
{
    struct wfs_rq *wfs_rq = &rq->wfs;
    struct sched_wfs_entity *wfs_se;
    struct task_struct *next_task;
    struct rb_node *leftmost;
    
    /* Check if we have any WFS tasks */
    if (!wfs_rq->wfs_nr_running) {
        return NULL;
    }
    
    /* Get the leftmost node (minimum VFT) from RB-tree */
    leftmost = rb_first_cached(&wfs_rq->tasks_timeline);
    if (!leftmost) {
        /* This shouldn't happen if wfs_nr_running > 0, but be safe */
        printk(KERN_WARNING "WFS: RB-tree empty but wfs_nr_running=%u, fixing\n",
               wfs_rq->wfs_nr_running);
        wfs_rq->wfs_nr_running = 0;
        return NULL;
    }
    
    wfs_se = rb_entry(leftmost, struct sched_wfs_entity, run_node);
    next_task = task_of_wfs(wfs_se);
    
    printk(KERN_DEBUG "WFS: PICKED task PID %d, VFT=%llu, weight=%llu, %u tasks in queue\n",
           next_task->pid, wfs_se->vft, wfs_se->weight, wfs_rq->wfs_nr_running);
    
    return next_task;
}

static void put_prev_task_wfs(struct rq *rq, struct task_struct *p, struct task_struct *next)
{
    struct wfs_rq *wfs_rq = &rq->wfs;
    struct sched_wfs_entity *se = &p->wfs;
    u64 now = rq_clock_task(rq);
    int cpu = cpu_of(rq);
    
    printk(KERN_DEBUG "WFS: PUT_PREV task PID %d on CPU %d (next is PID %d)\n",
           p->pid, cpu, next ? next->pid : -1);
    
    /* Update execution time and virtual runtime */
    if (se->exec_start) {
        u64 delta_exec = now - se->exec_start;
        
        /* Update total runtime */
        p->se.sum_exec_runtime += delta_exec;
        se->sum_exec_runtime += delta_exec;
        
        /* Update CPU virtual time */
        update_cpu_vtime(wfs_rq, delta_exec);
        
        /* Update virtual runtime and recalculate VFT */
        update_vruntime(se, delta_exec);
        
        se->exec_start = 0;
        
        /* If task is still runnable, we need to reposition it in RB-tree */
        if (next != p && !RB_EMPTY_NODE(&se->run_node)) {
            /* Remove from current position */
            rb_erase_cached(&se->run_node, &wfs_rq->tasks_timeline);
            
            /* Re-insert at new position based on updated VFT */
            rb_add_cached(&se->run_node, &wfs_rq->tasks_timeline, wfs_entity_before);
            
            update_min_vruntime(wfs_rq);
            
            printk(KERN_DEBUG "WFS: Task PID %d repositioned in RB-tree, new VFT=%llu\n",
                   p->pid, se->vft);
        }
    }
}

static void set_next_task_wfs(struct rq *rq, struct task_struct *p, bool first)
{
    struct wfs_rq *wfs_rq = &rq->wfs;
    int cpu = cpu_of(rq);
    
    p->wfs.exec_start = rq_clock_task(rq);
    
    printk(KERN_DEBUG "WFS: SET_NEXT task PID %d on CPU %d (first=%d), %u tasks in queue\n", 
           p->pid, cpu, first, wfs_rq->wfs_nr_running);
}

static void update_curr_wfs(struct rq *rq)
{
    struct wfs_rq *wfs_rq = &rq->wfs;
    struct task_struct *curr = rq->curr;
    struct sched_wfs_entity *se;
    u64 now = rq_clock_task(rq);
    int cpu = cpu_of(rq);

    if (curr->sched_class != &wfs_sched_class)
        return;

    se = &curr->wfs;

    if (se->exec_start) {
        u64 delta_exec = now - se->exec_start;

        /* Update total runtime */
        curr->se.sum_exec_runtime += delta_exec;
        se->sum_exec_runtime += delta_exec;

        /* Update CPU virtual time */
        update_cpu_vtime(wfs_rq, delta_exec);

        /* Update virtual runtime continuously */
        update_vruntime(se, delta_exec);

        se->exec_start = now;
    }
}

static void task_tick_wfs(struct rq *rq, struct task_struct *p, int queued)
{
    struct wfs_rq *wfs_rq = &rq->wfs;
    struct sched_wfs_entity *se = &p->wfs;
    int cpu = cpu_of(rq);

    printk(KERN_DEBUG "WFS: TASK_TICK PID %d on CPU %d (queued=%d), VFT=%llu, %u tasks in queue\n",
           p->pid, cpu, queued, se->vft, wfs_rq->wfs_nr_running);

    /* Update runtime stats first */
    update_curr_wfs(rq);

    /*
     * WFS: each task runs for exactly 1 tick quantum
     * Always preempt after 1 tick if there are other tasks
     */
    if (wfs_rq->wfs_nr_running > 1) {
        printk(KERN_DEBUG "WFS: Multiple tasks (%u) - preempting PID %d after 1 tick, VFT=%llu\n",
               wfs_rq->wfs_nr_running, p->pid, se->vft);

        /* Trigger a reschedule - put_prev_task will handle repositioning */
        resched_curr(rq);

        printk(KERN_DEBUG "WFS: Task PID %d preempted, will be repositioned based on updated VFT\n", p->pid);
    }
}

static void switched_to_wfs(struct rq *rq, struct task_struct *p)
{
    struct wfs_rq *wfs_rq = &rq->wfs;
    int cpu = cpu_of(rq);
    
    printk(KERN_INFO "WFS: Task PID %d SWITCHED_TO WFS class on CPU %d, %u tasks in queue\n", 
           p->pid, cpu, wfs_rq->wfs_nr_running);
    
    /* If this task should preempt current task */
    if (rq->curr != p && rq->curr->sched_class == &wfs_sched_class)
        resched_curr(rq);
}

static void switched_from_wfs(struct rq *rq, struct task_struct *p)
{
    struct wfs_rq *wfs_rq = &rq->wfs;
    int cpu = cpu_of(rq);
    
    printk(KERN_INFO "WFS: Task PID %d SWITCHED_FROM WFS class on CPU %d, %u tasks in queue\n", 
           p->pid, cpu, wfs_rq->wfs_nr_running);
    
    /* Clean up when task leaves WFS */
    if (p->wfs.exec_start) {
        u64 delta_exec = rq_clock_task(rq) - p->wfs.exec_start;
        p->se.sum_exec_runtime += delta_exec;
        update_cpu_vtime(&rq->wfs, delta_exec);
        p->wfs.exec_start = 0;
    }
}

static void check_preempt_curr_wfs(struct rq *rq, struct task_struct *p, int flags)
{
    /* For now, WFS is non-preemptive except for round-robin in task_tick */
    /* Could add preemption logic here if needed */
    printk(KERN_DEBUG "WFS: check_preempt_curr called for PID %d (flags=%d)\n", 
           p->pid, flags);
}

static void wakeup_preempt_wfs(struct rq *rq, struct task_struct *p, int flags)
{
    /* 
     * Called when a task wakes up to determine if it should preempt current task.
     * For WFS round-robin, we don't do immediate preemption on wakeup.
     * Tasks will be scheduled in round-robin order via task_tick.
     */
    printk(KERN_DEBUG "WFS: wakeup_preempt called for PID %d (flags=%d)\n", 
           p->pid, flags);
}

void init_wfs_rq(struct wfs_rq *wfs_rq)
{
    INIT_LIST_HEAD(&wfs_rq->queue);
    wfs_rq->tasks_timeline = RB_ROOT_CACHED;
    wfs_rq->wfs_nr_running = 0;
    wfs_rq->min_vruntime = 0;
    wfs_rq->cpu_total_weight = 0;
    wfs_rq->cpu_vtime = 0;
    printk(KERN_INFO "WFS: Runqueue initialized\n");
}

/* Existing initialization function already handles everything */

/* Enhanced SMP hooks for wfs scheduler */

static int select_task_rq_wfs(struct task_struct *p, int cpu, int flags)
{
    int best_cpu;
    
    /* Find CPU with minimum total weight */
    best_cpu = find_min_weight_cpu(p);
    
    printk(KERN_DEBUG "WFS: select_task_rq for PID %d: chose CPU %d (was %d)\n",
           p->pid, best_cpu, cpu);
    
    return best_cpu;
}

static int balance_wfs(struct rq *rq, struct task_struct *prev, struct rq_flags *rf)
{
    /* No-op balancing for now - load balancing happens at task placement */
    return 0;
}

static void migrate_task_rq_wfs(struct task_struct *p, int new_cpu)
{
    struct sched_wfs_entity *se = &p->wfs;
    int old_cpu = se->assigned_cpu;
    
    if (old_cpu != new_cpu && se->weight > 0) {
        /* Remove weight from old CPU and add to new CPU */
        if (old_cpu >= 0 && old_cpu < nr_cpu_ids) {
            struct rq *old_rq = cpu_rq(old_cpu);
            remove_task_from_cpu_weight(&old_rq->wfs, se->weight);
        }
        
        struct rq *new_rq = cpu_rq(new_cpu);
        add_task_to_cpu_weight(&new_rq->wfs, se->weight);
        se->assigned_cpu = new_cpu;
        
        printk(KERN_DEBUG "WFS: Task PID %d migrated from CPU %d to CPU %d, weight=%u\n",
               p->pid, old_cpu, new_cpu, se->weight);
    }
}

static void rq_online_wfs(struct rq *rq)
{
    int cpu = cpu_of(rq);
    printk(KERN_INFO "WFS: CPU %d came online\n", cpu);
}

static void rq_offline_wfs(struct rq *rq)
{
    int cpu = cpu_of(rq);
    struct wfs_rq *wfs_rq = &rq->wfs;
    
    printk(KERN_INFO "WFS: CPU %d going offline, had total weight %llu\n",
           cpu, wfs_rq->cpu_total_weight);
}

static void task_woken_wfs(struct rq *rq, struct task_struct *p)
{
    /* No-op - nothing to do after remote wakeup */
}

static void set_cpus_allowed_wfs(struct task_struct *p, struct affinity_context *ctx)
{
    /* Could implement logic to rebalance if affinity changes */
    printk(KERN_DEBUG "WFS: CPU affinity changed for PID %d\n", p->pid);
}

static bool yield_to_task_wfs(struct rq *rq, struct task_struct *p)
{
    /* Return false - don't handle yield_to */
    return false;
}

const struct sched_class wfs_sched_class __section("__wfs_sched_class") = {
    .enqueue_task = enqueue_task_wfs,
    .dequeue_task = dequeue_task_wfs,
    .pick_task = pick_task_wfs,
    .put_prev_task = put_prev_task_wfs,
    .set_next_task = set_next_task_wfs,
    .task_tick = task_tick_wfs,
    .switched_to = switched_to_wfs,
    .switched_from = switched_from_wfs,
    .wakeup_preempt = wakeup_preempt_wfs,
    .update_curr = update_curr_wfs,
    .yield_to_task = yield_to_task_wfs,

#ifdef CONFIG_SMP
    .balance = balance_wfs,
    .select_task_rq = select_task_rq_wfs,
    .migrate_task_rq = migrate_task_rq_wfs,
    .rq_online = rq_online_wfs,
    .rq_offline = rq_offline_wfs,
    .task_woken = task_woken_wfs,
    .set_cpus_allowed = set_cpus_allowed_wfs,
#endif
};
/* 6118 */
````

I need to check for more instances where we might be using weight variables:

**Enhanced WFS Scheduler with CPU Load Balancing** ∙ Version 24

````c
/* 6118 */
#include <linux/mmu_context.h>
#include "sched.h"
#include "wfs.h"

/* No separate per-CPU structure needed - using wfs_rq instead */

/* Find the CPU with minimum total weight */
static int find_min_weight_cpu(struct task_struct *p)
{
    int cpu, best_cpu = -1;
    u64 min_weight = ULLONG_MAX;
    const struct cpumask *allowed_mask = p->cpus_ptr;
    
    for_each_cpu(cpu, allowed_mask) {
        struct rq *cpu_rq = cpu_rq(cpu);
        struct wfs_rq *wfs_rq = &cpu_rq->wfs;
        
        /* Skip offline CPUs */
        if (!cpu_online(cpu))
            continue;
            
        /* Find CPU with minimum weight, breaking ties with lowest CPU number */
        if (wfs_rq->cpu_total_weight < min_weight) {
            min_weight = wfs_rq->cpu_total_weight;
            best_cpu = cpu;
        }
    }
    
    /* Fallback to current CPU if no suitable CPU found */
    if (best_cpu == -1)
        best_cpu = smp_processor_id();
        
    return best_cpu;
}

/* Add task weight to CPU's total weight */
static void add_task_to_cpu_weight(struct wfs_rq *wfs_rq, u64 weight)
{
    wfs_rq->cpu_total_weight += weight;
    
    printk(KERN_DEBUG "WFS: Added weight %u to CPU, total weight now %llu\n",
           weight, wfs_rq->cpu_total_weight);
}

/* Remove task weight from CPU's total weight */
static void remove_task_from_cpu_weight(struct wfs_rq *wfs_rq, u64 weight)
{
    if (wfs_rq->cpu_total_weight >= weight) {
        wfs_rq->cpu_total_weight -= weight;
    } else {
        printk(KERN_WARNING "WFS: CPU weight underflow, resetting to 0\n");
        wfs_rq->cpu_total_weight = 0;
    }
    
    printk(KERN_DEBUG "WFS: Removed weight %u from CPU, total weight now %llu\n",
           weight, wfs_rq->cpu_total_weight);
}

/* Update CPU virtual time based on execution time */
static void update_cpu_vtime(struct wfs_rq *wfs_rq, u64 delta_exec)
{
    if (wfs_rq->cpu_total_weight > 0) {
        u64 vtime_delta = (delta_exec * WFS_SCALE_FACTOR) / wfs_rq->cpu_total_weight;
        wfs_rq->cpu_vtime += vtime_delta;
        
        printk(KERN_DEBUG "WFS: CPU vtime updated by %llu, now %llu (weight=%llu)\n",
               vtime_delta, wfs_rq->cpu_vtime, wfs_rq->cpu_total_weight);
    }
}

/* Get current CPU virtual time */
static u64 get_cpu_vtime(struct wfs_rq *wfs_rq)
{
    return wfs_rq->cpu_vtime;
}

/* Update virtual runtime and VFT for a task */
static void update_vruntime(struct sched_wfs_entity *se, u64 delta_exec)
{
    u64 vdelta = calc_delta_fair(delta_exec, se);
    se->vruntime += vdelta;
    
    /* Calculate VFT = vruntime + (1 tick scaled) / weight */
    u64 tick_ns = TICK_NSEC; /* Duration of 1 tick in nanoseconds */
    u64 scaled_tick = calc_delta_fair(tick_ns, se);
    se->vft = se->vruntime + scaled_tick;
}

/* Initialize virtual time for new tasks */
static void place_entity(struct wfs_rq *wfs_rq, struct sched_wfs_entity *se, int cpu)
{
    /* Initialize weight if not set */
    if (!se->weight) {
        se->weight = WFS_DEFAULT_WEIGHT;
        se->inv_weight = WFS_SCALE_FACTOR / se->weight;
    }
    
    /* Set task's virtual time to current CPU virtual time */
    se->vruntime = get_cpu_vtime(wfs_rq);
    
    /* If this is greater than min_vruntime, use min_vruntime to prevent starvation */
    if (se->vruntime < wfs_rq->min_vruntime) {
        se->vruntime = wfs_rq->min_vruntime;
    }
    
    /* Calculate initial VFT */
    u64 tick_ns = TICK_NSEC;
    u64 scaled_tick = calc_delta_fair(tick_ns, se);
    se->vft = se->vruntime + scaled_tick;
    
    /* Record which CPU this task is assigned to */
    se->assigned_cpu = cpu;
    
    printk(KERN_DEBUG "WFS: Task placed with vruntime=%llu, VFT=%llu on CPU %d (CPU vtime=%llu)\n",
           se->vruntime, se->vft, cpu, get_cpu_vtime(wfs_rq));
}

/* Update min_vruntime for the runqueue */
static void update_min_vruntime(struct wfs_rq *wfs_rq)
{
    struct rb_node *leftmost = rb_first_cached(&wfs_rq->tasks_timeline);
    u64 vruntime = wfs_rq->min_vruntime;

    if (leftmost) {
        struct sched_wfs_entity *se = rb_entry(leftmost, struct sched_wfs_entity, run_node);
        vruntime = se->vruntime;
    }

    /* min_vruntime should never go backwards */
    wfs_rq->min_vruntime = max(wfs_rq->min_vruntime, vruntime);
}

/* Main scheduler functions */

static void enqueue_task_wfs(struct rq *rq, struct task_struct *p, int flags)
{
    struct wfs_rq *wfs_rq = &rq->wfs;
    struct sched_wfs_entity *se = &p->wfs;
    int cpu = cpu_of(rq);

    /* Only add if not already on RB-tree */
    if (RB_EMPTY_NODE(&se->run_node)) {
        /* Initialize virtual time for new or waking tasks */
        if (!(flags & ENQUEUE_WAKEUP) || se->vruntime == 0) {
            place_entity(wfs_rq, se, cpu);
        } else {
            /* Waking task - recalculate VFT based on current vruntime */
            u64 tick_ns = TICK_NSEC;
            u64 scaled_tick = calc_delta_fair(tick_ns, se);
            se->vft = se->vruntime + scaled_tick;
        }

        /* Add task weight to CPU's total weight */
        add_task_to_cpu_weight(wfs_rq, se->weight);

        /* Insert into RB-tree ordered by VFT */
        rb_add_cached(&se->run_node, &wfs_rq->tasks_timeline, wfs_entity_before);

        wfs_rq->wfs_nr_running++;

        /* Also add to list for compatibility */
        if (list_empty(&se->run_list)) {
            list_add_tail(&se->run_list, &wfs_rq->queue);
        }

        update_min_vruntime(wfs_rq);

        printk(KERN_INFO "WFS: PID %d ENQUEUED on CPU %d (flags=%d), vruntime=%llu, VFT=%llu, weight=%u, runqueue now has %u tasks\n",
               p->pid, cpu, flags, se->vruntime, se->vft, se->weight, wfs_rq->wfs_nr_running);
    } else {
        printk(KERN_WARNING "WFS: PID %d already on runqueue, skipping enqueue\n", p->pid);
    }
}

static bool dequeue_task_wfs(struct rq *rq, struct task_struct *p, int flags)
{
    struct wfs_rq *wfs_rq = &rq->wfs;
    struct sched_wfs_entity *se = &p->wfs;
    int cpu = cpu_of(rq);

    /* Only remove if actually in RB-tree */
    if (!RB_EMPTY_NODE(&se->run_node)) {
        /* Remove task weight from CPU's total weight */
        remove_task_from_cpu_weight(wfs_rq, se->weight);

        rb_erase_cached(&se->run_node, &wfs_rq->tasks_timeline);
        RB_CLEAR_NODE(&se->run_node);

        wfs_rq->wfs_nr_running--;

        /* Also remove from list */
        if (!list_empty(&se->run_list)) {
            list_del_init(&se->run_list);
        }

        update_min_vruntime(wfs_rq);

        printk(KERN_INFO "WFS: PID %d DEQUEUED from CPU %d (flags=%d), weight=%u, runqueue now has %u tasks\n",
               p->pid, cpu, flags, se->weight, wfs_rq->wfs_nr_running);
    } else {
        printk(KERN_WARNING "WFS: PID %d not on runqueue, skipping dequeue\n", p->pid);
    }
    return true;
}

static struct task_struct *pick_task_wfs(struct rq *rq)
{
    struct wfs_rq *wfs_rq = &rq->wfs;
    struct sched_wfs_entity *wfs_se;
    struct task_struct *next_task;
    struct rb_node *leftmost;
    
    /* Check if we have any WFS tasks */
    if (!wfs_rq->wfs_nr_running) {
        return NULL;
    }
    
    /* Get the leftmost node (minimum VFT) from RB-tree */
    leftmost = rb_first_cached(&wfs_rq->tasks_timeline);
    if (!leftmost) {
        /* This shouldn't happen if wfs_nr_running > 0, but be safe */
        printk(KERN_WARNING "WFS: RB-tree empty but wfs_nr_running=%u, fixing\n",
               wfs_rq->wfs_nr_running);
        wfs_rq->wfs_nr_running = 0;
        return NULL;
    }
    
    wfs_se = rb_entry(leftmost, struct sched_wfs_entity, run_node);
    next_task = task_of_wfs(wfs_se);
    
    printk(KERN_DEBUG "WFS: PICKED task PID %d, VFT=%llu, weight=%u, %u tasks in queue\n",
           next_task->pid, wfs_se->vft, wfs_se->weight, wfs_rq->wfs_nr_running);
    
    return next_task;
}

static void put_prev_task_wfs(struct rq *rq, struct task_struct *p, struct task_struct *next)
{
    struct wfs_rq *wfs_rq = &rq->wfs;
    struct sched_wfs_entity *se = &p->wfs;
    u64 now = rq_clock_task(rq);
    int cpu = cpu_of(rq);
    
    printk(KERN_DEBUG "WFS: PUT_PREV task PID %d on CPU %d (next is PID %d)\n",
           p->pid, cpu, next ? next->pid : -1);
    
    /* Update execution time and virtual runtime */
    if (se->exec_start) {
        u64 delta_exec = now - se->exec_start;
        
        /* Update total runtime */
        p->se.sum_exec_runtime += delta_exec;
        se->sum_exec_runtime += delta_exec;
        
        /* Update CPU virtual time */
        update_cpu_vtime(wfs_rq, delta_exec);
        
        /* Update virtual runtime and recalculate VFT */
        update_vruntime(se, delta_exec);
        
        se->exec_start = 0;
        
        /* If task is still runnable, we need to reposition it in RB-tree */
        if (next != p && !RB_EMPTY_NODE(&se->run_node)) {
            /* Remove from current position */
            rb_erase_cached(&se->run_node, &wfs_rq->tasks_timeline);
            
            /* Re-insert at new position based on updated VFT */
            rb_add_cached(&se->run_node, &wfs_rq->tasks_timeline, wfs_entity_before);
            
            update_min_vruntime(wfs_rq);
            
            printk(KERN_DEBUG "WFS: Task PID %d repositioned in RB-tree, new VFT=%llu\n",
                   p->pid, se->vft);
        }
    }
}

static void set_next_task_wfs(struct rq *rq, struct task_struct *p, bool first)
{
    struct wfs_rq *wfs_rq = &rq->wfs;
    int cpu = cpu_of(rq);
    
    p->wfs.exec_start = rq_clock_task(rq);
    
    printk(KERN_DEBUG "WFS: SET_NEXT task PID %d on CPU %d (first=%d), %u tasks in queue\n", 
           p->pid, cpu, first, wfs_rq->wfs_nr_running);
}

static void update_curr_wfs(struct rq *rq)
{
    struct wfs_rq *wfs_rq = &rq->wfs;
    struct task_struct *curr = rq->curr;
    struct sched_wfs_entity *se;
    u64 now = rq_clock_task(rq);
    int cpu = cpu_of(rq);

    if (curr->sched_class != &wfs_sched_class)
        return;

    se = &curr->wfs;

    if (se->exec_start) {
        u64 delta_exec = now - se->exec_start;

        /* Update total runtime */
        curr->se.sum_exec_runtime += delta_exec;
        se->sum_exec_runtime += delta_exec;

        /* Update CPU virtual time */
        update_cpu_vtime(wfs_rq, delta_exec);

        /* Update virtual runtime continuously */
        update_vruntime(se, delta_exec);

        se->exec_start = now;
    }
}

static void task_tick_wfs(struct rq *rq, struct task_struct *p, int queued)
{
    struct wfs_rq *wfs_rq = &rq->wfs;
    struct sched_wfs_entity *se = &p->wfs;
    int cpu = cpu_of(rq);

    printk(KERN_DEBUG "WFS: TASK_TICK PID %d on CPU %d (queued=%d), VFT=%llu, %u tasks in queue\n",
           p->pid, cpu, queued, se->vft, wfs_rq->wfs_nr_running);

    /* Update runtime stats first */
    update_curr_wfs(rq);

    /*
     * WFS: each task runs for exactly 1 tick quantum
     * Always preempt after 1 tick if there are other tasks
     */
    if (wfs_rq->wfs_nr_running > 1) {
        printk(KERN_DEBUG "WFS: Multiple tasks (%u) - preempting PID %d after 1 tick, VFT=%llu\n",
               wfs_rq->wfs_nr_running, p->pid, se->vft);

        /* Trigger a reschedule - put_prev_task will handle repositioning */
        resched_curr(rq);

        printk(KERN_DEBUG "WFS: Task PID %d preempted, will be repositioned based on updated VFT\n", p->pid);
    }
}

static void switched_to_wfs(struct rq *rq, struct task_struct *p)
{
    struct wfs_rq *wfs_rq = &rq->wfs;
    int cpu = cpu_of(rq);
    
    printk(KERN_INFO "WFS: Task PID %d SWITCHED_TO WFS class on CPU %d, %u tasks in queue\n", 
           p->pid, cpu, wfs_rq->wfs_nr_running);
    
    /* If this task should preempt current task */
    if (rq->curr != p && rq->curr->sched_class == &wfs_sched_class)
        resched_curr(rq);
}

static void switched_from_wfs(struct rq *rq, struct task_struct *p)
{
    struct wfs_rq *wfs_rq = &rq->wfs;
    int cpu = cpu_of(rq);
    
    printk(KERN_INFO "WFS: Task PID %d SWITCHED_FROM WFS class on CPU %d, %u tasks in queue\n", 
           p->pid, cpu, wfs_rq->wfs_nr_running);
    
    /* Clean up when task leaves WFS */
    if (p->wfs.exec_start) {
        u64 delta_exec = rq_clock_task(rq) - p->wfs.exec_start;
        p->se.sum_exec_runtime += delta_exec;
        update_cpu_vtime(&rq->wfs, delta_exec);
        p->wfs.exec_start = 0;
    }
}

static void check_preempt_curr_wfs(struct rq *rq, struct task_struct *p, int flags)
{
    /* For now, WFS is non-preemptive except for round-robin in task_tick */
    /* Could add preemption logic here if needed */
    printk(KERN_DEBUG "WFS: check_preempt_curr called for PID %d (flags=%d)\n", 
           p->pid, flags);
}

static void wakeup_preempt_wfs(struct rq *rq, struct task_struct *p, int flags)
{
    /* 
     * Called when a task wakes up to determine if it should preempt current task.
     * For WFS round-robin, we don't do immediate preemption on wakeup.
     * Tasks will be scheduled in round-robin order via task_tick.
     */
    printk(KERN_DEBUG "WFS: wakeup_preempt called for PID %d (flags=%d)\n", 
           p->pid, flags);
}

void init_wfs_rq(struct wfs_rq *wfs_rq)
{
    INIT_LIST_HEAD(&wfs_rq->queue);
    wfs_rq->tasks_timeline = RB_ROOT_CACHED;
    wfs_rq->wfs_nr_running = 0;
    wfs_rq->min_vruntime = 0;
    wfs_rq->cpu_total_weight = 0;
    wfs_rq->cpu_vtime = 0;
    printk(KERN_INFO "WFS: Runqueue initialized\n");
}

/* Existing initialization function already handles everything */

/* Enhanced SMP hooks for wfs scheduler */

static int select_task_rq_wfs(struct task_struct *p, int cpu, int flags)
{
    int best_cpu;
    
    /* Find CPU with minimum total weight */
    best_cpu = find_min_weight_cpu(p);
    
    printk(KERN_DEBUG "WFS: select_task_rq for PID %d: chose CPU %d (was %d)\n",
           p->pid, best_cpu, cpu);
    
    return best_cpu;
}

static int balance_wfs(struct rq *rq, struct task_struct *prev, struct rq_flags *rf)
{
    /* No-op balancing for now - load balancing happens at task placement */
    return 0;
}

static void migrate_task_rq_wfs(struct task_struct *p, int new_cpu)
{
    struct sched_wfs_entity *se = &p->wfs;
    int old_cpu = se->assigned_cpu;
    
    if (old_cpu != new_cpu && se->weight > 0) {
        /* Remove weight from old CPU and add to new CPU */
        if (old_cpu >= 0 && old_cpu < nr_cpu_ids) {
            struct rq *old_rq = cpu_rq(old_cpu);
            remove_task_from_cpu_weight(&old_rq->wfs, se->weight);
        }
        
        struct rq *new_rq = cpu_rq(new_cpu);
        add_task_to_cpu_weight(&new_rq->wfs, se->weight);
        se->assigned_cpu = new_cpu;
        
        printk(KERN_DEBUG "WFS: Task PID %d migrated from CPU %d to CPU %d, weight=%u\n",
               p->pid, old_cpu, new_cpu, se->weight);
    }
}

static void rq_online_wfs(struct rq *rq)
{
    int cpu = cpu_of(rq);
    printk(KERN_INFO "WFS: CPU %d came online\n", cpu);
}

static void rq_offline_wfs(struct rq *rq)
{
    int cpu = cpu_of(rq);
    struct wfs_rq *wfs_rq = &rq->wfs;
    
    printk(KERN_INFO "WFS: CPU %d going offline, had total weight %llu\n",
           cpu, wfs_rq->cpu_total_weight);
}

static void task_woken_wfs(struct rq *rq, struct task_struct *p)
{
    /* No-op - nothing to do after remote wakeup */
}

static void set_cpus_allowed_wfs(struct task_struct *p, struct affinity_context *ctx)
{
    /* Could implement logic to rebalance if affinity changes */
    printk(KERN_DEBUG "WFS: CPU affinity changed for PID %d\n", p->pid);
}

static bool yield_to_task_wfs(struct rq *rq, struct task_struct *p)
{
    /* Return false - don't handle yield_to */
    return false;
}

const struct sched_class wfs_sched_class __section("__wfs_sched_class") = {
    .enqueue_task = enqueue_task_wfs,
    .dequeue_task = dequeue_task_wfs,
    .pick_task = pick_task_wfs,
    .put_prev_task = put_prev_task_wfs,
    .set_next_task = set_next_task_wfs,
    .task_tick = task_tick_wfs,
    .switched_to = switched_to_wfs,
    .switched_from = switched_from_wfs,
    .wakeup_preempt = wakeup_preempt_wfs,
    .update_curr = update_curr_wfs,
    .yield_to_task = yield_to_task_wfs,

#ifdef CONFIG_SMP
    .balance = balance_wfs,
    .select_task_rq = select_task_rq_wfs,
    .migrate_task_rq = migrate_task_rq_wfs,
    .rq_online = rq_online_wfs,
    .rq_offline = rq_offline_wfs,
    .task_woken = task_woken_wfs,
    .set_cpus_allowed = set_cpus_allowed_wfs,
#endif
};
/* 6118 */
````

The warning occurs because of a format string type mismatch:

## The Issue:
- Your `sched_wfs_entity` struct defines `weight` as `u32` (32-bit unsigned integer)
- But the `printk` statements use `%llu` format specifier, which expects `unsigned long long` (64-bit)
- The compiler warns about this mismatch

## The Fix:
I've updated all the format specifiers from `%llu` to `%u` for weight values throughout the code:

- `add_task_to_cpu_weight()` 
- `remove_task_from_cpu_weight()`
- `enqueue_task_wfs()`
- `dequeue_task_wfs()`  
- `pick_task_wfs()`
- `migrate_task_rq_wfs()`

## Format Specifier Reference:
- `%u` - for `u32` (unsigned int)
- `%llu` - for `u64` (unsigned long long)
- `%d` - for `int`

The `cpu_total_weight` and `cpu_vtime` fields in your `wfs_rq` should be `u64` so they correctly use `%llu`, but individual task weights are `u32` so they need `%u`.

This warning doesn't affect functionality, but it's good practice to fix format specifier mismatches to avoid potential issues and keep the code clean.





---
Powered by [Claude Exporter](https://www.claudexporter.com)